"""
浏览器版（单文件 HTML）冒烟 + 性能实测。

不依赖 Python 桥接，直接以 file:// 打开 dist/Qazr音频剪辑.html，
模拟导入一个片段、选中它，然后逐项测「拖动 / 松手 / 缩放」这三条重路径。
用法：py _probe/browser_perf.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from PySide6.QtWidgets import QApplication            # noqa: E402
from PySide6.QtCore import QTimer, QUrl               # noqa: E402
from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa: E402
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings  # noqa: E402

HTML = os.path.abspath(os.path.join(os.path.dirname(__file__), "..",
                                    "dist", "Qazr音频剪辑.html"))

GEN_WAV = r"""
(function(){
  function wavBlob(sec, sr) {
    var n = Math.floor(sec * sr), ch = 2, dataLen = n * ch * 2;
    var buf = new ArrayBuffer(44 + dataLen), v = new DataView(buf);
    function ws(o, s) { for (var i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); }
    ws(0, 'RIFF'); v.setUint32(4, 36 + dataLen, true); ws(8, 'WAVE');
    ws(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, ch, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * ch * 2, true);
    v.setUint16(32, ch * 2, true); v.setUint16(34, 16, true);
    ws(36, 'data'); v.setUint32(40, dataLen, true);
    var o = 44;
    for (var i = 0; i < n; i++) {
      var s = Math.sin(2 * Math.PI * 440 * i / sr) * 0.4;
      s = Math.max(-1, Math.min(1, s));
      v.setInt16(o, s * 32767, true); o += 2;
      v.setInt16(o, s * 32767, true); o += 2;
    }
    return new Blob([buf], {type: 'audio/wav'});
  }
  var file = new File([wavBlob(3, 48000)], 'perf.wav', {type: 'audio/wav'});
  var dt = new DataTransfer(); dt.items.add(file);
  var inp = document.getElementById('fileInput');
  inp.files = dt.files;
  inp.dispatchEvent(new Event('change', {bubbles: true}));
  window.__gen = 'ok';
})();
"""

SELECT_CLIP = r"""
(function(){
  var c = document.querySelector('#tracks .clip');
  if (!c) return 'no-clip';
  var r = c.getBoundingClientRect();
  var x = r.left + r.width / 2, y = r.top + r.height / 2;
  ['mousedown', 'mouseup', 'click'].forEach(function (t) {
    c.dispatchEvent(new MouseEvent(t, {bubbles: true, clientX: x, clientY: y}));
  });
  return 'ok';
})();
"""

# 逐个属性滑条：拖动 100 次 input（只该改显示）+ 1 次 change（才真正应用）
BENCH = r"""
(function(){
  var insp = document.getElementById('inspector');
  var fields = insp ? insp.querySelectorAll('.field') : [];
  var out = {fields: fields.length, rows: []};
  Array.prototype.forEach.call(fields, function (f) {
    var r = f.querySelector('input[type=range]');
    if (!r) return;
    var lbl = f.querySelector('.lbl span');
    var name = lbl ? lbl.textContent : '?';
    var lo = parseFloat(r.min), hi = parseFloat(r.max);
    if (!isFinite(lo) || !isFinite(hi) || hi <= lo) { out.rows.push({name: name, skip: true}); return; }
    var t0 = performance.now();
    for (var i = 0; i < 100; i++) {
      r.value = String(lo + (hi - lo) * (i % 100) / 100);
      r.dispatchEvent(new Event('input', {bubbles: true}));
    }
    var drag = performance.now() - t0;
    var t1 = performance.now();
    r.value = String((lo + hi) / 2);
    r.dispatchEvent(new Event('change', {bubbles: true}));
    var apply = performance.now() - t1;
    out.rows.push({name: name, drag100: +drag.toFixed(2), apply: +apply.toFixed(2)});
  });
  out.clips = document.querySelectorAll('#tracks .clip').length;
  out.tracks = document.querySelectorAll('#tracks .track-row').length;
  out.hasEnvelope = !!(window.QazrDSP && window.QazrDSP.envelopePeaks);
  return JSON.stringify(out);
})();
"""

# 缩放：一次「+」键 -> 一帧内重建所有片段，量到下一帧为止的墙钟时间
ZOOM = r"""
(function(){
  window.__zoom = null;
  var times = [], n = 0;
  function once(cb) {
    var t0 = performance.now();
    document.dispatchEvent(new KeyboardEvent('keydown', {key: '=', bubbles: true}));
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { cb(performance.now() - t0); });
    });
  }
  function step() {
    if (n >= 6) {
      var sum = times.reduce(function (a, b) { return a + b; }, 0);
      window.__zoom = JSON.stringify({
        samples: times.map(function (x) { return +x.toFixed(2); }),
        avg: +(sum / times.length).toFixed(2)
      });
      return;
    }
    n++;
    once(function (dt) { times.push(dt); step(); });
  }
  step();
})();
"""


def main():
    app = QApplication(sys.argv)
    view = QWebEngineView()
    view.resize(1500, 950)

    logs = []

    class Page(QWebEnginePage):
        def javaScriptConsoleMessage(self, level, msg, line, src):
            logs.append(f"{level}: {msg}")

    page = Page(view)
    view.setPage(page)
    view.settings().setAttribute(QWebEngineSettings.PlaybackRequiresUserGesture, False)
    view.show()
    view.load(QUrl.fromLocalFile(HTML))

    def js(code, cb=None):
        if cb is None:
            page.runJavaScript(code)
        else:
            page.runJavaScript(code, cb)

    def poll(expr, ok, fail_msg, tries=100, delay=150):
        state = {"n": tries}

        def step():
            js(f"(function(){{try{{return {expr};}}catch(e){{return null;}}}})()",
               lambda v: handle(v))

        def handle(v):
            if v not in (None, False, "", 0):
                ok(v)
                return
            state["n"] -= 1
            if state["n"] <= 0:
                print("  !! 超时：" + fail_msg)
                finish()
                return
            QTimer.singleShot(delay, step)

        QTimer.singleShot(delay, step)

    def finish():
        print("\n--- 页面日志 ---")
        print("\n".join(logs) if logs else "(无)")
        QTimer.singleShot(0, app.quit)

    def s1():
        print("[1] 页面加载完成")
        js(GEN_WAV)
        poll("window.__gen === 'ok'", s2, "生成 WAV 失败")

    def s2(_):
        print("[2] 已投喂 3 秒 WAV，等待解析出片段…")
        poll("document.querySelectorAll('#tracks .clip').length",
             s3, "导入后没有生成片段")

    def s3(n):
        print(f"[3] 片段数 = {n}")
        js(SELECT_CLIP, lambda r: (print("[4] 选中片段：", r),
                                   QTimer.singleShot(700, s4)))

    def s4():
        js("!!document.querySelector('#inspector input[type=range]')",
           lambda ok: (print("[5] 属性面板滑条存在：", ok), s5() if ok else finish()))

    def s5():
        js(BENCH, lambda v: (print("[6] 属性滑条：", v), s6()))

    def s6():
        js(ZOOM)
        poll("window.__zoom", lambda v: (print("[7] 缩放一帧：", v), finish()),
             "缩放测时没有返回")

    QTimer.singleShot(2500, s1)
    QTimer.singleShot(90000, lambda: (print("!! 总超时"), finish()))
    app.exec()


if __name__ == "__main__":
    main()
