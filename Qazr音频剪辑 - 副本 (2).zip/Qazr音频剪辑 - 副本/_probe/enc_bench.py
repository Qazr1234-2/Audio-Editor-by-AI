"""
测量 Python 侧编码耗时：不同格式、不同时长下 media.encode 要花多久。
如果一次导出要几十秒且界面冻结，用户看到的就是"卡在编码中不动"。
用法：py _probe\enc_bench.py
"""
import os
import sys
import time
import tempfile

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import media  # noqa: E402

TMP = os.path.join(tempfile.gettempdir(), "qazr_enc")
os.makedirs(TMP, exist_ok=True)

SR = 48000

print("=" * 72)
print("media.encode 耗时（立体声 48000 Hz）")
print("=" * 72)
print(f"  {'时长':>6s}  {'格式':>6s}  {'耗时':>10s}  {'产物':>10s}  {'实时倍率':>9s}")

for secs in (10, 60, 180):
    n = SR * secs
    t = np.linspace(0, secs, n, endpoint=False)
    pcm = np.stack([
        0.4 * np.sin(2 * np.pi * 220 * t),
        0.4 * np.sin(2 * np.pi * 330 * t),
    ]).astype(np.float32)

    for fmt in ("wav", "flac", "mp3", "m4a", "opus"):
        out = os.path.join(TMP, f"t{secs}_{fmt}{media.EXPORT_FORMATS[fmt][0]}")
        if os.path.exists(out):
            os.remove(out)
        t0 = time.perf_counter()
        try:
            media.encode(pcm, SR, out, fmt, bitrate=192)
            dt = time.perf_counter() - t0
            size = os.path.getsize(out)
            speed = secs / dt if dt > 0 else 0
            flag = "  <<< 慢" if dt > 5 else ""
            print(f"  {secs:>5d}s  {fmt:>6s}  {dt:>9.2f}s  {size/1024:>9.0f}K  "
                  f"{speed:>8.1f}×{flag}")
        except Exception as e:
            print(f"  {secs:>5d}s  {fmt:>6s}  {type(e).__name__}: {e}")

print()
print("=" * 72)
print("解析：用户在界面上看到的是「正在交给 Python 编码…」，")
print("      如果这里要几十秒且主线程被占住，就等同于卡死不动。")
print("=" * 72)
