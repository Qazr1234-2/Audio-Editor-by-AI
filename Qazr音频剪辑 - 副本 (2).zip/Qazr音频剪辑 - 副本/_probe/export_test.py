"""
导出链路诊断：在真实 QtWebEngine 里跑一遍「上传混音 -> 调 Python 导出」，
逐步打印进度，定位到底卡在哪一步。
原生保存对话框会被打桩替换成固定路径，以便自动化。
用法：py _probe\\export_test.py
"""
import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from PySide6.QtWidgets import QApplication, QFileDialog

OUT_PATH = os.path.join(tempfile.gettempdir(), "qazr_export_test.mp3")
if os.path.exists(OUT_PATH):
    os.remove(OUT_PATH)

# 打桩：跳过原生保存框
_orig = QFileDialog.getSaveFileName
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (OUT_PATH, ""))

from PySide6.QtCore import QTimer                      # noqa: E402
from app.main import MainWindow                        # noqa: E402
from app.server import LocalServer, MediaStore         # noqa: E402
import secrets                                         # noqa: E402

STAGES = []


def log(s):
    STAGES.append(s)
    print(s, flush=True)


def main():
    app = QApplication(sys.argv)

    store = MediaStore()
    token = secrets.token_urlsafe(12)
    server = LocalServer(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")),
                         store, token).start()
    win = MainWindow(store, server, [])
    win.show()

    def js(code, cb):
        win.view.page().runJavaScript(code, cb)

    def poll(expr, ok_cb, fail_msg, tries=140, delay=120):
        state = {"n": tries}

        def step():
            js(f"(function(){{try{{return {expr};}}catch(e){{return null;}}}})()",
               lambda v: handle(v))

        def handle(v):
            if v not in (None, False, "", 0):
                ok_cb(v)
                return
            state["n"] -= 1
            if state["n"] <= 0:
                log(f"  !! 超时：{fail_msg}")
                finish()
                return
            QTimer.singleShot(delay, step)

        QTimer.singleShot(delay, step)

    def finish():
        log("")
        log("=" * 66)
        if os.path.exists(OUT_PATH):
            log(f"产物已生成: {OUT_PATH}  {os.path.getsize(OUT_PATH)} B")
        else:
            log("没有生成任何文件")
        QTimer.singleShot(0, app.quit)

    def stage1():
        log("[1] 等待前端桥接就绪…")
        poll("window.QazrPy && window.QazrPy.ready", stage2, "桥接一直没就绪")

    def stage2(_):
        log("[2] 桥接就绪，开始上传混音（10 秒立体声）…")
        js("(function(){"
           "  var sr=48000, n=sr*10;"
           "  var L=new Float32Array(n), R=new Float32Array(n);"
           "  for(var i=0;i<n;i++){L[i]=0.4*Math.sin(2*Math.PI*220*i/sr);"
           "                       R[i]=0.4*Math.sin(2*Math.PI*330*i/sr);}"
           "  window.__up='';"
           "  QazrPy.uploadPcm([L,R], sr)"
           "    .then(function(id){ window.__up = id || 'EMPTY'; })"
           "    .catch(function(e){ window.__up = 'ERR:' + e; });"
           "})();", lambda _: None)
        poll("window.__up", stage3, "上传一直没有返回（上传接口卡住）")

    def stage3(v):
        log(f"[3] 上传返回: {v}")
        if str(v).startswith("ERR") or v == "EMPTY":
            log("  !! 上传失败，导出链路断在这一步")
            finish()
            return
        log("[4] 调用 Python 导出（原生保存框已打桩）…")
        js("(function(){"
           "  window.__exp='';"
           "  try {"
           "    QazrPy.exportAudio(window.__up, 'mp3', 192, 'export_test', function(r){"
           "      window.__exp = JSON.stringify(r); });"
           "  } catch(e) { window.__exp = 'THROW:' + e; }"
           "})();", lambda _: None)
        poll("window.__exp", stage5, "导出回调一直没有返回（Python 侧卡住）")

    def stage5(v):
        log(f"[5] 导出回调: {v}")
        finish()

    # MainWindow 构造时已经 load 了页面，这里直接开始轮询即可
    QTimer.singleShot(600, stage1)

    QTimer.singleShot(90000, lambda: (log("!! 总超时"), finish()))
    app.exec()
    server.stop()
    QFileDialog.getSaveFileName = _orig


if __name__ == "__main__":
    main()
