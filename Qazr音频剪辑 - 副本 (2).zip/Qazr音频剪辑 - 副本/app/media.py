"""
Qazr 音频剪辑 — Python 媒体层（PyAV / ffmpeg）

职责：把任意音视频文件解码成 numpy PCM，以及把 PCM 编码成任意格式。
这是「Python 音频引擎」的核心：浏览器做不到的 mp4 / mkv / avi / wmv 等
容器，全部由这里用 ffmpeg 处理。

约定：
    PCM 一律是 float32、形状 (声道数, 采样数)、取值范围 [-1, 1]、
    保持文件原始采样率（不重采样，交给浏览器混音时处理）。
"""

from __future__ import annotations

import os
import re
import numpy as np

import av

# ---------------------------------------------------------------- 常量

# 可直接导入的扩展名（PyAV/ffmpeg 能解的）
IMPORT_EXTS = (
    # 音频
    ".wav", ".wave", ".mp3", ".mp2", ".mpga", ".ogg", ".oga", ".opus",
    ".flac", ".m4a", ".m4b", ".aac", ".weba", ".aiff", ".aif", ".aifc",
    ".au", ".snd", ".caf", ".wma", ".asf", ".ape", ".wv", ".amr",
    # 视频（只取音轨）
    ".mp4", ".m4v", ".mov", ".qt", ".webm", ".mkv", ".ogv", ".avi",
    ".wmv", ".flv", ".f4v", ".ts", ".mts", ".m2ts", ".mpg", ".mpeg",
    ".vob", ".3gp", ".3g2", ".rm", ".rmvb", ".asf", ".divx",
)

VIDEO_EXTS = (
    ".mp4", ".m4v", ".mov", ".qt", ".webm", ".mkv", ".ogv", ".avi",
    ".wmv", ".flv", ".f4v", ".ts", ".mts", ".m2ts", ".mpg", ".mpeg",
    ".vob", ".3gp", ".3g2", ".rm", ".rmvb", ".divx",
)

def _has_encoder(name: str) -> bool:
    """检查当前 ffmpeg 构建是否带某个编码器"""
    try:
        from av.codec import codecs_available
        return name in codecs_available
    except Exception:
        try:
            return av.codec.Codec(name, "w") is not None
        except Exception:
            return False


_HAS_VORBIS = _has_encoder("libvorbis")

# 导出格式表： key -> (扩展名, 容器, 编码器, 是否无损, 说明)
EXPORT_FORMATS = {
    "wav":   (".wav",  "wav",      "pcm_s16le", True,  "WAV 无损 PCM，兼容一切软件"),
    "wav24": (".wav",  "wav",      "pcm_s24le", True,  "WAV 24-bit 无损，母带级"),
    "wav32": (".wav",  "wav",      "pcm_f32le", True,  "WAV 32-bit 浮点无损"),
    "aiff":  (".aiff", "aiff",     "pcm_s16be", True,  "AIFF 无损，macOS / 专业软件通用"),
    "flac":  (".flac", "flac",     "flac",      True,  "FLAC 无损压缩，体积约为 WAV 一半"),
    "mp3":   (".mp3",  "mp3",      "libmp3lame", False, "MP3 兼容性最广"),
    "m4a":   (".m4a",  "mp4",      "aac",       False, "M4A / AAC，苹果生态默认"),
    "opus":  (".opus", "ogg",      "libopus",   False, "OGG Opus，同音质体积最小"),
    "ogg":   (".ogg",  "ogg",      "libvorbis" if _HAS_VORBIS else "libopus", False, "OGG"),
    "mka":   (".mka",  "matroska", "libopus",   False, "Matroska 音频"),
}

FLOAT_FMTS = ("fltp", "flt", "f32", "f32p", "dbl", "dblp", "s16p", "s32p")


# ---------------------------------------------------------------- 工具

def is_video(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in VIDEO_EXTS


def can_import(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in IMPORT_EXTS


EXPORT_NAMES = {
    "wav":   "WAV 16-bit",
    "wav24": "WAV 24-bit",
    "wav32": "WAV 32-bit 浮点",
    "aiff":  "AIFF 无损",
    "flac":  "FLAC 无损压缩",
    "mp3":   "MP3",
    "m4a":   "M4A / AAC",
    "opus":  "OGG Opus",
    "ogg":   "OGG",
    "mka":   "Matroska 音频",
}


def available_exports() -> list[dict]:
    """返回当前 ffmpeg 构建真正可用的导出格式清单"""
    out = []
    for key, (ext, container, codec, lossless, desc) in EXPORT_FORMATS.items():
        if _has_encoder(codec):
            out.append({
                "key": key, "ext": ext.lstrip("."), "codec": codec,
                "lossless": lossless, "desc": desc,
                "name": EXPORT_NAMES.get(key, key),
            })
    return out


# ---------------------------------------------------------------- 解码

def _frame_to_float(frame: av.AudioFrame) -> np.ndarray:
    """把任意格式的音频帧转成 float32 (ch, n)"""
    arr = frame.to_ndarray()
    if arr.ndim == 1:
        arr = arr[None, :]
    arr = arr.astype(np.float32)
    fmt = frame.format.name
    if fmt in FLOAT_FMTS:
        # s16p / s32p 仍是整数，需要缩放
        if fmt == "s16p":
            arr = arr / 32768.0
        elif fmt == "s32p":
            arr = arr / 2147483648.0
        return arr
    m = re.search(r"[su](\d+)", fmt or "")
    if m:
        bits = int(m.group(1))
        if fmt.startswith("u"):
            arr = (arr - float(1 << (bits - 1))) / float(1 << (bits - 1))
        else:
            arr = arr / float(1 << (bits - 1))
    return arr


def decode(path: str, max_seconds: float | None = None) -> tuple[np.ndarray, int, dict]:
    """
    解码任意音视频文件的音轨。

    返回 (pcm, sample_rate, info)
        pcm          float32 (channels, samples)
        sample_rate  原始采样率
        info         {channels, sample_rate, duration, frames, codec, container, has_video, source}
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    with av.open(path) as container:
        astreams = [s for s in container.streams if s.type == "audio"]
        if not astreams:
            raise ValueError("这个文件里没有音轨")
        # 选声道数最多、码率最高的音轨
        stream = max(
            astreams,
            key=lambda s: (s.codec_context.channels or 0, s.bit_rate or 0),
        )

        resampler = av.AudioResampler(
            format="fltp",
            layout=stream.codec_context.layout.name or "stereo",
            rate=stream.codec_context.sample_rate,
        )

        chunks: list[np.ndarray] = []
        total = 0
        limit = int(max_seconds * stream.codec_context.sample_rate) if max_seconds else None

        for frame in container.decode(stream):
            for res in resampler.resample(frame):
                data = _frame_to_float(res)
                chunks.append(data)
                total += data.shape[1]
            if limit and total >= limit:
                break
        # 冲刷重采样器
        try:
            for res in resampler.resample(None):
                data = _frame_to_float(res)
                chunks.append(data)
                total += data.shape[1]
        except Exception:
            pass

        if not chunks:
            raise ValueError("解码后没有得到任何音频数据")

        pcm = np.concatenate(chunks, axis=1)
        if limit and pcm.shape[1] > limit:
            pcm = pcm[:, :limit]

        sr = stream.codec_context.sample_rate
        duration = pcm.shape[1] / float(sr)
        channels = pcm.shape[0]

        info = {
            "channels": channels,
            "sample_rate": sr,
            "duration": duration,
            "frames": int(pcm.shape[1]),
            "codec": stream.codec_context.name,
            "container": container.format.name,
            "has_video": any(s.type == "video" for s in container.streams),
            "source": os.path.basename(path),
        }
        return pcm, sr, info


# ---------------------------------------------------------------- 编码

def _make_frame(pcm: np.ndarray, sr: int, codec: str) -> av.AudioFrame:
    """按编码器需要的样本格式构造 AudioFrame"""
    ch = pcm.shape[0]
    layout = {1: "mono", 2: "stereo"}.get(ch, "stereo")

    if codec in ("pcm_s16le", "pcm_s16be"):
        packed = np.clip(pcm.T, -1.0, 1.0)
        packed = (packed * 32767.0).astype(np.int16).reshape(1, -1)
        fr = av.AudioFrame.from_ndarray(packed, format="s16", layout=layout)
    elif codec == "pcm_s24le":
        # ffmpeg 对 pcm_s24le 的帧格式是 s32（只用高 24 位），
        # 因此要按 32 位满刻度缩放，而不是 24 位满刻度
        packed = np.clip(pcm.T, -1.0, 1.0)
        packed = (packed * 2147483647.0).astype(np.int32).reshape(1, -1)
        fr = av.AudioFrame.from_ndarray(packed, format="s32", layout=layout)
    elif codec == "pcm_f32le":
        # 打包格式需要交错展平成 (1, 采样数 × 声道数)
        packed = np.clip(pcm.T, -1.0, 1.0).astype(np.float32).reshape(1, -1)
        fr = av.AudioFrame.from_ndarray(packed, format="flt", layout=layout)
    else:
        fr = av.AudioFrame.from_ndarray(
            np.ascontiguousarray(pcm, dtype=np.float32), format="fltp", layout=layout)
    fr.sample_rate = sr
    return fr


def encode(pcm: np.ndarray, sr: int, path: str, fmt_key: str,
           bitrate: int = 192, chunk: int = 48000) -> str:
    """
    把 PCM 编码写入 path。fmt_key 见 EXPORT_FORMATS。
    分块编码，避免长音频一次性占用过多内存。
    """
    if fmt_key not in EXPORT_FORMATS:
        raise ValueError(f"未知的导出格式：{fmt_key}")
    ext, container, codec, _lossless, _desc = EXPORT_FORMATS[fmt_key]

    if not _has_encoder(codec):
        raise ValueError(f"当前编码器不支持 {fmt_key}（缺少 {codec}）")

    # 目标容器由容器名决定；容器名可用时按它写
    out_fmt = container
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)

    with av.open(path, "w", format=out_fmt) as out:
        stream = out.add_stream(codec, rate=sr)
        stream.layout = {1: "mono", 2: "stereo"}.get(pcm.shape[0], "stereo")
        try:
            stream.bit_rate = bitrate * 1000
        except Exception:
            pass

        total = pcm.shape[1]
        for start in range(0, total, chunk):
            piece = pcm[:, start:start + chunk]
            frame = _make_frame(piece, sr, codec)
            for pkt in stream.encode(frame):
                out.mux(pkt)
        for pkt in stream.encode(None):          # 冲刷
            out.mux(pkt)

    return path


def to_float32_bytes(pcm: np.ndarray) -> bytes:
    """(ch, n) -> 交错 float32 小端字节流（给浏览器）"""
    inter = np.ascontiguousarray(pcm.T, dtype="<f4")
    return inter.tobytes()


def from_float32_bytes(raw: bytes, channels: int, frames: int) -> np.ndarray:
    """交错 float32 小端字节流 -> (ch, n)"""
    arr = np.frombuffer(raw, dtype="<f4")
    if arr.size != channels * frames:
        raise ValueError(f"数据长度不符：收到 {arr.size}，期望 {channels * frames}")
    return np.ascontiguousarray(arr.reshape(frames, channels).T)


def peaks(pcm: np.ndarray, buckets: int = 2000) -> list[list[float]]:
    """每声道的最小/最大包络，供前端画波形"""
    ch, n = pcm.shape
    if n == 0:
        return [[0.0, 0.0] for _ in range(ch)]
    buckets = max(1, min(buckets, n))
    edges = np.linspace(0, n, buckets + 1).astype(np.int64)
    out = []
    for c in range(ch):
        d = pcm[c]
        mins = np.empty(buckets, dtype=np.float32)
        maxs = np.empty(buckets, dtype=np.float32)
        for i in range(buckets):
            a, b = edges[i], max(edges[i] + 1, edges[i + 1])
            seg = d[a:b]
            mins[i] = seg.min()
            maxs[i] = seg.max()
        out.append([mins, maxs])
    return out
