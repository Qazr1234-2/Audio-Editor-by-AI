"""
Qazr 音频剪辑 — 桌面版

界面仍是现有的 HTML / CSS（在 QtWebEngine 里渲染），
音频解码与编码改由 Python + ffmpeg（PyAV）负责。
"""

__version__ = "1.0.0"
