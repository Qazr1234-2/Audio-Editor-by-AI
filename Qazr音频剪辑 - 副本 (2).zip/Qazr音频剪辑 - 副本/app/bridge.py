"""
Qazr 音频剪辑 — 前后端桥

前端通过本地回环 HTTP 调用这里的方法（路由见 server.py 的 /api/*）。
要弹原生对话框的方法必须在 Qt 主线程执行，由 server.UiInvoker 负责搬运；
解码 / 编码这类耗时活儿留在 HTTP 工作线程里跑，别占着界面线程。
"""

from __future__ import annotations

import os
import subprocess
import sys

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices

from . import media
from .server import MediaStore


class Bridge:
    def __init__(self, window, store: MediaStore):
        self._win = window
        self._store = store

    # ------------------------------------------------------------ 能力

    def caps(self) -> dict:
        return {
            "exports": media.available_exports(),
            "import_exts": list(media.IMPORT_EXTS),
            "video_exts": list(media.VIDEO_EXTS),
            "platform": sys.platform,
        }

    # ------------------------------------------------------------ 导入

    def ask_open_paths(self) -> list[str]:
        """弹原生文件选择框。必须在主线程调用。"""
        from PySide6.QtWidgets import QFileDialog

        exts = " ".join("*" + e for e in media.IMPORT_EXTS)
        paths, _ = QFileDialog.getOpenFileNames(
            self._win,
            "导入音频 / 视频",
            "",
            f"所有支持的媒体 (*{exts});;所有文件 (*.*)",
        )
        return list(paths or [])

    def load_paths(self, paths: list[str]) -> dict:
        """解码若干文件并存入 store，返回给前端的元数据列表"""
        items, failed = [], []
        for p in paths:
            if not media.can_import(p):
                failed.append({"name": os.path.basename(p), "error": "不支持的扩展名"})
                continue
            try:
                pcm, sr, info = media.decode(p)
                mid = self._store.put(pcm, sr, info)
                items.append({
                    "id": mid,
                    "name": os.path.basename(p),
                    "path": p,
                    "channels": pcm.shape[0],
                    "sample_rate": sr,
                    "frames": int(pcm.shape[1]),
                    "duration": float(pcm.shape[1] / sr),
                    "codec": info.get("codec", ""),
                    "container": info.get("container", ""),
                    "has_video": bool(info.get("has_video")),
                })
            except Exception as e:
                failed.append({"name": os.path.basename(p), "error": f"{type(e).__name__}: {e}"})
        return {"items": items, "failed": failed}

    # ------------------------------------------------------------ 导出

    def ask_save_path(self, fmt_key: str, default_name: str) -> str | None:
        """弹原生保存框，返回最终路径；取消则返回 None。必须在主线程调用。"""
        from PySide6.QtWidgets import QFileDialog

        ext = media.EXPORT_FORMATS.get(fmt_key, ("",))[0] or ".wav"

        safe = (default_name or "Qazr-混音导出").strip() or "Qazr-混音导出"
        for ch in '\\/:*?"<>|':
            safe = safe.replace(ch, "_")
        suggested = os.path.join(os.path.expanduser("~"), "Music", safe + ext)
        if not os.path.isdir(os.path.dirname(suggested)):
            suggested = os.path.join(os.path.expanduser("~"), safe + ext)

        path, _ = QFileDialog.getSaveFileName(
            self._win, "导出音频", suggested, f"*{ext};;所有文件 (*.*)")
        if not path:
            return None
        if not path.lower().endswith(ext.lower()):
            path += ext
        return path

    def export_to(self, mid: str, fmt_key: str, bitrate: int, path: str) -> dict:
        """把 store 里的混音编码写入 path。可以在工作线程里跑。"""
        item = self._store.get(mid)
        if not item:
            return {"error": "混音数据已失效，请重新导出"}
        pcm, sr, _info = item
        media.encode(pcm, sr, path, fmt_key, bitrate=bitrate or 192)
        size = os.path.getsize(path)
        self._store.drop(mid)
        return {"path": path, "size": size, "fmt": fmt_key}

    # ------------------------------------------------------------ 系统交互

    def reveal(self, path: str) -> None:
        """在资源管理器里定位文件"""
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
        except Exception:
            pass

    def open_url(self, url: str) -> None:
        QDesktopServices.openUrl(QUrl(url))
