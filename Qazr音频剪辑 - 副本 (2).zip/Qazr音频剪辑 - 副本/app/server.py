"""
Qazr 音频剪辑 — 本地传输层

浏览器（QtWebEngine）与 Python 之间搬运大块 PCM 数据用 HTTP，
比走 WebChannel 的 JSON 序列化快得多，也不会把几十 MB 的
浮点数组变成 base64 字符串。

只绑定 127.0.0.1，并要求每次请求都带上启动时随机生成的 token。

路由：
    GET  /                  -> index.html
    GET  /<静态文件>         -> 项目里的 css/js 等
    GET  /api/audio/<id>    -> 交错 float32 小端 PCM（头部带采样率/声道数）
    POST /api/pcm           -> 前端上传渲染好的混音，返回 {id}
    GET  /api/caps          -> 导出格式等能力清单
    GET  /api/open-media    -> 弹原生文件框并导入
    POST /api/load-paths    -> 按路径导入（拖拽入窗 / 命令行传入）
    POST /api/export        -> 弹原生保存框并编码写盘
    POST /api/reveal        -> 在资源管理器里定位文件

原生对话框必须在 Qt 主线程执行，而 HTTP 请求跑在工作线程，
所以这里用 UiInvoker 把对话框调用搬回主线程。
"""

from __future__ import annotations

import json
import os
import threading
import mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

import numpy as np
from PySide6.QtCore import QObject, Signal, Qt

from . import media


class UiInvoker(QObject):
    """把工作线程里的调用搬到 Qt 主线程执行，并同步等待结果。

    Qt 的原生对话框只能在 GUI 线程里弹；HTTP 处理跑在别的线程，
    所以这里用队列信号切回主线程，再用 Event 把结果带回来。
    """

    _request = Signal(object)

    def __init__(self):
        super().__init__()
        self._request.connect(self._run, Qt.QueuedConnection)

    def _run(self, payload):
        fn, args, kwargs, box, done = payload
        try:
            box["value"] = fn(*args, **kwargs)
        except BaseException as e:              # noqa: BLE001
            box["error"] = e
        finally:
            done.set()

    def call(self, fn, *args, timeout: float = 600.0, **kwargs):
        box: dict = {}
        done = threading.Event()
        self._request.emit((fn, args, kwargs, box, done))
        if not done.wait(timeout):
            raise TimeoutError("主线程没有在预期时间内响应")
        if "error" in box:
            raise box["error"]
        return box.get("value")


class MediaStore:
    """内存 PCM 仓库：前后端用 id 交换数据"""

    def __init__(self, limit: int = 24):
        self._items: dict[str, dict] = {}
        self._lock = threading.Lock()
        self._seq = 0
        self._limit = limit

    def put(self, pcm: np.ndarray, sr: int, info: dict | None = None) -> str:
        with self._lock:
            self._seq += 1
            mid = f"m{self._seq:x}"
            self._items[mid] = {"pcm": pcm, "sr": sr, "info": info or {}}
            # 超出上限时丢弃最旧的
            while len(self._items) > self._limit:
                self._items.pop(next(iter(self._items)))
            return mid

    def get(self, mid: str):
        with self._lock:
            item = self._items.get(mid)
        if not item:
            return None
        return item["pcm"], item["sr"], item["info"]

    def drop(self, mid: str) -> None:
        with self._lock:
            self._items.pop(mid, None)

    def clear(self) -> None:
        with self._lock:
            self._items.clear()


def _make_handler(ui_root: str, store: MediaStore, token: str, state: dict):
    class Handler(BaseHTTPRequestHandler):
        server_version = "QazrLocal/1.0"

        def log_message(self, *args):        # 静音，别刷控制台
            pass

        # ------------------------------------------------ 工具

        def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, str(v))
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def _json(self, code: int, obj) -> None:
            self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                       "application/json; charset=utf-8")

        def _authorised(self, q: dict) -> bool:
            got = (q.get("t") or [""])[0]
            return got == token

        def _bridge(self):
            b = state.get("bridge")
            if b is None:
                self._json(503, {"error": "桥接尚未就绪"})
                return None
            return b

        def _invoke(self, fn, *args):
            """把调用搬到 Qt 主线程执行"""
            invoker = state.get("invoker")
            if invoker is None:
                raise RuntimeError("主线程调度器不可用")
            return invoker.call(fn, *args)

        # ------------------------------------------------ GET

        def do_GET(self):
            u = urlparse(self.path)
            path = u.path
            q = parse_qs(u.query)

            if path.startswith("/api/"):
                if not self._authorised(q):
                    self._json(403, {"error": "token 无效"})
                    return
                if path == "/api/caps":
                    b = self._bridge()
                    if b is None:
                        return
                    try:
                        self._json(200, b.caps())
                    except Exception as e:
                        self._json(500, {"error": f"{type(e).__name__}: {e}"})
                    return
                if path == "/api/open-media":
                    b = self._bridge()
                    if b is None:
                        return
                    try:
                        paths = self._invoke(b.ask_open_paths)
                        if not paths:
                            self._json(200, {"cancelled": True})
                        else:
                            self._json(200, b.load_paths(paths))
                    except Exception as e:
                        self._json(500, {"error": f"{type(e).__name__}: {e}"})
                    return
                if path.startswith("/api/audio/"):
                    mid = path[len("/api/audio/"):]
                    item = store.get(mid)
                    if not item:
                        self._json(404, {"error": "找不到该音频"})
                        return
                    pcm, sr, info = item
                    body = media.to_float32_bytes(pcm)
                    self._send(200, body, "application/octet-stream", {
                        "X-Sample-Rate": sr,
                        "X-Channels": pcm.shape[0],
                        "X-Frames": pcm.shape[1],
                        "X-Info": json.dumps(info, ensure_ascii=False),
                    })
                    return
                self._json(404, {"error": "未知接口"})
                return

            # 静态资源
            rel = path.lstrip("/") or "index.html"
            full = os.path.normpath(os.path.join(ui_root, rel))
            if not full.startswith(os.path.normpath(ui_root)):
                self._json(403, {"error": "越界路径"})
                return
            if not os.path.isfile(full):
                self._json(404, {"error": "文件不存在：" + rel})
                return
            ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
            if full.endswith(".js"):
                ctype = "text/javascript; charset=utf-8"
            elif full.endswith(".css"):
                ctype = "text/css; charset=utf-8"
            elif full.endswith(".html"):
                ctype = "text/html; charset=utf-8"
            with open(full, "rb") as f:
                self._send(200, f.read(), ctype)

        # ------------------------------------------------ POST

        def do_POST(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if not self._authorised(q):
                self._json(403, {"error": "token 无效"})
                return

            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0:
                self._json(400, {"error": "没有数据"})
                return

            # 分块读取，避免一次性分配过大内存
            buf = bytearray()
            remaining = length
            while remaining > 0:
                chunk = self.rfile.read(min(1 << 20, remaining))
                if not chunk:
                    break
                buf += chunk
                remaining -= len(chunk)

            if u.path == "/api/pcm":
                try:
                    ch = int((q.get("ch") or ["0"])[0])
                    frames = int((q.get("frames") or ["0"])[0])
                    sr = int((q.get("sr") or ["48000"])[0])
                    pcm = media.from_float32_bytes(bytes(buf), ch, frames)
                    mid = store.put(pcm, sr, {"channels": ch, "sample_rate": sr,
                                              "frames": frames, "duration": frames / sr})
                    self._json(200, {"id": mid, "channels": ch, "frames": frames, "sr": sr})
                except Exception as e:
                    self._json(400, {"error": f"{type(e).__name__}: {e}"})
                return

            if u.path in ("/api/load-paths", "/api/export", "/api/reveal"):
                b = self._bridge()
                if b is None:
                    return
                try:
                    body = json.loads(bytes(buf).decode("utf-8") or "{}")
                except Exception as e:
                    self._json(400, {"error": f"请求体不是合法 JSON：{e}"})
                    return

                try:
                    if u.path == "/api/load-paths":
                        self._json(200, b.load_paths(body.get("paths") or []))
                        return
                    if u.path == "/api/export":
                        mid = str(body.get("id") or "")
                        fmt_key = str(body.get("fmt") or "wav")
                        bitrate = int(body.get("bitrate") or 192)
                        name = str(body.get("name") or "")
                        # 保存对话框必须在主线程弹
                        path = self._invoke(b.ask_save_path, fmt_key, name)
                        if not path:
                            self._json(200, {"cancelled": True})
                        else:
                            # 编码很吃 CPU，放在工作线程里跑
                            self._json(200, b.export_to(mid, fmt_key, bitrate, path))
                        return
                    # /api/reveal
                    self._invoke(b.reveal, str(body.get("path") or ""))
                    self._json(200, {"ok": True})
                    return
                except Exception as e:
                    self._json(500, {"error": f"{type(e).__name__}: {e}"})
                    return

            self._json(404, {"error": "未知接口"})

    return Handler


class LocalServer:
    def __init__(self, ui_root: str, store: MediaStore, token: str):
        self.ui_root = os.path.abspath(ui_root)
        self.store = store
        self.token = token
        self._state: dict = {"bridge": None, "invoker": None}
        self.httpd = ThreadingHTTPServer(
            ("127.0.0.1", 0), _make_handler(self.ui_root, store, token, self._state))
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self._thread = None

    def attach(self, bridge, invoker=None) -> None:
        """接上前端桥。invoker 缺省时自己造一个（必须在主线程调用）"""
        self._state["bridge"] = bridge
        self._state["invoker"] = invoker or UiInvoker()

    def start(self):
        self._thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self._thread.start()
        return self

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def index_url(self) -> str:
        return f"{self.base_url}/index.html?t={self.token}"

    def stop(self):
        try:
            self.httpd.shutdown()
        except Exception:
            pass
