"""
Qazr 音频剪辑 — 桌面版入口

结构：
    PySide6 原生窗口
      └─ QWebEngineView（Chromium）渲染现有 HTML 界面
    Python 侧负责音频解码/编码（PyAV / ffmpeg），
    大块 PCM 通过本地回环 HTTP 传输，控制指令走 QWebChannel。

用法：
    py -m app.main              # 直接运行
    py -m app.main 某文件.mp4    # 带文件启动
"""

from __future__ import annotations

import os
import secrets
import sys
import ctypes

# QtWebEngine 必须在 QApplication 之前导入
from PySide6.QtWebEngineWidgets import QWebEngineView          # noqa: E402
from PySide6.QtWebEngineCore import QWebEngineSettings, QWebEngineScript  # noqa: E402
from PySide6.QtWidgets import QApplication, QMainWindow, QMessageBox  # noqa: E402
from PySide6.QtCore import QUrl, Qt, QTimer, QSize, QCoreApplication  # noqa: E402
from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QLinearGradient, QAction  # noqa: E402

from . import media
from .server import LocalServer, MediaStore
from .bridge import Bridge

APP_NAME = "Qazr 音频剪辑"


def resource_root() -> str:
    """前端资源目录：打包后在 _MEIPASS，开发时是项目根目录"""
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def make_icon() -> QIcon:
    """用代码画一个图标，省得带外部资源"""
    icon = QIcon()
    for size in (16, 24, 32, 48, 64, 128, 256):
        pm = QPixmap(size, size)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        r = size * 0.22
        g = QLinearGradient(0, 0, size, size)
        g.setColorAt(0.0, QColor("#2e9bff"))
        g.setColorAt(1.0, QColor("#0059c8"))
        p.setBrush(g)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(0, 0, size, size, r, r)
        # 画一条波形
        p.setPen(QColor(255, 255, 255, 235))
        w = max(1.0, size * 0.075)
        p.setBrush(QColor(255, 255, 255, 235))
        bars = [0.42, 0.72, 0.30, 0.88, 0.52, 0.66, 0.38]
        bw = size * 0.085
        gap = (size - len(bars) * bw) / (len(bars) + 1)
        for i, h in enumerate(bars):
            bh = size * h * 0.62
            x = gap + i * (bw + gap)
            y = (size - bh) / 2
            p.drawRoundedRect(x, y, bw, bh, bw / 2, bw / 2)
        p.end()
        icon.addPixmap(pm)
    return icon


class MainWindow(QMainWindow):
    def __init__(self, store: MediaStore, server: LocalServer, initial_files: list[str]):
        super().__init__()
        self._server = server
        self._store = store
        self._initial = initial_files

        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(make_icon())
        self.resize(1440, 900)
        self.setMinimumSize(1040, 660)

        self.view = QWebEngineView(self)
        self.setCentralWidget(self.view)

        # 文件拖拽交给 Qt 主窗口处理（网页拿不到本地路径）
        self.view.setAcceptDrops(False)
        self.setAcceptDrops(True)

        self._setup_channel()
        self._build_menu()

        self.view.load(QUrl(server.index_url))
        self.view.loadFinished.connect(self._on_loaded)

    # ------------------------------------------------------------ 初始化

    def _setup_channel(self):
        # 桥接走本地 HTTP（见 server.py 的 /api/*）。
        # 之前用的 QWebChannel 依赖 qrc:///qtwebchannel/qwebchannel.js，
        # 这个 PySide6 构建里拿不到，所以整条链路一直没就绪。
        self.bridge = Bridge(self, self._store)
        self._server.attach(self.bridge)

        # 注入桌面版专用样式：关掉 backdrop-filter，避免 QtWebEngine 重绘闪动
        css_path = os.path.join(resource_root(), "css", "desktop-qt.css")
        if os.path.isfile(css_path):
            with open(css_path, "r", encoding="utf-8") as f:
                css = f.read()
            sc = QWebEngineScript()
            sc.setName("qazr-desktop-css")
            sc.setSourceCode(
                "(function(){var s=document.createElement('style');"
                "s.setAttribute('data-qazr','desktop');"
                "s.textContent=" + __import__("json").dumps(css) + ";"
                "(document.head||document.documentElement).appendChild(s);})();")
            sc.setInjectionPoint(QWebEngineScript.DocumentReady)
            sc.setWorldId(QWebEngineScript.MainWorld)
            sc.setRunsOnSubFrames(False)
            self.view.page().scripts().insert(sc)

        # 把前端桥接脚本注入到页面最前面
        js_path = os.path.join(resource_root(), "js", "pybridge.js")
        if os.path.isfile(js_path):
            with open(js_path, "r", encoding="utf-8") as f:
                src = f.read()
            script = QWebEngineScript()
            script.setName("qazr-pybridge")
            script.setSourceCode(src)
            script.setInjectionPoint(QWebEngineScript.DocumentCreation)
            script.setWorldId(QWebEngineScript.MainWorld)
            script.setRunsOnSubFrames(False)
            self.view.page().scripts().insert(script)

        s = self.view.settings()
        s.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        s.setAttribute(QWebEngineSettings.PlaybackRequiresUserGesture, False)
        s.setAttribute(QWebEngineSettings.JavascriptCanAccessClipboard, True)
        s.setAttribute(QWebEngineSettings.ShowScrollBars, False)
        s.setAttribute(QWebEngineSettings.FocusOnNavigationEnabled, True)

    def _build_menu(self):
        bar = self.menuBar()

        m_file = bar.addMenu("文件")
        a_import = QAction("导入音频 / 视频…", self)
        a_import.setShortcut("Ctrl+O")
        a_import.triggered.connect(lambda: self._call_js("QazrPy && QazrPy.openMedia()"))
        m_file.addAction(a_import)

        a_export = QAction("导出…", self)
        a_export.setShortcut("Ctrl+E")
        a_export.triggered.connect(lambda: self._call_js("QazrPy && QazrPy.exportDialog()"))
        m_file.addAction(a_export)

        m_file.addSeparator()
        a_quit = QAction("退出", self)
        a_quit.setShortcut("Ctrl+Q")
        a_quit.triggered.connect(self.close)
        m_file.addAction(a_quit)

        m_view = bar.addMenu("视图")
        a_reload = QAction("重新加载界面", self)
        a_reload.setShortcut("F5")
        a_reload.triggered.connect(self.view.reload)
        m_view.addAction(a_reload)
        a_zoom_in = QAction("放大", self)
        a_zoom_in.setShortcut("Ctrl+=")
        a_zoom_in.triggered.connect(lambda: self.view.setZoomFactor(min(3.0, self.view.zoomFactor() + 0.1)))
        m_view.addAction(a_zoom_in)
        a_zoom_out = QAction("缩小", self)
        a_zoom_out.setShortcut("Ctrl+-")
        a_zoom_out.triggered.connect(lambda: self.view.setZoomFactor(max(0.5, self.view.zoomFactor() - 0.1)))
        m_view.addAction(a_zoom_out)
        a_zoom_reset = QAction("实际大小", self)
        a_zoom_reset.setShortcut("Ctrl+0")
        a_zoom_reset.triggered.connect(lambda: self.view.setZoomFactor(1.0))
        m_view.addAction(a_zoom_reset)
        m_view.addSeparator()
        a_dev = QAction("打开开发者工具", self)
        a_dev.setShortcut("F12")
        a_dev.triggered.connect(self._open_devtools)
        m_view.addAction(a_dev)

        m_help = bar.addMenu("帮助")
        a_about = QAction("关于 " + APP_NAME, self)
        a_about.triggered.connect(self._about)
        m_help.addAction(a_about)

    def _open_devtools(self):
        try:
            self.view.page().setDevToolsPage(self.view.page())
        except Exception:
            pass

    def _about(self):
        exts = ", ".join(sorted({f["ext"] for f in media.available_exports()}))
        QMessageBox.about(
            self, "关于 " + APP_NAME,
            f"<b>{APP_NAME}</b> — 桌面版<br><br>"
            f"打压一切付费同行，让所有人能用上免费好用的工具。<br><br>"
            f"界面：HTML / CSS（QtWebEngine {QCoreApplication.applicationVersion() or ''}）<br>"
            f"音频引擎：Python + ffmpeg（PyAV）<br>"
            f"可导出：{exts}<br><br>"
            f"导入支持 ffmpeg 能解的几乎所有音频与视频容器。",
        )

    # ------------------------------------------------------------ 事件

    def _call_js(self, code: str):
        self.view.page().runJavaScript(code)

    def _on_loaded(self, ok: bool):
        if not ok:
            QMessageBox.critical(self, APP_NAME, "界面加载失败，请检查资源是否完整。")
            return
        if os.environ.get("QAZR_SELFTEST"):
            self._selftest()
            return
        if self._initial:
            payload = __import__("json").dumps(self._initial, ensure_ascii=False)
            self._call_js(f"window.QazrPy && QazrPy.loadPaths({payload});")
            self._initial = []

    # ------------------------------------------------------------ 自检

    def _selftest(self):
        """无头式自检：验证桥接、导入、建片段、导出整条链路。

        用 QAZR_SELFTEST=1 启动，结果打到 stdout，然后退出。
        """
        import json as _json
        steps: list[str] = []
        fails: list[str] = []

        def report(step: str, detail: str = ""):
            steps.append(f"  {step}{('  ::  ' + detail) if detail else ''}")

        def js(code: str, cb):
            self.view.page().runJavaScript(code, cb)

        def wait_until(expr: str, cb, ms: int = 20000):
            """轮询直到表达式为真"""
            deadline = [ms]

            def poll():
                js(f"(function(){{ try {{ return !!({expr}); }} catch(e) {{ return false; }} }})()",
                   lambda v: cb(True) if v else (
                       QTimer.singleShot(150, poll) if (deadline[0] > 0) else cb(False)))
                deadline[0] -= 150
            poll()

        def finish():
            print("=" * 62)
            print("Qazr 桌面版自检")
            print("=" * 62)
            print("\n".join(steps))
            if fails:
                print("\n失败项：")
                for f in fails:
                    print("  !! " + f)
                print(f"\n{len(fails)} 项失败")
            else:
                print("\n全部通过")
            log = getattr(self, "_st_log", "")
            if log:
                print("\n--- 页面日志 ---")
                print(log)
            QTimer.singleShot(0, QApplication.instance().quit)

        def step_bridge():
            wait_until("window.QazrPy && window.QazrPy.ready", lambda ok: after_bridge(ok))

        def after_bridge(ok):
            if not ok:
                fails.append("桥接未就绪（QazrPy.ready 一直为 false）")
                return finish()
            report("桥接就绪", "window.QazrPy.ready = true")
            js("(window.QazrPy.caps && window.QazrPy.caps.exports || []).map(function(x){return x.key;}).join(',')",
               lambda v: (report("Python 能力清单", str(v)), step_dom()))

        def step_dom():
            js("document.querySelectorAll('#tracks .track-row').length", lambda n: (
                report("默认音轨", f"{n} 条"),
                fails.append("默认音轨不是 5 条") if n != 5 else None))
            js("!!document.querySelector('#inspector')", lambda v: None)
            step_import()

        def step_import():
            # 用之前造好的真实测试文件，覆盖音频与视频容器
            tmp = os.path.join(__import__("tempfile").gettempdir(), "qazr_fmt")
            picks = ["probe.mp3", "probe.wav", "probe.m4a" if os.path.exists(
                os.path.join(tmp, "probe.m4a")) else "probe.mp4", "probe.mkv", "probe.webm"]
            paths = [os.path.join(tmp, p) for p in picks]
            paths = [p for p in paths if os.path.isfile(p)]
            if not paths:
                fails.append("找不到测试文件，跳过导入测试")
                return step_export()
            payload = _json.dumps(paths, ensure_ascii=False)
            self._call_js(f"window.QazrPy && QazrPy.loadPaths({payload});")

            def check(n):
                if n:
                    report("导入与建片段", f"喂入 {len(paths)} 个文件 -> {n} 个片段")
                    step_export()
                else:
                    fails.append("导入后没有生成片段")
                    finish()
            wait_until("document.querySelectorAll('#tracks .clip').length >= " + str(len(paths)),
                       check)

        def step_export():
            # 直接走 Python 编码路径：上传一小段 PCM 再导出
            js("(function(){ return typeof QazrPy.uploadPcm === 'function'; })()",
               lambda ok: None)
            out_path = os.path.join(__import__("tempfile").gettempdir(), "qazr_selftest_out.flac")
            if os.path.exists(out_path):
                os.remove(out_path)

            # 造 1 秒立体声，直接调用 store + media.encode，验证 Python 编码链路
            import numpy as np
            sr = 48000
            t = np.linspace(0, 1.0, sr, endpoint=False)
            pcm = np.stack([0.4 * np.sin(2 * np.pi * 440 * t),
                            0.4 * np.sin(2 * np.pi * 660 * t)]).astype(np.float32)
            mid = self._store.put(pcm, sr, {})
            try:
                media.encode(pcm, sr, out_path, "flac")
                back, bsr, _ = media.decode(out_path)
                r = float(np.sqrt(np.mean(back.astype(np.float64) ** 2)))
                report("Python 编码/解码环回", f"FLAC {os.path.getsize(out_path)} B, rms={r:.4f}")
            except Exception as e:
                fails.append(f"编码环回失败：{e}")

            # 走前端的上传接口，确认 HTTP 传输层可用
            js("QazrPy.uploadPcm([new Float32Array(4800), new Float32Array(4800)], 48000)"
               ".then(function(id){ window.__up = id || 'ERR'; })"
               ".catch(function(e){ window.__up = 'ERR:' + e; });", lambda _: None)

            def after_upload(_):
                js("window.__up || ''", lambda v: (
                    report("前端 -> Python PCM 上传", str(v) or "无响应"),
                    fails.append("上传接口没有返回 id") if not (v and str(v).startswith("m")) else None,
                    finish()))
            QTimer.singleShot(1500, lambda: after_upload(None))

        report("窗口已创建", f"{self.width()}x{self.height()}")
        report("本地传输层", self._server.base_url)
        step_bridge()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        paths = [p for p in paths if p and media.can_import(p)]
        if paths:
            payload = __import__("json").dumps(paths, ensure_ascii=False)
            self._call_js(f"window.QazrPy && QazrPy.loadPaths({payload})")
            e.acceptProposedAction()

    def closeEvent(self, e):
        try:
            self._server.stop()
        except Exception:
            pass
        super().closeEvent(e)


def main():
    # Windows 任务栏图标要用 AppUserModelID 才生效
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Qazr.AudioEditor.1")
        except Exception:
            pass

    uargs = [a for a in sys.argv[1:] if not a.startswith("-")]
    initial = [os.path.abspath(p) for p in uargs if os.path.isfile(p)]

    QCoreApplication.setApplicationName("QazrAudioEditor")
    QCoreApplication.setOrganizationName("Qazr")

    app = QApplication(sys.argv)
    app.setApplicationDisplayName(APP_NAME)
    app.setWindowIcon(make_icon())

    store = MediaStore()
    token = secrets.token_urlsafe(18)
    server = LocalServer(resource_root(), store, token).start()

    win = MainWindow(store, server, initial)
    win.show()

    code = app.exec()
    server.stop()
    return code


if __name__ == "__main__":
    sys.exit(main())
