/*
 * Qazr 音频剪辑软件 — 主程序
 * 多轨时间轴 / 剪辑 / 变速 / 变调 / 声道 / 导出
 */
(function () {
  'use strict';

  var DSP = window.QazrDSP;
  var Engine = window.QazrEngine;
  var Codec = window.QazrCodec;

  /* 桌面版（Python）桥接：由主程序注入 js/pybridge.js 后才存在。
     纯浏览器里打开时 py() 恒为 null，全部走内置的浏览器实现。 */
  function py() {
    return (window.QazrPy && window.QazrPy.ready) ? window.QazrPy : null;
  }

  /* ============================ 常量 ============================ */

  var TRACK_COLORS = ['#0a84ff', '#3ad6ff', '#6a7bff', '#00c2a8', '#ff9f0a', '#ff6482', '#bf5af2', '#30d158'];
  var PX_MIN = 8, PX_MAX = 420;
  var SNAP_PX = 9;
  var MIN_CLIP = 0.02;         // 片段最小长度（秒）
  var LANE_MIN_H = 52, LANE_MAX_H = 260;
  var WAVE_MARGIN = 240;       // 波形可视区外额外多画这么多像素，减少滚动重绘

  /* ============================ 状态 ============================ */

  var S = {
    tracks: [],
    clips: [],
    activeTrack: null,
    selection: null,          // { type:'clip'|'track', id }
    playhead: 0,
    pxPerSec: 62,
    tool: 'select',
    snap: true,
    master: 1,
    theme: 'light'
  };

  var history = [];
  var future = [];
  var clipAudio = new Map();   // clipId -> { channels, sampleRate, sig }
  var peakCache = new Map();   // key -> peaks
  var srcSeq = 1;

  /* ============================ DOM ============================ */

  var $ = function (id) { return document.getElementById(id); };
  var tracksEl = $('tracks');
  var tlInner = $('tlInner');
  var tlScroll = $('tlScroll');
  var rulerEl = $('ruler');
  var rulerCanvas = $('rulerCanvas');
  var playheadEl = $('playhead');
  var inspBody = $('inspBody');
  var inspector = $('inspector');

  /* ============================ 工具函数 ============================ */

  var uidN = 1;
  function uid(p) { return p + '_' + (uidN++).toString(36) + Math.random().toString(36).slice(2, 6); }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function pad(n, w) { n = Math.floor(n); var s = String(n); while (s.length < w) s = '0' + s; return s; }

  function fmt(t) {
    t = Math.max(0, t);
    var m = Math.floor(t / 60), s = Math.floor(t % 60), ms = Math.floor((t % 1) * 1000);
    return pad(m, 2) + ':' + pad(s, 2) + '.' + pad(ms, 3);
  }
  function fmtShort(t) {
    t = Math.max(0, t);
    var m = Math.floor(t / 60), s = Math.round(t % 60);
    return pad(m, 2) + ':' + pad(s, 2);
  }

  function toast(msg, kind) {
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.innerHTML = '<span class="ic"></span><span></span>';
    el.lastChild.textContent = msg;
    $('toasts').appendChild(el);
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () { el.remove(); }, 320);
    }, 2300);
  }

  var busyDepth = 0;
  function busy(on, text) {
    busyDepth += on ? 1 : -1;
    if (busyDepth < 0) busyDepth = 0;
    if (text) $('busyText').textContent = text;
    $('busyMask').classList.toggle('on', busyDepth > 0);
  }

  /* ============================ 快照 / 撤销 ============================ */

  function snapshot() {
    return JSON.stringify({
      tracks: S.tracks.map(function (t) {
        return { id: t.id, name: t.name, color: t.color, gainDb: t.gainDb, pan: t.pan, gainL: t.gainL, gainR: t.gainR, channelMode: t.channelMode, link: t.link, muted: t.muted, solo: t.solo, height: t.height };
      }),
      clips: S.clips.map(function (c) {
        return { id: c.id, trackId: c.trackId, name: c.name, start: c.start, offset: c.offset, srcDur: c.srcDur, srcId: c.srcId, reversed: c.reversed, speed: c.speed, pitchUnit: c.pitchUnit, pitchValue: c.pitchValue, vanilla: c.vanilla, ratio: c.ratio, gainDb: c.gainDb, pan: c.pan, gainL: c.gainL, gainR: c.gainR, channelMode: c.channelMode, link: c.link, fadeIn: c.fadeIn, fadeOut: c.fadeOut, denoise: c.denoise, eq: c.eq, vocal: c.vocal, color: c.color };
      }),
      activeTrack: S.activeTrack,
      selection: S.selection
    });
  }

  var srcs = new Map();   // srcId -> {channels, sampleRate, duration, name}
  var lastSnap = null;    // 上一次已提交的状态（用于撤销基线）

  /* 在“改动完成之后”调用：把改动前的状态压入历史 */
  function pushHistory() {
    var cur = snapshot();
    if (lastSnap === null) { lastSnap = cur; return; }
    if (lastSnap === cur) return;
    history.push(lastSnap);
    if (history.length > 80) history.shift();
    future.length = 0;
    lastSnap = cur;
    updateUndoButtons();
  }

  function applySnapshot(json) {
    var d = JSON.parse(json);
    S.tracks = d.tracks.map(function (t) { return plainTrack(t); });
    S.clips = d.clips.map(function (c) { return plainClip(c); });
    S.activeTrack = d.activeTrack;
    S.selection = d.selection;
    clipAudio.clear();
    renderAll();
    updateUndoButtons();
  }

  function plainTrack(t) {
    return {
      id: t.id, name: t.name, color: t.color,
      gainDb: t.gainDb === undefined ? 0 : t.gainDb,
      pan: t.pan || 0,
      gainL: t.gainL === undefined ? 1 : t.gainL,
      gainR: t.gainR === undefined ? 1 : t.gainR,
      channelMode: t.channelMode || 'stereo',
      link: t.link !== false,
      muted: !!t.muted, solo: !!t.solo,
      height: t.height || 84
    };
  }

  function plainClip(c) {
    return {
      id: c.id, trackId: c.trackId, name: c.name,
      start: c.start, offset: c.offset, srcDur: c.srcDur,
      srcId: c.srcId,
      reversed: !!c.reversed,
      speed: c.speed || 1,
      pitchUnit: c.pitchUnit || 'ratio',
      pitchValue: c.pitchValue === undefined ? 1 : c.pitchValue,
      vanilla: !!c.vanilla,
      ratio: c.ratio || 1,
      gainDb: c.gainDb === undefined ? 0 : c.gainDb,
      pan: c.pan || 0,
      gainL: c.gainL === undefined ? 1 : c.gainL,
      gainR: c.gainR === undefined ? 1 : c.gainR,
      channelMode: c.channelMode || 'stereo',
      link: c.link !== false,
      fadeIn: c.fadeIn || 0,
      fadeOut: c.fadeOut || 0,
      denoise: plainDenoise(c.denoise),
      eq: plainEq(c.eq),
      vocal: plainVocal(c.vocal),
      color: c.color
    };
  }

  function plainDenoise(d) {
    return {
      on: !!(d && d.on),
      strength: d && d.strength !== undefined ? d.strength : 0.6,
      floorDb: d && d.floorDb !== undefined ? d.floorDb : -18
    };
  }
  function plainEq(e) {
    var g = e && e.gains && e.gains.length ? e.gains.slice(0, 10) : [];
    while (g.length < 10) g.push(0);
    return {
      on: !!(e && e.on),
      lowCut: e && e.lowCut ? e.lowCut : 0,
      highCut: e && e.highCut ? e.highCut : 0,
      gains: g
    };
  }
  function plainVocal(v) {
    return {
      mode: v && v.mode ? v.mode : 'off',
      strength: v && v.strength !== undefined ? v.strength : 0.9
    };
  }

  function updateUndoButtons() {
    $('btnUndo').disabled = history.length === 0;
    $('btnRedo').disabled = future.length === 0;
  }

  /* ============================ 音轨 ============================ */

  function makeTrack(i) {
    return plainTrack({
      id: uid('tr'),
      name: '音轨 ' + (i + 1),
      color: TRACK_COLORS[i % TRACK_COLORS.length],
      height: 84
    });
  }

  function track(id) { for (var i = 0; i < S.tracks.length; i++) if (S.tracks[i].id === id) return S.tracks[i]; return null; }
  function clip(id) { for (var i = 0; i < S.clips.length; i++) if (S.clips[i].id === id) return S.clips[i]; return null; }
  function trackIdx(id) { for (var i = 0; i < S.tracks.length; i++) if (S.tracks[i].id === id) return i; return -1; }

  function trackClips(tid) {
    return S.clips.filter(function (c) { return c.trackId === tid; });
  }

  function isAudible(t) {
    var anySolo = S.tracks.some(function (x) { return x.solo; });
    if (anySolo) return t.solo;
    return !t.muted;
  }

  /* ============================ 片段几何 ============================ */

  function clipDur(c) {
    if (c.vanilla) return c.srcDur / (c.ratio > 0 ? c.ratio : 1);
    return c.srcDur / (c.speed > 0 ? c.speed : 1);
  }
  function clipEnd(c) { return c.start + clipDur(c); }
  function timelineEnd() {
    var e = 0;
    for (var i = 0; i < S.clips.length; i++) e = Math.max(e, clipEnd(S.clips[i]));
    return e;
  }

  /* 变调数值 -> 倍率 */
  function pitchRatio(c) {
    if (c.vanilla) return c.ratio > 0 ? c.ratio : 1;
    return DSP.pitchToRatio(c.pitchValue, c.pitchUnit);
  }

  /* ============================ 音频渲染缓存 ============================ */

  function clipSig(c) {
    var d = c.denoise || {}, e = c.eq || {}, v = c.vocal || {};
    return [c.srcId, c.offset.toFixed(4), c.srcDur.toFixed(4), c.reversed ? 1 : 0,
      c.speed, c.pitchUnit, c.pitchValue, c.vanilla ? 1 : 0, c.ratio,
      v.mode || 'off', v.strength,
      d.on ? 1 : 0, d.strength, d.floorDb,
      e.on ? 1 : 0, e.lowCut || 0, e.highCut || 0, (e.gains || []).join(',')
    ].join('|');
  }

  function getAudio(c) {
    var sig = clipSig(c);
    var hit = clipAudio.get(c.id);
    if (hit && hit.sig === sig) return hit;

    var src = srcs.get(c.srcId);
    if (!src) return null;

    var rendered = Engine.renderClip(src, {
      srcIn: c.offset,
      srcLen: c.srcDur,
      sampleRate: src.sampleRate,
      reversed: c.reversed,
      speed: c.speed,
      pitch: c.vanilla ? 1 : DSP.pitchToRatio(c.pitchValue, c.pitchUnit),
      vanilla: c.vanilla,
      ratio: c.ratio,
      vocal: c.vocal,
      denoise: c.denoise,
      eq: c.eq
    });
    var rec = { channels: rendered.channels, sampleRate: rendered.sampleRate, sig: sig };
    clipAudio.set(c.id, rec);
    return rec;
  }

  /* ============================ 波形绘制 ============================ */

  /* 分段包络：每个素材只建一次，分帧推进，构建期间界面不阻塞 */
  var envs = new Map();        // srcId -> 多分辨率分段包络
  var envPump = 0;             // requestAnimationFrame 句柄
  var ENV_BUDGET = 1500000;    // 每帧最多扫描的样本数

  function ensureEnv(srcId) {
    var src = srcs.get(srcId);
    if (!src) return null;
    var env = envs.get(srcId);
    if (!env) {
      env = DSP.envelopeInit(src.channels);
      envs.set(srcId, env);
      pumpEnv();
    }
    return env;
  }

  function pumpEnv() {
    if (envPump) return;
    var step = function () {
      envPump = 0;
      var busy = false;
      var left = 0;
      envs.forEach(function (env, sid) {
        if (env.done) return;
        left++;
        if (busy) return;                       // 每帧只推进一个素材
        var src = srcs.get(sid);
        if (!src) return;
        DSP.envelopeFill(env, src.channels, ENV_BUDGET);
        busy = true;
      });
      if (left === 0) {
        /* 全部建好：旧的一次性峰值缓存作废，整体重绘一次走上快车道 */
        peakCache.clear();
        drawAllWaves();
        return;
      }
      envPump = requestAnimationFrame(step);
    };
    envPump = requestAnimationFrame(step);
  }

  function drawWave(canvas, c, w, h) {
    var dpr = window.devicePixelRatio || 1;

    /*
     * 可视区裁剪：高缩放下一个片段能有上万像素宽，
     * 整幅画出来既分配巨大的画布、又要画上万个矩形，
     * 而屏幕其实只看得到一千多像素。这里只画可视的那一段。
     */
    /* 泳道本地可视区间：与刻度尺同理，从 scrollLeft 起算 */
    var laneLeft = c.start * S.pxPerSec;
    var viewW = Math.max(0, tlScroll.clientWidth - headWidth());
    var viewL = tlScroll.scrollLeft - WAVE_MARGIN;
    var viewR = tlScroll.scrollLeft + viewW + WAVE_MARGIN;
    var x0 = Math.max(0, Math.min(w, viewL - laneLeft));
    var x1 = Math.max(0, Math.min(w, viewR - laneLeft));
    var cw = x1 - x0;

    if (cw < 1 || h < 1) {                 // 完全在屏幕外
      if (canvas.width !== 1) { canvas.width = 1; canvas.height = 1; }
      return;
    }

    canvas.style.left = x0 + 'px';
    canvas.style.width = cw + 'px';
    canvas.width = Math.max(1, Math.floor(cw * dpr));
    canvas.height = Math.max(1, Math.floor(h * dpr));
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cw, h);
    if (cw < 2 || h < 2) return;

    var src = srcs.get(c.srcId);
    if (!src) return;

    var buckets = Math.max(2, Math.floor(cw));
    /* 可视像素区间换算回样本区间 */
    var spanSamples = c.srcDur * src.sampleRate;
    var from = c.offset * src.sampleRate + spanSamples * (x0 / w);
    var to = c.offset * src.sampleRate + spanSamples * (x1 / w);

    var key = [c.srcId, c.offset.toFixed(3), c.srcDur.toFixed(3), buckets,
      x0.toFixed(0), x1.toFixed(0)].join('|');
    var pk = peakCache.get(key);
    if (!pk) {
      /* 分段包络建好后走快车道：只聚合格子，不再扫样本。
         建好一档就能用一档，不必等全部层级都填完。 */
      var env = ensureEnv(c.srcId);
      pk = (env && DSP.envelopeReadyTo(env, buckets, from, to))
        ? DSP.envelopePeaks(env, src.channels, buckets, from, to)
        : DSP.peaks(src.channels, buckets, from, to);
      if (c.reversed) {
        var rmin = new Float32Array(pk.count), rmax = new Float32Array(pk.count);
        for (var i = 0; i < pk.count; i++) { rmin[i] = pk.min[pk.count - 1 - i]; rmax[i] = pk.max[pk.count - 1 - i]; }
        pk = { min: rmin, max: rmax, count: pk.count };
      }
      peakCache.set(key, pk);
      if (peakCache.size > 400) { var k0 = peakCache.keys().next().value; peakCache.delete(k0); }
    }

    var mid = h / 2;
    ctx.fillStyle = 'rgba(255,255,255,0.86)';
    ctx.beginPath();
    for (var b = 0; b < pk.count; b++) {
      var x = b * (cw / pk.count);
      var y0 = mid - pk.max[b] * (mid - 3);
      var y1 = mid - pk.min[b] * (mid - 3);
      var bh = Math.max(1, y1 - y0);
      ctx.rect(x, y0, Math.max(0.8, cw / pk.count - 0.35), bh);
    }
    ctx.fill();

    ctx.strokeStyle = 'rgba(255,255,255,0.34)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, mid + 0.5); ctx.lineTo(cw, mid + 0.5); ctx.stroke();
  }

  /* ============================ 渲染 ============================ */

  var rowEls = new Map();   // trackId -> { row, lane, head }
  var clipEls = new Map();  // clipId -> el

  function totalWidth() {
    var vw = tlScroll.clientWidth - headWidth();
    return Math.max(vw, (timelineEnd() + 6) * S.pxPerSec + 40);
  }
  function headWidth() {
    var v = getComputedStyle(document.documentElement).getPropertyValue('--head-w');
    return parseFloat(v) || 210;
  }

  function renderRuler() {
    var w = totalWidth();
    var dpr = window.devicePixelRatio || 1;
    var pps = S.pxPerSec;
    rulerEl.style.width = w + 'px';

    /*
     * 刻度尺同样只画可视区：
     * 整条时间轴在最大缩放下有几万像素宽，若整幅画出来，
     * 画布要分配几百万像素，而且刻度会密到每帧画上千条线加文字。
     */
    var pad = WAVE_MARGIN;
    /* 刻度尺与泳道都排在 headWidth 宽的粘性表头之后，
       所以"本地可视区间"都从 scrollLeft 开始、到 scrollLeft + 可视宽度为止 */
    var viewL = tlScroll.scrollLeft;
    var viewW = Math.max(0, tlScroll.clientWidth - headWidth());
    var x0 = Math.max(0, Math.floor(viewL - pad));
    var x1 = Math.min(w, Math.ceil(viewL + viewW + pad));
    var cw = Math.max(1, x1 - x0);

    rulerCanvas.style.left = x0 + 'px';
    rulerCanvas.style.width = cw + 'px';
    rulerCanvas.width = Math.floor(cw * dpr);
    rulerCanvas.height = Math.floor(34 * dpr);
    rulerCanvas.style.height = '34px';
    var ctx = rulerCanvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cw, 34);

    var steps = [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
    var major = 60;
    for (var i = 0; i < steps.length; i++) { if (steps[i] * pps >= 74) { major = steps[i]; break; } }
    var minor = major / 5;

    ctx.font = '600 10px -apple-system, "SF Pro Text", "PingFang SC", sans-serif';
    ctx.textBaseline = 'middle';

    /* 从可视区左边界对应的第一个整刻度开始 */
    var t = Math.floor((x0 / pps) / major) * major;
    var endT = x1 / pps;
    while (t <= endT) {
      var x = Math.round(t * pps - x0) + 0.5;
      ctx.strokeStyle = 'rgba(10,80,170,0.22)';
      ctx.beginPath(); ctx.moveTo(x, 22); ctx.lineTo(x, 34); ctx.stroke();
      ctx.fillStyle = 'rgba(11,30,56,0.62)';
      ctx.fillText(fmtShort(t), x + 4, 11);
      for (var m = 1; m < 5; m++) {
        var mx = Math.round((t + minor * m) * pps - x0) + 0.5;
        if (mx > cw) break;
        ctx.strokeStyle = 'rgba(10,80,170,0.12)';
        ctx.beginPath(); ctx.moveTo(mx, 27); ctx.lineTo(mx, 34); ctx.stroke();
      }
      t += major;
    }
  }

  function renderTracks() {
    tracksEl.innerHTML = '';
    rowEls.clear();

    for (var i = 0; i < S.tracks.length; i++) {
      var t = S.tracks[i];
      var row = document.createElement('div');
      row.className = 'track-row';
      row.style.height = t.height + 'px';
      row.dataset.track = t.id;

      var head = document.createElement('div');
      head.className = 'track-head' + (S.activeTrack === t.id ? ' active' : '');
      head.dataset.track = t.id;

      var row1 = document.createElement('div');
      row1.className = 'row1';
      var dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = t.color;
      var name = document.createElement('input');
      name.className = 'name';
      name.value = t.name;
      name.dataset.track = t.id;
      name.addEventListener('input', function (e) {
        var tr = track(e.target.dataset.track); if (tr) tr.name = e.target.value;
      });
      name.addEventListener('change', function () { pushHistory(); });
      row1.appendChild(dot); row1.appendChild(name);

      var row2 = document.createElement('div');
      row2.className = 'row2';
      var bM = mkChip('M', 'chip' + (t.muted ? ' on' : ''), function () {
        t.muted = !t.muted; pushHistory(); renderTracks(); refreshInspector();
      });
      var bS = mkChip('S', 'chip solo' + (t.solo ? ' on' : ''), function () {
        t.solo = !t.solo; pushHistory(); renderTracks(); refreshInspector();
      });
      bM.title = '静音'; bS.title = '独奏';
      row2.appendChild(bM); row2.appendChild(bS);

      var vol = document.createElement('input');
      vol.type = 'range'; vol.className = 'slider mini'; vol.min = '-40'; vol.max = '6'; vol.step = '0.01';
      vol.value = t.gainDb; vol.title = '音轨音量';
      vol.addEventListener('input', function () {
        var tr = track(this.dataset.track); if (tr) tr.gainDb = parseFloat(this.value);
      });
      vol.dataset.track = t.id;
      vol.addEventListener('change', function () { pushHistory(); refreshInspector(); });

      var del = mkChip('✕', 'chip danger', function () {
        if (S.tracks.length <= 1) { toast('至少保留一条音轨', 'err'); return; }
        S.clips = S.clips.filter(function (c) { return c.trackId !== t.id; });
        S.tracks.splice(trackIdx(t.id), 1);
        if (S.activeTrack === t.id) S.activeTrack = S.tracks[0].id;
        pushHistory();
        renderAll();
      });
      del.title = '删除音轨';

      row2.appendChild(vol); row2.appendChild(del);

      head.appendChild(row1); head.appendChild(row2);

      var lane = document.createElement('div');
      lane.className = 'lane';
      lane.dataset.track = t.id;
      lane.style.width = totalWidth() + 'px';
      lane.dataset.track = t.id;

      head.addEventListener('mousedown', function () {
        var id = this.dataset.track;
        S.activeTrack = id;
        S.selection = { type: 'track', id: id };
        renderTracks(); refreshInspector();
      });

      /* 拖放到音轨 */
      bindLaneDrop(lane, t.id);

      row.appendChild(head); row.appendChild(lane);
      tracksEl.appendChild(row);
      rowEls.set(t.id, { row: row, lane: lane, head: head, index: i });
    }

    renderClips();
    layoutPlayhead();
  }

  function mkChip(text, cls, fn) {
    var b = document.createElement('button');
    b.className = cls;
    b.textContent = text;
    b.addEventListener('click', function (e) { e.stopPropagation(); fn(); });
    return b;
  }

  function renderClips() {
    clipEls.clear();
    rowEls.forEach(function (r) { r.lane.innerHTML = ''; });

    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i];
      var r = rowEls.get(c.trackId);
      if (!r) continue;

      var el = document.createElement('div');
      el.className = 'clip';
      el.dataset.clip = c.id;
      el.style.left = (c.start * S.pxPerSec) + 'px';
      el.style.width = Math.max(6, clipDur(c) * S.pxPerSec) + 'px';
      if (c.color) {
        el.style.background = 'linear-gradient(170deg,' + hexA(c.color, 0.94) + ',' + c.color + ' 62%,' + shade(c.color, -22) + ')';
      }

      var cv = document.createElement('canvas');
      var tag = document.createElement('div');
      tag.className = 'tag';
      tag.textContent = c.name;
      var badges = document.createElement('div');
      badges.className = 'badges';
      badges.innerHTML = clipBadges(c);

      var fi = document.createElement('div'); fi.className = 'fade';
      var fo = document.createElement('div'); fo.className = 'fade out';
      var hL = document.createElement('div'); hL.className = 'handle l';
      var hR = document.createElement('div'); hR.className = 'handle r';
      var dIn = document.createElement('div'); dIn.className = 'fdot in';
      var dOut = document.createElement('div'); dOut.className = 'fdot out';
      var busyEl = document.createElement('div'); busyEl.className = 'busy';
      busyEl.innerHTML = '<span class="spinner"></span>';

      el.appendChild(cv); el.appendChild(fi); el.appendChild(fo);
      el.appendChild(tag); el.appendChild(badges);
      el.appendChild(hL); el.appendChild(hR); el.appendChild(dIn); el.appendChild(dOut);
      el.appendChild(busyEl);

      if (S.selection && S.selection.type === 'clip' && S.selection.id === c.id) el.classList.add('selected');

      r.lane.appendChild(el);
      clipEls.set(c.id, el);
    }
    drawAllWaves();
    updateFades();
  }

  /*
   * 缩放专用：所有片段元素都已存在，只是位置和宽度变了，
   * 直接改样式 + 重画波形即可，不必拆掉重建 DOM。
   */
  function relayoutAllClips() {
    if (clipEls.size !== S.clips.length) { renderClips(); return; }
    for (var i = 0; i < S.clips.length; i++) {
      if (!clipEls.has(S.clips[i].id)) { renderClips(); return; }
    }
    var pps = S.pxPerSec;
    /* 先集中写样式，再集中绘制：
       否则每个"写 width 后读 clientWidth"都会触发一次强制同步重排 */
    for (var k = 0; k < S.clips.length; k++) {
      var c = S.clips[k];
      var el = clipEls.get(c.id);
      if (!el) continue;
      el.style.left = (c.start * pps) + 'px';
      el.style.width = Math.max(6, clipDur(c) * pps) + 'px';
    }
    for (var j = 0; j < S.clips.length; j++) drawOneWave(S.clips[j]);
    updateFades();
  }

  function clipBadges(c) {
    var b = '';
    if (Math.abs(c.speed - 1) > 1e-5) b += '<span class="badge">' + (+c.speed.toFixed(5)) + '×</span>';
    if (c.vanilla) b += '<span class="badge">原版 ' + (+c.ratio.toFixed(3)) + '×</span>';
    else if (Math.abs(DSP.ratioToPitch(pitchRatio(c), 'ratio') - 1) > 1e-4) {
      b += '<span class="badge">' + (+pitchRatio(c).toFixed(3)) + '× 调</span>';
    }
    if (c.reversed) b += '<span class="badge">反转</span>';
    if (c.channelMode && c.channelMode !== 'stereo') {
      var m = { left: '左', right: '右', swap: '换', merge: '单' };
      b += '<span class="badge">' + (m[c.channelMode] || '') + '</span>';
    }
    if (Math.abs(c.gainL - 1) > 1e-3 || Math.abs(c.gainR - 1) > 1e-3) b += '<span class="badge">L/R</span>';
    if (c.vocal && c.vocal.mode === 'vocal') b += '<span class="badge">人声</span>';
    else if (c.vocal && c.vocal.mode === 'remove') b += '<span class="badge">伴奏</span>';
    if (c.denoise && c.denoise.on) b += '<span class="badge">降噪</span>';
    if (c.eq && c.eq.on) b += '<span class="badge">EQ</span>';
    return b;
  }

  function drawOneWave(c) {
    var el = clipEls.get(c.id);
    if (!el) return;
    var cv = el.querySelector('canvas');
    if (!cv) return;
    var w = el.clientWidth, h = el.clientHeight;
    el.classList.toggle('narrow', w < 54);
    drawWave(cv, c, w, h);
  }

  function drawAllWaves() {
    clipEls.forEach(function (el, id) {
      var c = clip(el.dataset.clip);
      if (!c) return;
      drawOneWave(c);
    });
  }

  function updateFades() {
    clipEls.forEach(function (el, id) {
      var c = clip(id);
      if (!c) return;
      var d = clipDur(c);
      var w = Math.max(6, d * S.pxPerSec);
      var f = el.querySelector('.fade');
      var fo = el.querySelector('.fade.out');
      f.style.width = clamp(c.fadeIn / d, 0, 1) * w + 'px';
      fo.style.width = clamp(c.fadeOut / d, 0, 1) * w + 'px';
    });
  }

  function layoutPlayhead() {
    playheadEl.style.left = headWidth() + 'px';
    playheadEl.style.transform = 'translateX(' + (S.playhead * S.pxPerSec) + 'px)';
    var h = tracksEl.scrollHeight || 0;
    playheadEl.style.height = (34 + h) + 'px';
    playheadEl.style.top = '0px';
  }

  function renderAll() {
    renderRuler();
    renderTracks();
    layoutPlayhead();
    updateTimecode();
    updateStatus();
    updateUndoButtons();
  }

  /* ============================ 面板 ============================ */

  function refreshInspector() {
    inspBody.innerHTML = '';
    chanSync = {};
    var sel = S.selection;
    if (!sel) {
      inspector.classList.remove('open');
      inspBody.appendChild(emptyInsp());
      return;
    }
    inspector.classList.add('open');
    if (sel.type === 'track') { buildTrackInsp(track(sel.id)); return; }
    buildClipInsp(clip(sel.id));
  }

  function emptyInsp() {
    var d = document.createElement('div');
    d.className = 'empty';
    d.innerHTML = '<div class="big"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/></svg></div>' +
      '<div>点击下方按钮或把音频 / 视频拖进来<br>开始你的剪辑</div>';
    var btn = document.createElement('button');
    btn.className = 'btn primary';
    btn.textContent = '导入音频 / 视频';
    btn.addEventListener('click', function () { startImport(); });
    d.appendChild(btn);
    return d;
  }

  function sec(title) {
    var s = document.createElement('div');
    s.className = 'section';
    var h = document.createElement('h4');
    h.textContent = title;
    s.appendChild(h);
    return s;
  }

  function field(label, node, valueText) {
    var f = document.createElement('div');
    f.className = 'field';
    var l = document.createElement('div');
    l.className = 'lbl';
    var t = document.createElement('span'); t.textContent = label;
    l.appendChild(t);
    if (valueText !== undefined) {
      var v = document.createElement('span'); v.className = 'val'; v.textContent = valueText;
      l.appendChild(v);
    }
    f.appendChild(l); f.appendChild(node);
    return f;
  }

  /* 数值精度约定：滑动条步进 2 位小数，数字框可输入 5 位小数 */
  var SLIDER_STEP = 0.01;
  var NUM_STEP = 0.00001;
  var NUM_DEBOUNCE = 420;      // 数字框停止输入多久后才真正应用

  function round5(v) { return Math.round(v * 1e5) / 1e5; }

  /*
   * sliderField(label, min, max, step, value, unit, onApply, onPreview)
   *
   * 性能约定：拖动过程中只同步另一个控件的显示（onPreview），
   * 不做任何重计算；只有松手 / 输入结束（change）才调用 onApply 真正应用。
   * 这样避免每移动一个像素就重算波形与音频。
   */
  function sliderField(label, min, max, step, value, unit, onApply, onPreview) {
    var wrap = document.createElement('div');
    wrap.style.display = 'flex';
    wrap.style.gap = '10px';
    wrap.style.alignItems = 'center';

    var lo = parseFloat(min), hi = parseFloat(max);
    /* 整数型参数（如轨道高度 px）保持整数，其余统一按上述精度约定 */
    var isInt = parseFloat(step) >= 1;
    var snap = isInt ? function (v) { return Math.round(v); } : round5;

    var r = document.createElement('input');
    r.type = 'range'; r.className = 'slider'; r.style.flex = '1';
    r.min = lo; r.max = hi; r.step = isInt ? 1 : SLIDER_STEP; r.value = value;
    var n = document.createElement('input');
    n.type = 'number'; n.className = 'input'; n.style.width = '86px';
    n.min = lo; n.max = hi; n.step = isInt ? 1 : NUM_STEP; n.value = value;

    var timer = null;

    function read(v) { return snap(clamp(parseFloat(v) || 0, lo, hi)); }

    function preview(v) { if (onPreview) onPreview(v); }

    /* 调整结束：真正应用（重算音频、重绘波形、记入历史） */
    function apply(v) {
      if (timer) { clearTimeout(timer); timer = null; }
      onApply(v);
      pushHistory();
    }

    /* 滑动条：拖动中只更新数字显示 */
    r.addEventListener('input', function () {
      var v = read(this.value);
      n.value = v;
      preview(v);
    });
    r.addEventListener('change', function () {
      var v = read(this.value);
      n.value = v;
      apply(v);
    });

    /* 数字框：输入中只更新滑条位置，停止输入一小段时间后才应用 */
    n.addEventListener('input', function () {
      var raw = n.value;
      if (raw === '' || raw === '-' || raw === '.' || isNaN(parseFloat(raw))) return;
      var v = read(raw);
      r.value = v;
      preview(v);
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () { timer = null; apply(v); }, NUM_DEBOUNCE);
    });
    n.addEventListener('change', function () {
      var v = read(n.value);
      n.value = v; r.value = v;
      apply(v);
    });

    wrap.appendChild(r); wrap.appendChild(n);
    var f = field(label, wrap);
    f.dataset.setter = 'v';
    return f;
  }

  function selectField(label, options, value, onChange) {
    var s = customSelect(options, value, onChange);
    return field(label, s);
  }

  /* ============================================================
   * customSelect(options, value, onChange)
   *   自定义下拉选择框：
   *   - 收起时是圆角胶囊按钮，右侧 chevron 随开合旋转
   *   - 展开时弹出毛玻璃浮层：spring 缩放 + 淡入 + 上滑，选项逐条 stagger
   *   - 悬停高亮、选中打勾、点击有回弹；外部点击 / Esc / 滚动自动收起
   * 返回可直接 appendChild 的 DOM。
   * ============================================================ */
  var csOpen = null;          // 当前打开的下拉

  function closeCustomSelect(silent) {
    if (!csOpen) return;
    var o = csOpen; csOpen = null;
    o.trigger.classList.remove('open');
    document.removeEventListener('mousedown', o.onDoc, true);
    document.removeEventListener('keydown', o.onKey, true);
    window.removeEventListener('resize', o.onWin);
    window.removeEventListener('scroll', o.onScroll, true);

    var panel = o.panel;
    if (silent) {
      panel.style.transition = 'none';
      panel.classList.remove('open');
      /* 强制重排后移除节点 */
      void panel.offsetHeight;
      if (panel.parentNode) panel.parentNode.removeChild(panel);
      return;
    }
    panel.classList.remove('open');
    var done = function (ev) {
      if (ev && ev.target !== panel) return;
      panel.removeEventListener('transitionend', done);
      if (panel.parentNode) panel.parentNode.removeChild(panel);
    };
    panel.addEventListener('transitionend', done);
    /* 兜底：极端情况下 transitionend 未触发 */
    setTimeout(function () {
      if (document.body.contains(panel)) done();
    }, 480);
  }

  /* 通用构建器：orient = 'v'（上下展开）| 'h'（左右展开） */
  function buildCS(options, value, onChange, orient) {
    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'cs-trigger input' + (orient === 'h' ? ' cs-trigger-h' : '');

    var labelEl = document.createElement('span');
    labelEl.className = 'cs-label';
    var chevron = document.createElement('span');
    chevron.className = 'cs-chevron';
    chevron.innerHTML = orient === 'h'
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
    trigger.appendChild(labelEl);
    trigger.appendChild(chevron);

    function currentText() {
      for (var i = 0; i < options.length; i++) {
        if (String(options[i].v) === String(value)) return options[i].t;
      }
      return options.length ? options[0].t : '';
    }
    labelEl.textContent = currentText();

    trigger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (csOpen && csOpen.trigger === trigger) { closeCustomSelect(); return; }
      closeCustomSelect(true);
      openPanel();
    });

    function openPanel() {
      var rect = trigger.getBoundingClientRect();
      var panel = document.createElement('div');
      panel.className = 'cs-panel' + (orient === 'h' ? ' cs-panel-h' : '');

      var dir;
      /* 面板预估高度（纵向时用于方向判定与定位） */
      var panelH = Math.min(options.length * 40 + 12, 288);
      if (orient === 'h') {
        dir = (rect.right + 10 + 180 > window.innerWidth) ? 'left' : 'right';
      } else {
        /* 下方放不下，或上方空间明显更宽裕时，向上展开 */
        var downFit = rect.bottom + 10 + panelH <= window.innerHeight;
        var upSpace = rect.top - 10;
        dir = (!downFit && upSpace >= panelH) ? 'up'
          : (!downFit && upSpace > 40) ? 'up'
          : downFit ? 'down' : 'down';
      }
      panel.classList.add('dir-' + dir);

      options.forEach(function (o, i) {
        var it = document.createElement('button');
        it.type = 'button';
        it.className = 'cs-item';
        var selected = String(o.v) === String(value);
        if (selected) it.classList.add('selected');

        var tx = document.createElement('span');
        tx.className = 'cs-item-t';
        tx.textContent = o.t;
        var tick = document.createElement('span');
        tick.className = 'cs-tick';
        tick.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>';
        it.appendChild(tx); it.appendChild(tick);
        it.style.transitionDelay = (i * 26) + 'ms';

        it.addEventListener('click', function (ev) {
          ev.stopPropagation();
          value = o.v;
          labelEl.textContent = o.t;
          trigger.classList.add('picked');
          setTimeout(function () { trigger.classList.remove('picked'); }, 260);
          closeCustomSelect();
          if (onChange) onChange(o.v);
        });
        panel.appendChild(it);
      });

      document.body.appendChild(panel);

      if (orient === 'h') {
        var PHW = 176;
        panel.style.width = PHW + 'px';
        var needH = Math.min(options.length * 40 + 12, 288);
        var topH = Math.max(8, Math.min(rect.top, window.innerHeight - needH - 8));
        panel.style.top = topH + 'px';
        if (dir === 'right') panel.style.left = (rect.right + 8) + 'px';
        else panel.style.left = (rect.left - 8 - PHW) + 'px';
      } else {
        var pw = Math.max(rect.width, 168);
        panel.style.width = pw + 'px';
        var left = Math.max(8, Math.min(rect.left, window.innerWidth - pw - 8));
        panel.style.left = left + 'px';

        /* 向上展开：底边贴在触发器上方，高度不超过上方可用空间 */
        if (dir === 'up') {
          var upAvail = Math.max(60, rect.top - 10);
          var upH = Math.min(panelH, upAvail);
          panel.style.maxHeight = upH + 'px';
          panel.style.top = (rect.top - 8 - upH) + 'px';
        } else {
          panel.style.top = (rect.bottom + 8) + 'px';
        }
      }

      requestAnimationFrame(function () {
        requestAnimationFrame(function () { panel.classList.add('open'); });
      });

      var onDoc = function (ev) {
        if (panel.contains(ev.target) || trigger.contains(ev.target)) return;
        closeCustomSelect();
      };
      var onKey = function (ev) { if (ev.key === 'Escape') closeCustomSelect(); };
      var onWin = function () { closeCustomSelect(true); };
      var onScroll = function (ev) {
        if (panel.contains(ev.target)) return;
        closeCustomSelect(true);
      };
      document.addEventListener('mousedown', onDoc, true);
      document.addEventListener('keydown', onKey, true);
      window.addEventListener('resize', onWin);
      window.addEventListener('scroll', onScroll, true);

      csOpen = { trigger: trigger, panel: panel, onDoc: onDoc, onKey: onKey, onWin: onWin, onScroll: onScroll };
      trigger.classList.add('open');
    }

    return trigger;
  }

  /* 纵向下拉（自动向上/向下） */
  function customSelect(options, value, onChange) {
    return buildCS(options, value, onChange, 'v');
  }

  /* 横向下拉（自动向左/向右，备用） */
  function customSelectH(options, value, onChange) {
    return buildCS(options, value, onChange, 'h');
  }

  function switchRow(label, checked, onChange) {
    var w = document.createElement('label');
    w.className = 'switch';
    var cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = !!checked;
    w.appendChild(cb);
    var tr = document.createElement('span'); tr.className = 'track'; w.appendChild(tr);
    var t = document.createElement('span'); t.textContent = label; w.appendChild(t);
    cb.addEventListener('change', function () { onChange(this.checked); });
    return w;
  }

  function eqBandRow(freq, val, onInput) {
    var row = document.createElement('div');
    row.className = 'eq-row';
    var lb = document.createElement('span');
    lb.className = 'eq-lb';
    lb.textContent = freq >= 1000 ? (freq / 1000) + 'k' : String(freq);
    var r = document.createElement('input');
    r.type = 'range'; r.className = 'slider';
    r.min = -18; r.max = 18; r.step = SLIDER_STEP; r.value = val;
    var v = document.createElement('span');
    v.className = 'eq-val';
    v.textContent = (val > 0 ? '+' : '') + (+val).toFixed(2);
    r.addEventListener('input', function () {
      var g = parseFloat(this.value);
      v.textContent = (g > 0 ? '+' : '') + g.toFixed(2);
      onInput(g);
    });
    r.addEventListener('change', function () { pushHistory(); });
    row.appendChild(lb); row.appendChild(r); row.appendChild(v);
    return { row: row };
  }

  /* 绘制均衡器频响曲线 */
  function drawEqCurve(canvas, eq, sr) {
    var w = canvas.clientWidth || 280;
    var h = 92;
    var dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    var g = canvas.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);

    sr = sr || 48000;
    var fMin = 20, fMax = Math.min(20000, sr / 2);
    var n = Math.max(24, Math.floor(w / 3));
    var freqs = new Float32Array(n);
    for (var i = 0; i < n; i++) freqs[i] = fMin * Math.pow(fMax / fMin, i / (n - 1));
    var resp = DSP.eqResponse(eq, sr, freqs);

    function yOf(db) { return h / 2 - Math.max(-18, Math.min(18, db)) / 18 * (h / 2 - 7); }

    g.strokeStyle = 'rgba(10,132,255,0.16)'; g.lineWidth = 1;
    var marks = [-12, -6, 6, 12];
    for (var m = 0; m < marks.length; m++) {
      var yy = yOf(marks[m]);
      g.beginPath(); g.moveTo(0, yy + 0.5); g.lineTo(w, yy + 0.5); g.stroke();
    }
    g.strokeStyle = 'rgba(10,132,255,0.32)';
    g.beginPath(); g.moveTo(0, h / 2 + 0.5); g.lineTo(w, h / 2 + 0.5); g.stroke();

    var xs = new Float32Array(n), ys = new Float32Array(n);
    for (var k = 0; k < n; k++) { xs[k] = k / (n - 1) * w; ys[k] = yOf(resp[k]); }

    g.beginPath();
    g.moveTo(xs[0], h / 2);
    for (var a = 0; a < n; a++) g.lineTo(xs[a], ys[a]);
    g.lineTo(xs[n - 1], h / 2);
    g.closePath();
    var fg = g.createLinearGradient(0, 0, 0, h);
    fg.addColorStop(0, 'rgba(46,155,255,0.26)');
    fg.addColorStop(1, 'rgba(46,155,255,0.02)');
    g.fillStyle = fg; g.fill();

    g.beginPath();
    g.moveTo(xs[0], ys[0]);
    for (var j = 1; j < n; j++) g.lineTo(xs[j], ys[j]);
    g.strokeStyle = '#0a84ff';
    g.lineWidth = 2.4; g.lineJoin = 'round';
    g.stroke();
  }

  function buildClipInsp(c) {
    if (!c) { inspBody.appendChild(emptyInsp()); return; }
    var t = track(c.trackId);

    var title = document.createElement('div');
    title.className = 'insp-title';
    title.innerHTML = '<span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 18V5l10-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/></svg></span>';
    var nm = document.createElement('input');
    nm.className = 'input'; nm.value = c.name; nm.style.height = '34px';
    nm.addEventListener('input', function () {
      c.name = this.value;
      var el = clipEls.get(c.id); if (el) el.querySelector('.tag').textContent = c.name;
    });
    nm.addEventListener('change', pushHistory);
    title.appendChild(nm);
    inspBody.appendChild(title);

    /* --- 声道 L / R（精简）--- */
    var sc = sec('声道 L / R');
    sc.appendChild(chanField('左声道', c, 'gainL'));
    sc.appendChild(chanField('右声道', c, 'gainR'));
    sc.appendChild(selectField('声道模式', [
      { v: 'stereo', t: '立体声（默认）' },
      { v: 'left', t: '仅左声道' },
      { v: 'right', t: '仅右声道' },
      { v: 'swap', t: '左右交换' },
      { v: 'merge', t: '合并为单声道' }
    ], c.channelMode, function (v) { c.channelMode = v; refreshInspector(); renderClips(); }));
    inspBody.appendChild(sc);

    /* --- 变速 / 变调 --- */
    var sp = sec('变速 · 变调');
    var vanWrap = document.createElement('label');
    vanWrap.className = 'switch';
    var vcb = document.createElement('input');
    vcb.type = 'checkbox'; vcb.checked = c.vanilla;
    vanWrap.appendChild(vcb);
    var vtr = document.createElement('span'); vtr.className = 'track'; vanWrap.appendChild(vtr);
    var vlt = document.createElement('span'); vlt.textContent = '原版耦合（时长与音高同时变化）'; vanWrap.appendChild(vlt);
    vcb.addEventListener('change', function () {
      c.vanilla = this.checked;
      if (c.vanilla) c.ratio = pitchRatio(c);
      else { c.pitchUnit = 'ratio'; c.pitchValue = c.ratio; }
      pushHistory(); refreshInspector(); renderClips();
    });
    sp.appendChild(vanWrap);

    if (!c.vanilla) {
      sp.appendChild(sliderField('播放速度（精确 5 位小数）', 0.05, 10, 0.00001, c.speed, '×', function (v) {
        c.speed = v; relayoutClip(c);
      }));
      sp.appendChild(selectField('变调单位', [
        { v: 'ratio', t: '倍率 (×)' },
        { v: 'semitone', t: '半音 (semitone)' },
        { v: 'cent', t: '音分 (cent)' },
        { v: 'hz', t: '赫兹 (Hz 偏移 @A4=440)' }
      ], c.pitchUnit, function (v) {
        var r = pitchRatio(c);
        c.pitchUnit = v;
        c.pitchValue = v === 'ratio' ? +r.toFixed(5) : +DSP.ratioToPitch(r, v).toFixed(5);
        refreshInspector(); renderClips();
      }));
      sp.appendChild(sliderField('变调数值', pitchRange(c).min, pitchRange(c).max, pitchRange(c).step, c.pitchValue, '', function (v) {
        c.pitchValue = v; relayoutClip(c);
      }));
      sp.appendChild(hint('当前倍率 ' + pitchRatio(c).toFixed(5) + '× · 时长 ' + clipDur(c).toFixed(3) + ' s'));
    } else {
      sp.appendChild(sliderField('原版倍率（倍率 = 速度 = 音高）', 0.05, 10, 0.00001, c.ratio, '×', function (v) {
        c.ratio = v; relayoutClip(c);
      }));
      sp.appendChild(hint('时长 ' + clipDur(c).toFixed(3) + ' s · 音高 ' + c.ratio.toFixed(5) + '×'));
    }

    var rv = document.createElement('button');
    rv.className = 'btn' + (c.reversed ? ' primary' : '');
    rv.textContent = c.reversed ? '已反转 · 点击还原' : '反转音频';
    rv.addEventListener('click', function () { c.reversed = !c.reversed; pushHistory(); refreshInspector(); renderClips(); });
    sp.appendChild(rv);
    inspBody.appendChild(sp);

    /* --- 人声 / 伴奏分离（精简）--- */
    var sv = sec('人声 / 伴奏分离');
    var mono = srcs.get(c.srcId) && srcs.get(c.srcId).channels.length < 2;
    sv.appendChild(selectField('分离模式', [
      { v: 'off', t: '关闭' },
      { v: 'remove', t: '去人声（保留伴奏）' },
      { v: 'vocal', t: '去伴奏（保留人声）' }
    ], c.vocal.mode, function (v) { c.vocal.mode = v; refreshInspector(); renderClips(); }));
    if (c.vocal.mode !== 'off') {
      sv.appendChild(sliderField('分离强度', 0, 1, 0.01, c.vocal.strength, '', function (v) {
        c.vocal.strength = v;
      }));
    }
    if (mono) sv.appendChild(hint('单声道素材不支持该方法，请使用立体声文件。'));
    inspBody.appendChild(sv);

    /* --- 降噪（精简）--- */
    var sd = sec('降噪');
    sd.appendChild(switchRow('启用降噪', c.denoise.on, function (v) {
      c.denoise.on = v; pushHistory(); refreshInspector(); renderClips();
    }));
    if (c.denoise.on) {
      sd.appendChild(sliderField('降噪强度', 0, 1, 0.01, c.denoise.strength, '', function (v) { c.denoise.strength = v; }));
    }
    inspBody.appendChild(sd);

    /* --- 均衡器（精简：保留曲线 + 预设 + 10 段）--- */
    var sq = sec('均衡器');
    sq.appendChild(switchRow('启用均衡器', c.eq.on, function (v) {
      c.eq.on = v; pushHistory(); refreshInspector(); renderClips();
    }));
    if (c.eq.on) {
      var eqCanvas = document.createElement('canvas');
      eqCanvas.className = 'eq-canvas';
      sq.appendChild(eqCanvas);
      var srNow = srcs.get(c.srcId) ? srcs.get(c.srcId).sampleRate : 48000;
      var drawCurve = function () { drawEqCurve(eqCanvas, c.eq, srNow); };

      var PRESETS = {
        '平直': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        '低音增强': [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
        '人声增强': [-2, -1, 0, 1, 3, 4, 4, 3, 1, 0],
        '明亮': [-1, 0, 0, 0, 1, 2, 3, 4, 5, 5]
      };
      sq.appendChild(selectField('预设', Object.keys(PRESETS).map(function (k) { return { v: k, t: k }; }), '平直', function (k) {
        c.eq.gains = PRESETS[k].slice();
        refreshInspector(); renderClips();
      }));

      var bands = DSP.EQ_BANDS;
      for (var bi = 0; bi < bands.length; bi++) {
        (function (idx) {
          var row = eqBandRow(bands[idx], c.eq.gains[idx], function (g) {
            c.eq.gains[idx] = g;
            drawCurve();
          });
          sq.appendChild(row.row);
        })(bi);
      }
      requestAnimationFrame(drawCurve);
    }
    inspBody.appendChild(sq);

    /* --- 片段 --- */
    var sg = sec('片段');
    sg.appendChild(sliderField('音量 (dB)', -40, 12, 0.1, c.gainDb, 'dB', function (v) { c.gainDb = v; }));
    /* 淡入淡出只改两个宽度，代价极低，允许拖动时实时预览 */
    var fadePreview = function (key) {
      return function (v) { c[key] = Math.min(v, clipDur(c)); updateFades(); };
    };
    var fadeMax = Math.max(0.01, clipDur(c) / 2);
    sg.appendChild(sliderField('淡入 (s)', 0, fadeMax, 0.001, c.fadeIn, 's',
      fadePreview('fadeIn'), fadePreview('fadeIn')));
    sg.appendChild(sliderField('淡出 (s)', 0, fadeMax, 0.001, c.fadeOut, 's',
      fadePreview('fadeOut'), fadePreview('fadeOut')));
    inspBody.appendChild(sg);

    /* --- 常用操作 --- */
    var sop = sec('操作');
    var act = document.createElement('div');
    act.className = 'actions';
    var mk = function (txt, cls, fn) {
      var b = document.createElement('button'); b.className = 'btn ' + (cls || ''); b.textContent = txt;
      b.addEventListener('click', fn); act.appendChild(b);
    };
    mk('在播放头分割', '', function () { splitAt(S.playhead); });
    mk('复制片段', '', function () { duplicateClip(c.id); });
    mk('删除片段', 'ghost', function () { deleteClip(c.id); });
    sop.appendChild(act);

    var st2 = document.createElement('div');
    st2.className = 'field';
    var selLbl = document.createElement('div'); selLbl.className = 'lbl';
    var selT = document.createElement('span'); selT.textContent = '所属音轨';
    selLbl.appendChild(selT);
    var trackOptions = S.tracks.map(function (tr) { return { v: tr.id, t: tr.name }; });
    var trackSel = customSelect(trackOptions, c.trackId, function (v) {
      c.trackId = v; pushHistory(); renderAll();
    });
    st2.appendChild(selLbl); st2.appendChild(trackSel);
    sop.appendChild(st2);
    inspBody.appendChild(sop);
  }

  function chanField(label, c, key) {
    var other = key === 'gainL' ? 'gainR' : 'gainL';
    var f = sliderField(label + ' 增益', 0, 2, 0.001, c[key], '×',
      /* 松手才真正应用 */
      function (v) {
        c[key] = v;
        if (c.link) c[other] = v;
        var el = clipEls.get(c.id);
        if (el) el.querySelector('.badges').innerHTML = clipBadges(c);
      },
      /* 拖动中只联动对侧滑条的显示，不重算 */
      function (v) {
        if (!c.link) return;
        var peer = chanSync[other];
        if (peer) peer.set(v);
      });
    var wrap = f.lastChild;
    chanSync[key] = {
      set: function (v) {
        wrap.children[0].value = v;
        wrap.children[1].value = +(+v).toFixed(5);
      }
    };
    f.dataset.chan = key;
    return f;
  }
  var chanSync = {};

  function pitchRange(c) {
    switch (c.pitchUnit) {
      case 'semitone': return { min: -24, max: 24, step: 0.001 };
      case 'cent': return { min: -1200, max: 1200, step: 0.01 };
      case 'hz': return { min: -400, max: 400, step: 0.01 };
      default: return { min: 0.25, max: 4, step: 0.00001 };
    }
  }

  function hint(text) {
    var d = document.createElement('div');
    d.className = 'hint';
    d.textContent = text;
    return d;
  }

  function buildTrackInsp(t) {
    if (!t) { inspBody.appendChild(emptyInsp()); return; }
    var title = document.createElement('div');
    title.className = 'insp-title';
    title.innerHTML = '<span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></span>';
    var inp = document.createElement('input');
    inp.className = 'input'; inp.value = t.name; inp.style.height = '34px';
    inp.addEventListener('input', function () { t.name = this.value; var e = rowEls.get(t.id); if (e) e.head.querySelector('.name').value = t.name; });
    inp.addEventListener('change', pushHistory);
    title.appendChild(inp);
    inspBody.appendChild(title);

    var sc = sec('声道 L / R');
    sc.appendChild(sliderField('左声道增益', 0, 2, 0.001, t.gainL, '×', function (v) { t.gainL = v; }));
    sc.appendChild(sliderField('右声道增益', 0, 2, 0.001, t.gainR, '×', function (v) { t.gainR = v; }));
    sc.appendChild(selectField('声道模式', [
      { v: 'stereo', t: '立体声（默认）' },
      { v: 'left', t: '仅左声道' },
      { v: 'right', t: '仅右声道' },
      { v: 'swap', t: '左右交换' },
      { v: 'merge', t: '合并为单声道' }
    ], t.channelMode, function (v) { t.channelMode = v; }));
    inspBody.appendChild(sc);

    var sm = sec('轨道');
    sm.appendChild(sliderField('音量 (dB)', -40, 12, 0.1, t.gainDb, 'dB', function (v) {
      t.gainDb = v;
      var e = rowEls.get(t.id); if (e) e.head.querySelector('.slider').value = v;
    }));
    sm.appendChild(sliderField('轨道高度', LANE_MIN_H, LANE_MAX_H, 1, t.height, 'px', function (v) {
      t.height = v;
      var e = rowEls.get(t.id);
      if (e) { e.row.style.height = v + 'px'; drawAllWaves(); }
      layoutPlayhead();
    }));
    inspBody.appendChild(sm);

    var ac = sec('操作');
    var ab = document.createElement('div'); ab.className = 'actions';
    var b1 = document.createElement('button'); b1.className = 'btn'; b1.textContent = '清空该轨';
    b1.addEventListener('click', function () {
      S.clips = S.clips.filter(function (c) { return c.trackId !== t.id; });
      pushHistory();
      renderAll(); refreshInspector();
    });
    var bDelT = document.createElement('button'); bDelT.className = 'btn danger'; bDelT.textContent = '删除该音轨';
    bDelT.addEventListener('click', function () { removeTrack(t.id); });
    ab.appendChild(b1); ab.appendChild(bDelT);
    ac.appendChild(ab);
    inspBody.appendChild(ac);
  }

  /* 删除音轨（至少保留一条） */
  function removeTrack(tid) {
    if (S.tracks.length <= 1) { toast('至少保留一条音轨', 'err'); return; }
    var idx = trackIdx(tid);
    if (idx < 0) return;
    S.clips = S.clips.filter(function (c) { return c.trackId !== tid; });
    S.tracks.splice(idx, 1);
    if (S.activeTrack === tid) {
      S.activeTrack = S.tracks[Math.max(0, idx - 1)].id;
    }
    if (S.selection && S.selection.type === 'track' && S.selection.id === tid) {
      S.selection = null;
    }
    pushHistory();
    renderAll();
    refreshInspector();
    toast('已删除音轨', 'ok');
  }

  function relayoutClip(c) {
    var el = clipEls.get(c.id);
    if (!el) { renderClips(); refreshInspector(); return; }
    el.style.left = (c.start * S.pxPerSec) + 'px';
    el.style.width = Math.max(6, clipDur(c) * S.pxPerSec) + 'px';
    el.querySelector('.badges').innerHTML = clipBadges(c);
    /* 只有这个片段的宽度变了，其余片段波形不受影响，不必重画 */
    drawOneWave(c);
    updateFades();
    layoutPlayhead();
    updateStatus();
  }

  /* ============================ 交互：选择 / 拖动 / 裁剪 ============================ */

  var drag = null;

  function laneRect(tid) {
    var r = rowEls.get(tid);
    return r ? r.lane.getBoundingClientRect() : null;
  }

  function laneTimeFromX(clientX, tid) {
    var rect = laneRect(tid);
    if (!rect) return 0;
    return Math.max(0, (clientX - rect.left) / S.pxPerSec);
  }

  function snapPoints(excludeId) {
    var pts = [0, S.playhead];
    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i];
      if (c.id === excludeId) continue;
      pts.push(c.start, clipEnd(c));
    }
    return pts;
  }

  function applySnap(t, excludeId, tol) {
    if (!S.snap || drag.alt) return t;
    var pts = snapPoints(excludeId);
    var best = t, bd = (tol || SNAP_PX) / S.pxPerSec;
    for (var i = 0; i < pts.length; i++) {
      var d = Math.abs(pts[i] - t);
      if (d < bd) { bd = d; best = pts[i]; }
    }
    return Math.max(0, best);
  }

  function pickTrackAt(clientY) {
    var best = null, bd = 1e9;
    rowEls.forEach(function (r, id) {
      var rect = r.lane.getBoundingClientRect();
      if (clientY >= rect.top - 10 && clientY <= rect.bottom + 10) {
        var d = Math.abs(clientY - (rect.top + rect.height / 2));
        if (d < bd) { bd = d; best = id; }
      }
    });
    return best;
  }

  tracksEl.addEventListener('mousedown', function (e) {
    var clipEl = e.target.closest('.clip');
    var laneEl = e.target.closest('.lane');

    if (S.tool === 'split') {
      if (laneEl) {
        var tid = laneEl.dataset.track;
        var tt = laneTimeFromX(e.clientX, tid);
        splitAt(tt, tid);
      }
      return;
    }

    if (!clipEl) {
      if (laneEl) {
        S.activeTrack = laneEl.dataset.track;
        S.selection = null;
        renderTracks(); refreshInspector();
        setPlayhead(laneTimeFromX(e.clientX, S.activeTrack));
      }
      return;
    }

    var c = clip(clipEl.dataset.clip);
    if (!c) return;
    S.activeTrack = c.trackId;
    S.selection = { type: 'clip', id: c.id };

    clipEls.forEach(function (el) { el.classList.remove('selected'); });
    clipEl.classList.add('selected');
    rowEls.forEach(function (r, id) { r.head.classList.toggle('active', id === c.trackId); });
    refreshInspector();

    var rect = clipEl.getBoundingClientRect();
    var which = e.target.classList.contains('handle') ? (e.target.classList.contains('l') ? 'trimL' : 'trimR')
      : e.target.classList.contains('fdot') ? (e.target.classList.contains('in') ? 'fadeIn' : 'fadeOut')
        : 'move';

    drag = {
      mode: which, id: c.id, alt: e.altKey,
      grabT: (e.clientX - rect.left) / S.pxPerSec,
      x0: e.clientX, y0: e.clientY,
      start: c.start, offset: c.offset, srcDur: c.srcDur,
      fadeIn: c.fadeIn, fadeOut: c.fadeOut,
      moved: false, trackId: c.trackId, dur: clipDur(c)
    };
    clipEl.classList.add('dragging');
    e.preventDefault();
  });

  window.addEventListener('mousemove', function (e) {
    if (!drag) return;
    var c = clip(drag.id);
    if (!c) { drag = null; return; }
    var el = clipEls.get(c.id);
    var dx = (e.clientX - drag.x0) / S.pxPerSec;
    if (Math.abs(e.clientX - drag.x0) > 2 || Math.abs(e.clientY - drag.y0) > 2) drag.moved = true;

    if (drag.mode === 'move') {
      var nt = drag.start + dx;
      nt = applySnap(nt, c.id);
      nt = Math.max(0, nt);
      c.start = nt;
      el.style.left = (c.start * S.pxPerSec) + 'px';

      var tid = pickTrackAt(e.clientY);
      if (tid && tid !== c.trackId) {
        c.trackId = tid;
        var r = rowEls.get(tid);
        if (r) r.lane.appendChild(el);
        rowEls.forEach(function (rr, id) { rr.head.classList.toggle('active', id === tid); });
        S.activeTrack = tid;
      }
      S.selection = { type: 'clip', id: c.id };
    } else if (drag.mode === 'trimL') {
      var src = srcs.get(c.srcId);
      var maxShift = drag.srcDur - MIN_CLIP;
      var shift = clamp(dx, -drag.offset, maxShift);
      var ns = drag.start + shift;
      if (S.snap && !drag.alt) {
        var sp = snapPoints(c.id), bd = SNAP_PX / S.pxPerSec;
        for (var i = 0; i < sp.length; i++) { if (Math.abs(sp[i] - ns) < bd) { shift = sp[i] - drag.start; break; } }
        shift = clamp(shift, -drag.offset, maxShift);
      }
      c.start = Math.max(0, drag.start + shift);
      c.offset = drag.offset + shift;
      c.srcDur = drag.srcDur - shift;
      el.style.left = (c.start * S.pxPerSec) + 'px';
      el.style.width = Math.max(6, clipDur(c) * S.pxPerSec) + 'px';
      drawAllWaves();
    } else if (drag.mode === 'trimR') {
      var maxLen = srcs.get(c.srcId) ? srcs.get(c.srcId).duration - drag.offset : drag.srcDur * 4;
      var nl = clamp(drag.srcDur + dx * (c.vanilla ? c.ratio : c.speed), MIN_CLIP, maxLen);
      if (S.snap && !drag.alt) {
        var nowEnd = drag.start + (nl / (c.vanilla ? c.ratio : c.speed));
        var sp2 = snapPoints(c.id), bd2 = SNAP_PX / S.pxPerSec;
        for (var j = 0; j < sp2.length; j++) {
          if (Math.abs(sp2[j] - nowEnd) < bd2) { nl = (sp2[j] - drag.start) * (c.vanilla ? c.ratio : c.speed); break; }
        }
      }
      c.srcDur = clamp(nl, MIN_CLIP, maxLen);
      el.style.width = Math.max(6, clipDur(c) * S.pxPerSec) + 'px';
      drawAllWaves();
    } else if (drag.mode === 'fadeIn') {
      c.fadeIn = clamp(drag.fadeIn + dx, 0, clipDur(c));
      updateFades();
    } else if (drag.mode === 'fadeOut') {
      c.fadeOut = clamp(drag.fadeOut - dx, 0, clipDur(c));
      updateFades();
    }
    layoutPlayhead();
  });

  window.addEventListener('mouseup', function () {
    if (!drag) return;
    var c = clip(drag.id);
    var el = c ? clipEls.get(c.id) : null;
    if (el) el.classList.remove('dragging');
    if (drag.moved && c) {
      pushHistory();
      var elA = clipEls.get(c.id);
      if (elA) elA.querySelector('.badges').innerHTML = clipBadges(c);
      updateStatus();
    }
    drag = null;
  });

  /* ============================ 播放头 ============================ */

  function setPlayhead(t, noRender) {
    S.playhead = Math.max(0, t);
    if (!noRender) layoutPlayhead();
    updateTimecode();
  }

  function bindScrub(el) {
    el.addEventListener('mousedown', function (e) {
      var rect = laneRect(S.activeTrack || (S.tracks[0] && S.tracks[0].id));
      var base = rect ? rect.left : 0;
      var w = el === rulerEl ? rulerEl.getBoundingClientRect().left : base;
      var move = function (ev) {
        setPlayhead((ev.clientX - w) / S.pxPerSec);
      };
      move(e);
      var up = function () { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
      e.preventDefault();
    });
  }

  /* ============================ 播放 ============================ */

  function buildItems() {
    var items = [];
    var P = S.playhead;
    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i];
      var t = track(c.trackId);
      if (!t || !isAudible(t)) continue;
      var rec = getAudio(c);
      if (!rec || !rec.channels.length) continue;
      var D = clipDur(c);
      if (P >= c.start + D) continue;
      var localOffset = Math.max(0, P - c.start);
      if (localOffset >= D) continue;
      var remaining = D - localOffset;
      var chans = rec.channels;
      /* 从 localOffset 起截取 */
      var sr = rec.sampleRate;
      var from = Math.round(localOffset * sr);
      var cut = [];
      for (var k = 0; k < chans.length; k++) cut.push(chans[k].subarray(from));

      items.push({
        channels: cut,
        sampleRate: sr,
        delay: Math.max(0, c.start - P),
        offset: 0,
        clipDur: remaining,
        gain: Engine.dbToGain(c.gainDb + t.gainDb),
        volume: 1,
        pan: clamp((c.pan || 0) + (t.pan || 0), -1, 1),
        gainL: (c.gainL === undefined ? 1 : c.gainL) * (t.gainL === undefined ? 1 : t.gainL),
        gainR: (c.gainR === undefined ? 1 : c.gainR) * (t.gainR === undefined ? 1 : t.gainR),
        channelMode: c.channelMode !== 'stereo' ? c.channelMode : (t.channelMode || 'stereo'),
        fadeIn: Math.max(0, c.fadeIn - localOffset),
        fadeOut: c.fadeOut,
        _clip: c
      });
    }
    return items;
  }

  var playStart = 0;
  var playing = false;

  function togglePlay() { playing ? pause() : doPlay(); }

  function doPlay() {
    var end = timelineEnd();
    if (end <= 0.001) { toast('先导入一段音频吧', 'err'); return; }
    if (S.playhead >= end - 0.005) S.playhead = 0;
    Engine.ensure();
    var items = buildItems();
    if (!items.length) { toast('播放头之后没有可播放的片段', 'err'); return; }

    var remain = end - S.playhead;
    playStartOrigin = S.playhead;
    Engine.play(items, {
      total: remain,
      onTick: function (pos) {
        S.playhead = playStartOrigin + pos;
        layoutPlayhead();
        updateTimecode();
        followPlayhead();
      },
      onEnd: function () { playing = false; setPlayIcon(false); S.playhead = end; layoutPlayhead(); updateTimecode(); }
    });
    playStartOrigin = S.playhead;
    playing = true;
    setPlayIcon(true);
  }

  var playStartOrigin = 0;

  function pause() {
    Engine.stop();
    playing = false;
    setPlayIcon(false);
  }

  function setPlayIcon(on) {
    $('icoPlay').innerHTML = on
      ? '<rect x="7" y="5.5" width="3.6" height="13" rx="1.6"/><rect x="13.4" y="5.5" width="3.6" height="13" rx="1.6"/>'
      : '<path d="M8 5.5v13a1 1 0 0 0 1.5.87l11-6.5a1 1 0 0 0 0-1.74l-11-6.5A1 1 0 0 0 8 5.5Z"/>';
    $('txtPlay').textContent = on ? '暂停' : '播放';
    $('btnPlay').classList.toggle('on', on);
  }

  function followPlayhead() {
    var x = S.playhead * S.pxPerSec;
    var left = tlScroll.scrollLeft;
    var view = tlScroll.clientWidth - headWidth();
    if (x < left + 40) tlScroll.scrollLeft = Math.max(0, x - 40);
    else if (x > left + view - 80) tlScroll.scrollLeft = x - view + 80;
  }

  /* ============================ 编辑操作 ============================ */

  function splitAt(t, onlyTrack) {
    var list = S.clips.filter(function (c) {
      if (onlyTrack) return c.trackId === onlyTrack && t > c.start + 0.001 && t < clipEnd(c) - 0.001;
      if (S.selection && S.selection.type === 'clip' && S.selection.id === c.id) {
        return t > c.start + 0.001 && t < clipEnd(c) - 0.001;
      }
      if (S.activeTrack && c.trackId !== S.activeTrack) return false;
      return t > c.start + 0.001 && t < clipEnd(c) - 0.001;
    });
    if (!list.length) { toast('播放头位置没有可分割的片段', 'err'); return; }
    list.forEach(function (c) {
      var leftDur = t - c.start;                    // 时间轴秒
      var factor = c.vanilla ? c.ratio : c.speed;
      var leftSrc = leftDur * factor;               // 源秒
      var right = plainClip(JSON.parse(JSON.stringify(c)));
      right.id = uid('cl');
      right.start = t;
      right.offset = c.offset + leftSrc;
      right.srcDur = c.srcDur - leftSrc;
      right.fadeIn = 0;
      c.srcDur = leftSrc;
      c.fadeOut = 0;
      S.clips.push(right);
    });
    pushHistory();
    renderAll();
    refreshInspector();
    toast('已分割 ' + list.length + ' 个片段', 'ok');
  }

  function deleteClip(id) {
    var i = S.clips.findIndex(function (c) { return c.id === id; });
    if (i < 0) return;
    var el = clipEls.get(id);
    S.clips.splice(i, 1);
    clipAudio.delete(id);
    pushHistory();
    if (el) {
      el.classList.add('leaving');
      setTimeout(function () { renderAll(); }, 190);
    } else renderAll();
    S.selection = null;
    refreshInspector();
    toast('已删除片段', 'ok');
  }

  function duplicateClip(id) {
    var c = clip(id);
    if (!c) return;
    var n = plainClip(JSON.parse(JSON.stringify(c)));
    n.id = uid('cl');
    n.name = c.name + ' 副本';
    n.start = clipEnd(c);
    S.clips.push(n);
    pushHistory();
    renderAll();
    S.selection = { type: 'clip', id: n.id };
    clipEls.forEach(function (el, cid) { el.classList.toggle('selected', cid === n.id); });
    refreshInspector();
  }

  function clearAll() {
    if (!S.clips.length) return;
    S.clips = [];
    clipAudio.clear();
    pushHistory();
    renderAll();
    refreshInspector();
    toast('已清空全部片段', 'ok');
  }

  /* ============================ 导入 ============================ */

  var importQueue = Promise.resolve();

  /* 可放行的媒体扩展名（音频 + 视频容器）。
     注意：decodeAudioData 是按字节内容嗅探容器的，不看扩展名，
     所以这里只负责"放行"，真正能否解码由浏览器决定。
     视频文件会自动只取其中的音轨，实现视频转音频导入。 */
  var MEDIA_EXT = /\.(wav|wave|mp3|mp2|mpga|ogg|oga|opus|flac|m4a|m4b|aac|weba|mp4|m4v|mov|qt|webm|mkv|ogv|ts|mts|m2ts|3gp|3g2)$/i;
  var VIDEO_EXT = /\.(mp4|m4v|mov|qt|webm|mkv|ogv|ts|mts|m2ts|3gp|3g2)$/i;

  function isMediaFile(f) {
    if (/^(audio|video)\//.test(f.type)) return true;
    return MEDIA_EXT.test(f.name || '');
  }

  function isVideoFile(f) {
    return /^video\//.test(f.type) || VIDEO_EXT.test(f.name || '');
  }

  function importFiles(files, trackId) {
    var all = Array.prototype.slice.call(files);
    files = all.filter(isMediaFile);
    if (!files.length) {
      toast(all.length ? '不支持的文件格式：' + all[0].name : '没有识别到音频/视频文件', 'err');
      return;
    }
    busy(true, '正在解码 ' + files.length + ' 个文件…');

    var ok = 0, fromVideo = 0, failed = [];

    importQueue = importQueue.then(function () {
      return files.reduce(function (p, f) {
        return p.then(function () {
          return f.arrayBuffer().then(function (ab) {
            return Engine.decode(ab).then(function (dec) {
              var sid = 'src_' + (srcSeq++);
              srcs.set(sid, {
                channels: dec.channels, sampleRate: dec.sampleRate,
                duration: dec.duration, name: f.name
              });
              placeClip(sid, f.name, trackId);
              ok++;
              if (isVideoFile(f)) fromVideo++;
            }).catch(function (err) {
              failed.push(f.name);
              console.warn('解码失败：' + f.name, err);
            });
          });
        });
      }, Promise.resolve());
    }).then(function () {
      busy(false);
      renderAll();
      if (ok) pushHistory();

      if (!ok) {
        toast('全部解码失败，浏览器不支持这些文件的编码格式', 'err');
      } else if (failed.length) {
        toast('已导入 ' + ok + ' 个' + (fromVideo ? '（含 ' + fromVideo + ' 个视频提取音频）' : '') +
          '，' + failed.length + ' 个失败', 'err');
      } else {
        toast('已导入 ' + ok + ' 个文件' +
          (fromVideo ? '（其中 ' + fromVideo + ' 个由视频提取音频）' : ''), 'ok');
      }
    }).catch(function (e) {
      busy(false);
      toast('导入失败：' + (e && e.message ? e.message : e), 'err');
    });
  }

  /* 桌面版：Python 已经把文件解码成 PCM，这里只做登记与建片段 */
  function registerPyItems(res, trackId) {
    var items = (res && res.items) || [];
    var failed = (res && res.failed) || [];
    var ok = 0, fromVideo = 0;

    items.forEach(function (it) {
      var sid = 'src_' + (srcSeq++);
      srcs.set(sid, {
        channels: it.channels, sampleRate: it.sampleRate,
        duration: it.duration, name: it.name
      });
      placeClip(sid, it.name, trackId);
      ok++;
      if (it.hasVideo) fromVideo++;
    });

    renderAll();
    if (ok) pushHistory();

    if (!ok) {
      var first = failed.length ? failed[0] : null;
      toast(first ? ('导入失败：' + first.name + '（' + first.error + '）')
        : '没有可导入的文件', 'err');
      return;
    }
    if (failed.length) {
      toast('已导入 ' + ok + ' 个' + (fromVideo ? '（含 ' + fromVideo + ' 个视频提取音频）' : '') +
        '，' + failed.length + ' 个失败', 'err');
    } else {
      toast('已导入 ' + ok + ' 个文件' +
        (fromVideo ? '（其中 ' + fromVideo + ' 个由视频提取音频）' : ''), 'ok');
    }
  }

  /* 桌面版：走 Python 的原生文件对话框 */
  function importViaPython(trackId) {
    var p = py();
    if (!p) { $('fileInput').click(); return; }
    busy(true, '正在用 Python 解码…');
    p.importViaDialog(function (res) {
      busy(false);
      if (res === null) return;             // 用户取消
      if (res && res.error) { toast('导入失败：' + res.error, 'err'); return; }
      registerPyItems(res, trackId);
    });
  }

  /* 统一的导入入口：桌面版走 Python，浏览器版走 <input type=file> */
  function startImport(trackId) {
    if (py()) importViaPython(trackId);
    else $('fileInput').click();
  }

  /* 把已解码素材放到音轨（自动找空位，避免重叠） */
  function placeClip(sid, name, trackId) {
    var src = srcs.get(sid);
    var tid = trackId || S.activeTrack || S.tracks[S.tracks.length - 1].id;
    if (!track(tid)) tid = S.tracks[S.tracks.length - 1].id;

    var start = S.playhead;
    var guard = 0;
    while (overlaps(tid, start, src.duration) && guard++ < 60) {
      start += 0.25;
    }
    var t = track(tid);
    var c = plainClip({
      id: uid('cl'),
      trackId: tid,
      name: name.replace(/\.[^.]+$/, ''),
      start: start,
      offset: 0,
      srcDur: src.duration,
      srcId: sid,
      color: t.color
    });
    S.clips.push(c);
    return c;
  }

  function overlaps(tid, start, dur) {
    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i];
      if (c.trackId !== tid) continue;
      if (start < clipEnd(c) - 0.001 && start + dur > c.start + 0.001) return true;
    }
    return false;
  }

  function bindLaneDrop(lane, tid) {
    lane.addEventListener('dragover', function (e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      lane.classList.add('drop-target');
    });
    lane.addEventListener('dragleave', function () { lane.classList.remove('drop-target'); });
    lane.addEventListener('drop', function (e) {
      e.preventDefault();
      lane.classList.remove('drop-target');
      if (e.dataTransfer.files && e.dataTransfer.files.length) importFiles(e.dataTransfer.files, tid);
    });
  }

  /* ============================ 导出 ============================ */

  var expMask = $('exportMask');

  /* 导出配置：格式能力表 */
  var EXP_FORMATS = [
    { v: 'wav', t: 'WAV（无损）', ext: 'wav', lossy: false },
    { v: 'aiff', t: 'AIFF（无损）', ext: 'aiff', lossy: false },
    { v: 'mp3', t: 'MP3（兼容最广）', ext: 'mp3', lossy: true },
    { v: 'opus', t: 'OGG Opus（体积小）', ext: 'opus', lossy: true },
    { v: 'm4a', t: 'M4A / AAC（苹果）', ext: 'm4a', lossy: true }
  ];

  var expCfg = { fmt: 'wav', depth: 24, rate: 48000, ch: 2, kbps: 192 };

  /* 桌面版由 Python 提供可用格式（含 FLAC、24/32-bit WAV 等），
     浏览器版用上面的内置清单 */
  function expFormats() {
    var p = py();
    if (p && p.caps && p.caps.exports && p.caps.exports.length) {
      return p.caps.exports.map(function (x) {
        return { v: x.key, t: x.name, ext: x.ext, lossy: !x.lossless, py: true, desc: x.desc };
      });
    }
    return EXP_FORMATS;
  }

  function expFormat() {
    var list = expFormats();
    for (var i = 0; i < list.length; i++) {
      if (list[i].v === expCfg.fmt) return list[i];
    }
    /* 当前格式在桌面版里不存在（例如 FLAC 切回浏览器版）时回落到第一个 */
    expCfg.fmt = list[0].v;
    return list[0];
  }

  /* 该格式实际使用的渲染采样率 */
  function expRenderRate() {
    if (expCfg.fmt === 'opus') return 48000;          // Opus 内部固定 48 kHz
    if (expCfg.fmt === 'mp3') return Codec.mp3Rate(expCfg.rate) ? expCfg.rate : 48000;
    return expCfg.rate;
  }

  function mountExpSelect(slotId, options, value, onChange) {
    var slot = $(slotId);
    slot.innerHTML = '';
    slot.appendChild(customSelect(options, value, function (v) {
      onChange(v);
      buildExportForm();
    }));
  }

  /* 依据当前格式重建弹窗表单（隐藏无关项） */
  function buildExportForm() {
    var f = expFormat();
    var inPy = !!(f.py);

    mountExpSelect('expFmtSlot', expFormats().map(function (x) { return { v: x.v, t: x.t }; }),
      expCfg.fmt, function (v) { expCfg.fmt = v; });

    /* 桌面版：位深已经写进格式本身（WAV 16/24/32 是三个独立格式），不再单独选 */
    $('expDepthField').style.display = f.lossy ? 'none' : '';
    if (inPy) $('expDepthField').style.display = 'none';
    $('expKbpsField').style.display = f.lossy ? '' : 'none';
    $('expKbpsField').style.gridColumn = '1 / 2';

    if (!f.lossy && !inPy) {
      /* AIFF 只提供 16/24-bit：中间缓冲为 Float32，32-bit 整数无法真正达到 32 位精度 */
      var depths = f.v === 'aiff'
        ? [{ v: 16, t: '16-bit PCM' }, { v: 24, t: '24-bit PCM' }]
        : [{ v: 16, t: '16-bit PCM' }, { v: 24, t: '24-bit PCM' }, { v: 32, t: '32-bit 浮点' }];
      if (!depths.some(function (d) { return d.v === expCfg.depth; })) expCfg.depth = 24;
      mountExpSelect('expDepthSlot', depths, expCfg.depth, function (v) { expCfg.depth = +v; });
    }

    /* 采样率：桌面版由 ffmpeg 负责重采样，组合更自由；
       浏览器版受各自编码器限制（Opus 固定 48k，MP3 无 96k） */
    var rateOpts;
    var standard = [{ v: 44100, t: '44100 Hz' }, { v: 48000, t: '48000 Hz' }, { v: 96000, t: '96000 Hz' }];
    if (inPy) {
      rateOpts = expCfg.fmt === 'opus'
        ? [{ v: 48000, t: '48000 Hz（Opus 固定）' }]
        : standard;
      if (expCfg.fmt === 'opus') expCfg.rate = 48000;
      else if (rateOpts.every(function (r) { return r.v !== expCfg.rate; })) expCfg.rate = 48000;
    } else if (expCfg.fmt === 'opus') {
      rateOpts = [{ v: 48000, t: '48000 Hz（固定）' }];
      expCfg.rate = 48000;
    } else if (expCfg.fmt === 'mp3') {
      rateOpts = [{ v: 44100, t: '44100 Hz' }, { v: 48000, t: '48000 Hz' }];
      if (!Codec.mp3Rate(expCfg.rate)) expCfg.rate = 48000;
      if (expCfg.rate === 96000) expCfg.rate = 48000;
    } else {
      rateOpts = standard;
      if (expCfg.rate !== 44100 && expCfg.rate !== 48000 && expCfg.rate !== 96000) expCfg.rate = 48000;
    }
    mountExpSelect('expRateSlot', rateOpts, expCfg.rate, function (v) { expCfg.rate = +v; });

    mountExpSelect('expChSlot',
      [{ v: 2, t: '立体声' }, { v: 1, t: '单声道' }],
      expCfg.ch, function (v) { expCfg.ch = +v; });

    if (f.lossy) {
      var rates = f.v === 'opus'
        ? [{ v: 64, t: '64 kbps' }, { v: 96, t: '96 kbps' }, { v: 128, t: '128 kbps' }, { v: 192, t: '192 kbps' }, { v: 256, t: '256 kbps' }, { v: 320, t: '320 kbps' }]
        : f.v === 'mp3'
          ? [{ v: 128, t: '128 kbps' }, { v: 192, t: '192 kbps' }, { v: 256, t: '256 kbps' }, { v: 320, t: '320 kbps' }]
          : [{ v: 128, t: '128 kbps' }, { v: 192, t: '192 kbps' }, { v: 256, t: '256 kbps' }];
      var ok = rates.some(function (r) { return r.v === expCfg.kbps; });
      if (!ok) expCfg.kbps = rates[Math.min(1, rates.length - 1)].v;
      mountExpSelect('expKbpsSlot', rates, expCfg.kbps, function (v) { expCfg.kbps = +v; });
    }

    var hints = {
      wav: 'WAV 无损 PCM，兼容一切软件。',
      aiff: 'AIFF 无损大端 PCM，macOS 与专业音频软件通用。',
      mp3: 'MP3 兼容性最广，体积小、有损压缩。',
      opus: 'OGG Opus 同音质体积最小（约 WAV 的 1/10），适合分享。',
      m4a: 'M4A / AAC 为苹果生态默认格式，剪映、QuickTime 可直接使用。'
    };
    $('expHint').textContent = f.desc || hints[f.v] || '';
  }

  function openExport() {
    buildExportForm();
    expMask.classList.add('open');
  }
  function closeExport() { expMask.classList.remove('open'); }

  /* 把编码结果保存为文件 */
  function saveBytes(bytes, mime, filename, done) {
    var blob = new Blob([bytes], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    done(filename);
  }

  function doExport() {
    var end = timelineEnd();
    if (end <= 0.001) { toast('没有可导出的内容', 'err'); return; }

    var f = expFormat();
    var rate = expRenderRate();
    var chans = expCfg.ch;
    var norm = $('expNormalize').checked;
    var name = ($('expName').value || 'Qazr-混音导出').replace(/[\\/:*?"<>|]/g, '_');

    /* 先探测浏览器是否支持该编码（桌面版由 Python 编码，无需探测） */
    var probe = Promise.resolve(true);
    if (!f.py) {
      if (f.v === 'mp3') probe = Promise.resolve(Codec.hasLame());
      else if (f.v === 'opus') probe = Codec.supports('opus', 48000, chans);
      else if (f.v === 'm4a') probe = Codec.supports('mp4a.40.2', rate, chans);
    }

    probe.then(function (ok) {
      if (!ok) {
        toast(f.v === 'mp3' ? 'MP3 编码器未加载' : '当前浏览器不支持 ' + f.t + ' 编码', 'err');
        return;
      }

      busy(true, '正在离线渲染…');
      $('expBar').style.width = '10%';

      var items = buildItemsFull();
      if (!items.length) { busy(false); toast('没有可导出的音频', 'err'); return; }

      setTimeout(function () {
        Engine.render(items, { sampleRate: rate, channels: chans, duration: end })
          .then(function (buffer) {
            $('expBar').style.width = '55%';
            var out = Engine.bufferToChannels(buffer);
            if (norm) DSP.normalize(out, -1);
            return out;
          })
          .then(function (out) {
            /* 桌面版：编码与保存交给 Python（ffmpeg），先跳到那里 */
            if (py()) { doExportPy(out, f, rate, name, end); return null; }

            busy(true, '正在编码…');
            var mk = function (p) {
              $('expBar').style.width = (55 + p * 42) + '%';
            };

            if (f.v === 'wav') {
              return { bytes: DSP.encodeWav(out, rate, expCfg.depth, expCfg.depth === 32), mime: 'audio/wav' };
            }
            if (f.v === 'aiff') {
              return { bytes: DSP.encodeAiff(out, rate, expCfg.depth), mime: 'audio/aiff' };
            }
            if (f.v === 'mp3') {
              return { bytes: Codec.encodeMp3(out, rate, expCfg.kbps, mk), mime: 'audio/mpeg' };
            }
            if (f.v === 'opus') {
              return Codec.encodeOpus(out, 48000, expCfg.kbps, mk)
                .then(function (b) { return { bytes: b, mime: 'audio/ogg' }; });
            }
            return Codec.encodeM4a(out, rate, expCfg.kbps, mk)
              .then(function (b) { return { bytes: b, mime: 'audio/mp4' }; });
          })
          .then(function (r) {
            if (!r) return;                 // 已交给 Python 处理
            $('expBar').style.width = '100%';
            saveBytes(r.bytes, r.mime, name + '.' + f.ext, function (fn) {
              busy(false);
              closeExport();
              setTimeout(function () { $('expBar').style.width = '0%'; }, 500);
              toast('导出完成：' + fn, 'ok');
            });
          })
          .catch(function (e) {
            busy(false);
            toast('导出失败：' + (e && e.message ? e.message : e), 'err');
            console.error(e);
          });
      }, 60);
    });
  }

  /* 桌面版导出：本地渲染 -> 交给 Python 编码并弹原生保存框 */
  function doExportPy(out, f, rate, name, end) {
    var p = py();
    if (!p) return;
    busy(true, '正在交给 Python 编码…');
    $('expBar').style.width = '70%';

    p.uploadPcm(out, rate).then(function (id) {
      $('expBar').style.width = '86%';
      return new Promise(function (resolve, reject) {
        p.exportAudio(id, f.v, expCfg.kbps, name, function (res) {
          if (res && res.error) reject(new Error(res.error));
          else resolve(res || {});
        });
      });
    }).then(function (res) {
      busy(false);
      if (res.cancelled) {
        $('expBar').style.width = '0%';
        return;
      }
      $('expBar').style.width = '100%';
      closeExport();
      setTimeout(function () { $('expBar').style.width = '0%'; }, 500);
      var kb = res.size ? '（' + (res.size / 1048576).toFixed(1) + ' MB）' : '';
      toast('导出完成：' + res.path + kb, 'ok');
    }).catch(function (e) {
      busy(false);
      $('expBar').style.width = '0%';
      toast('导出失败：' + (e && e.message ? e.message : e), 'err');
      console.error(e);
    });
  }

  /* 导出用：从头渲染所有片段（不受播放头影响） */
  function buildItemsFull() {
    var items = [];
    for (var i = 0; i < S.clips.length; i++) {
      var c = S.clips[i];
      var t = track(c.trackId);
      if (!t || !isAudible(t)) continue;
      var rec = getAudio(c);
      if (!rec || !rec.channels.length) continue;
      items.push({
        channels: rec.channels,
        sampleRate: rec.sampleRate,
        delay: c.start,
        offset: 0,
        clipDur: clipDur(c),
        gain: Engine.dbToGain(c.gainDb + t.gainDb),
        volume: 1,
        pan: clamp((c.pan || 0) + (t.pan || 0), -1, 1),
        gainL: (c.gainL === undefined ? 1 : c.gainL) * (t.gainL === undefined ? 1 : t.gainL),
        gainR: (c.gainR === undefined ? 1 : c.gainR) * (t.gainR === undefined ? 1 : t.gainR),
        channelMode: c.channelMode !== 'stereo' ? c.channelMode : (t.channelMode || 'stereo'),
        fadeIn: c.fadeIn,
        fadeOut: c.fadeOut
      });
    }
    return items;
  }

  /* ============================ 缩放 / 视图 ============================ */

  function setZoomPx(pps, keepTime) {
    var anchor = keepTime === undefined ? null : keepTime;
    var before = anchor !== null ? (anchor * S.pxPerSec - tlScroll.scrollLeft) : null;
    S.pxPerSec = clamp(pps, PX_MIN, PX_MAX);
    var tw = totalWidth();       // 只算一次，避免重复触发布局
    rowEls.forEach(function (r) { r.lane.style.width = tw + 'px'; });
    renderRuler();
    relayoutAllClips();          // 只改宽高与波形，不重建 DOM
    layoutPlayhead();
    if (before !== null) tlScroll.scrollLeft = anchor * S.pxPerSec - before;
    $('zoomSlider').value = Math.round((Math.log(S.pxPerSec / PX_MIN) / Math.log(PX_MAX / PX_MIN)) * 100);
  }

  var zoomPending = 0;
  function queueZoom(pps, keepTime) {
    if (zoomPending) cancelAnimationFrame(zoomPending);
    zoomPending = requestAnimationFrame(function () { zoomPending = 0; setZoomPx(pps, keepTime); });
  }

  function fitView() {
    var end = Math.max(1, timelineEnd()) + 1;
    var w = tlScroll.clientWidth - headWidth() - 20;
    setZoomPx(clamp(w / end, PX_MIN, PX_MAX));
    tlScroll.scrollLeft = 0;
  }

  /* ============================ 状态栏 / 时间码 ============================ */

  function updateTimecode() {
    $('timecode').innerHTML = fmt(S.playhead) + '<small>/ ' + fmt(timelineEnd()) + '</small>';
  }

  function updateStatus() {
    var src = S.selection && S.selection.type === 'clip' ? srcs.get(clip(S.selection.id) ? clip(S.selection.id).srcId : '') : null;
    $('stSample').textContent = src ? (src.sampleRate + ' Hz · ' + src.channels.length + 'ch') : (Engine.context() ? (Engine.context().sampleRate + ' Hz') : '未初始化');
    $('stDuration').textContent = '总时长 ' + fmt(timelineEnd());
    $('stClips').textContent = S.clips.length + ' 个片段 · ' + S.tracks.length + ' 条音轨';
  }

  /* ============================ 右键菜单 ============================ */

  var menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }

  function openMenu(x, y, items) {
    closeMenu();
    menuEl = document.createElement('div');
    menuEl.className = 'menu';
    items.forEach(function (it) {
      if (it === '-') { menuEl.appendChild(document.createElement('hr')); return; }
      var b = document.createElement('button');
      if (it.danger) b.className = 'danger';
      b.innerHTML = '<span></span>';
      b.firstChild.textContent = it.label;
      if (it.sub || it.key) {
        var k = document.createElement('span'); k.className = 'k';
        k.textContent = it.key || '›';
        b.appendChild(k);
      }
      b.addEventListener('click', function (ev) {
        if (it.sub) {
          var r = b.getBoundingClientRect();
          openMenu(r.right - 6, r.top, it.sub);
          return;
        }
        closeMenu(); it.fn();
      });
      menuEl.appendChild(b);
    });
    menuEl.style.left = Math.min(x, window.innerWidth - 200) + 'px';
    menuEl.style.top = Math.min(y, window.innerHeight - 300) + 'px';
    document.body.appendChild(menuEl);
  }

  window.addEventListener('mousedown', function (e) {
    if (menuEl && !menuEl.contains(e.target)) closeMenu();
  }, true);

  /* 右键菜单：变速子菜单 */
  function speedMenu(c) {
    var presets = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 4];
    var sub = presets.map(function (s) {
      return { label: Math.abs(s - c.speed) < 1e-5 ? '✓ ' + s.toFixed(2) + '×' : s.toFixed(2) + '×',
        fn: function () {
          c.vanilla = false; c.speed = s;
          pushHistory(); renderClips(); refreshInspector();
        } };
    });
    sub.push('-');
    sub.push({ label: '自定义速度…（5 位小数）', fn: function () {
      var v = prompt('输入播放速度（0.05 ~ 10，可精确到 0.00001）：', c.speed.toFixed(5));
      if (v === null) return;
      var n = clamp(parseFloat(v), 0.05, 10);
      if (!(n > 0)) { toast('数值无效', 'err'); return; }
      c.vanilla = false; c.speed = +n.toFixed(5);
      pushHistory(); renderClips(); refreshInspector();
    } });
    return { label: c.vanilla ? '播放速度（原版倍率中）' : '播放速度：' + c.speed.toFixed(3) + '×', sub: sub };
  }

  /* 右键菜单：变调子菜单 */
  function pitchMenu(c) {
    var semis = [-12, -7, -5, -2, -1, 0, 1, 2, 5, 7, 12];
    var sub = semis.map(function (st) {
      var curRatio = pitchRatio(c);
      var target = Math.pow(2, st / 12);
      var cur = c.pitchUnit === 'semitone' ? c.pitchValue : null;
      return { label: (Math.abs(curRatio - target) < 0.003 ? '✓ ' : '') +
        (st > 0 ? '+' : '') + st + ' 半音',
        fn: function () {
          c.vanilla = false; c.pitchUnit = 'semitone'; c.pitchValue = st;
          pushHistory(); renderClips(); refreshInspector();
        } };
    });
    sub.push('-');
    sub.push({ label: '单位：倍率 (×)', fn: function () { setPitchUnit(c, 'ratio'); } });
    sub.push({ label: '单位：半音', fn: function () { setPitchUnit(c, 'semitone'); } });
    sub.push({ label: '单位：音分', fn: function () { setPitchUnit(c, 'cent'); } });
    sub.push({ label: '单位：赫兹 (Hz)', fn: function () { setPitchUnit(c, 'hz'); } });
    sub.push('-');
    sub.push({ label: '自定义变调…（按当前单位）', fn: function () {
      var r0 = pitchRatio(c);
      var v = prompt('当前单位：' + c.pitchUnit + '，输入数值：',
        (c.pitchUnit === 'ratio' ? r0 : DSP.ratioToPitch(r0, c.pitchUnit)).toFixed(5));
      if (v === null) return;
      var n = parseFloat(v);
      if (!isFinite(n)) { toast('数值无效', 'err'); return; }
      c.vanilla = false; c.pitchValue = +n.toFixed(5);
      pushHistory(); renderClips(); refreshInspector();
    } });
    sub.push({ label: '重置为不变调', fn: function () {
      c.vanilla = false; c.pitchUnit = 'ratio'; c.pitchValue = 1;
      pushHistory(); renderClips(); refreshInspector();
    } });
    return { label: '变调：' + pitchRatio(c).toFixed(3) + '×（' + c.pitchUnit + '）', sub: sub };
  }

  function setPitchUnit(c, u) {
    var r = pitchRatio(c);
    c.vanilla = false;
    c.pitchUnit = u;
    c.pitchValue = u === 'ratio' ? +r.toFixed(5) : +DSP.ratioToPitch(r, u).toFixed(5);
    pushHistory(); renderClips(); refreshInspector();
  }

  tracksEl.addEventListener('contextmenu', function (e) {
    var clipEl = e.target.closest('.clip');
    e.preventDefault();
    if (clipEl) {
      var c = clip(clipEl.dataset.clip);
      S.selection = { type: 'clip', id: c.id };
      clipEls.forEach(function (el, id) { el.classList.toggle('selected', id === c.id); });
      refreshInspector();
      openMenu(e.clientX, e.clientY, [
        { label: '在播放头分割', key: 'S', fn: function () { splitAt(S.playhead); } },
        { label: '复制片段', key: 'Ctrl+D', fn: function () { duplicateClip(c.id); } },
        '-',
        speedMenu(c),
        pitchMenu(c),
        { label: c.vanilla ? '✓ 原版倍率（点击关闭）' : '原版倍率（速度=音高）',
          fn: function () {
            c.vanilla = !c.vanilla;
            if (c.vanilla) c.ratio = pitchRatio(c);
            else { c.pitchUnit = 'ratio'; c.pitchValue = c.ratio; }
            pushHistory(); renderClips(); refreshInspector();
          } },
        '-',
        { label: c.reversed ? '取消反转' : '反转音频', fn: function () { c.reversed = !c.reversed; pushHistory(); renderClips(); refreshInspector(); } },
        { label: '重置 L/R 平衡', fn: function () { c.gainL = 1; c.gainR = 1; c.channelMode = 'stereo'; pushHistory(); renderClips(); refreshInspector(); } },
        '-',
        { label: '删除片段', key: 'Del', danger: true, fn: function () { deleteClip(c.id); } }
      ]);
    } else {
      var laneEl = e.target.closest('.lane');
      openMenu(e.clientX, e.clientY, [
        { label: '新增音轨', fn: addTrack },
        { label: '全部适应窗口', fn: fitView },
        '-',
        { label: '清空全部片段', danger: true, fn: clearAll }
      ]);
    }
  });

  /* ============================ 顶部 / 底部控件 ============================ */

  function addTrack() {
    var t = makeTrack(S.tracks.length);
    S.tracks.push(t);
    pushHistory();
    renderAll();
    refreshInspector();
  }

  /* 顶栏 */
  $('btnImport').addEventListener('click', function () { startImport(); });
  $('fileInput').addEventListener('change', function () {
    if (this.files && this.files.length) importFiles(this.files);
    this.value = '';
  });
  $('btnAddTrack').addEventListener('click', addTrack);
  $('btnPanic').addEventListener('click', clearAll);
  $('btnUndo').addEventListener('click', undo);
  $('btnRedo').addEventListener('click', redo);
  $('btnExport').addEventListener('click', openExport);
  $('btnTheme').addEventListener('click', function () {
    S.theme = S.theme === 'light' ? 'dark' : 'light';
    document.documentElement.dataset.theme = S.theme;
    try { localStorage.setItem('qazr.theme', S.theme); } catch (e) { }
  });

  /* 走带 */
  $('btnPlay').addEventListener('click', togglePlay);
  $('btnStop').addEventListener('click', function () { pause(); setPlayhead(0); });
  $('btnStart').addEventListener('click', function () { pause(); setPlayhead(0); tlScroll.scrollLeft = 0; });
  $('btnEnd').addEventListener('click', function () { pause(); setPlayhead(timelineEnd()); followPlayhead(); });

  /* 工具 */
  $('toolSelect').addEventListener('click', function () { setTool('select'); });
  $('toolSplit').addEventListener('click', function () { setTool('split'); });

  function setTool(t) {
    S.tool = t;
    $('toolSelect').classList.toggle('on', t === 'select');
    $('toolSplit').classList.toggle('on', t === 'split');
    tracksEl.style.cursor = t === 'split' ? 'crosshair' : 'default';
  }

  /* 吸附 / 缩放 / 主音量 */
  $('chkSnap').addEventListener('change', function () {
    S.snap = this.checked;
    try { localStorage.setItem('qazr.snap', this.checked ? '1' : '0'); } catch (e) { }
  });

  $('zoomSlider').addEventListener('input', function () {
    var t = parseFloat(this.value) / 100;
    var pps = PX_MIN * Math.pow(PX_MAX / PX_MIN, t);
    var c = tlScroll.clientWidth / 2;
    var centerTime = (tlScroll.scrollLeft + c - headWidth()) / S.pxPerSec;
    queueZoom(pps, centerTime);
  });
  $('btnFit').addEventListener('click', fitView);

  /* 波形与刻度尺都做了可视区裁剪，横向滚动时要重画进入视野的那一段 */
  var waveScrollPending = 0;
  tlScroll.addEventListener('scroll', function () {
    if (waveScrollPending) return;
    waveScrollPending = requestAnimationFrame(function () {
      waveScrollPending = 0;
      renderRuler();
      drawAllWaves();
    });
  });

  $('masterVol').addEventListener('input', function () {
    S.master = parseFloat(this.value);
    Engine.ensure();
    Engine.setMasterVolume(S.master);
    try { localStorage.setItem('qazr.master', S.master); } catch (e) { }
  });

  /* 导出弹窗 */
  $('btnExpCancel').addEventListener('click', closeExport);
  $('btnExpGo').addEventListener('click', doExport);
  expMask.addEventListener('mousedown', function (e) { if (e.target === expMask) closeExport(); });

  /* 刻度尺 / 播放头拖动 */
  bindScrub(rulerEl);
  (function () {
    var grip = $('phGrip');
    var startDrag = function (e) {
      pause();
      var move = function (ev) {
        var rect = laneRect(S.tracks[0].id);
        var left = rect ? rect.left : 0;
        setPlayhead((ev.clientX - left) / S.pxPerSec);
      };
      move(e);
      var up = function () { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
      e.preventDefault(); e.stopPropagation();
    };
    grip.addEventListener('mousedown', startDrag);
    playheadEl.addEventListener('mousedown', startDrag);
  })();

  /* ============================ 撤销 / 重做 ============================ */

  function undo() {
    if (!history.length) return;
    var prev = history.pop();
    future.push(snapshot());
    lastSnap = prev;
    applySnapshot(prev);
    toast('已撤销');
  }
  function redo() {
    if (!future.length) return;
    var next = future.pop();
    history.push(snapshot());
    lastSnap = next;
    applySnapshot(next);
    toast('已重做');
  }

  /* ============================ 快捷键 ============================ */

  document.addEventListener('keydown', function (e) {
    var tag = (e.target.tagName || '').toLowerCase();
    var typing = tag === 'input' || tag === 'select' || tag === 'textarea';
    var mod = e.ctrlKey || e.metaKey;

    if (mod && e.key.toLowerCase() === 'o') { e.preventDefault(); $('fileInput').click(); return; }
    if (mod && e.key.toLowerCase() === 'e') { e.preventDefault(); openExport(); return; }
    if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
    if (mod && e.key.toLowerCase() === 'd') {
      e.preventDefault();
      if (S.selection && S.selection.type === 'clip') duplicateClip(S.selection.id);
      return;
    }
    if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); return; }

    if (typing) return;

    if (e.code === 'Space') { e.preventDefault(); togglePlay(); return; }
    if (e.key === 'Home') { e.preventDefault(); pause(); setPlayhead(0); tlScroll.scrollLeft = 0; return; }
    if (e.key === 'End') { e.preventDefault(); pause(); setPlayhead(timelineEnd()); followPlayhead(); return; }
    if (e.key === 'Escape') { e.preventDefault(); pause(); setPlayhead(0); closeExport(); closeMenu(); return; }
    if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault();
      if (S.selection && S.selection.type === 'clip') deleteClip(S.selection.id);
      return;
    }
    if (e.key === 's' || e.key === 'S') { splitAt(S.playhead); return; }
    if (e.key === 'v' || e.key === 'V') { setTool('select'); return; }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault();
      var d = (e.shiftKey ? 1 : 0.1) * (e.key === 'ArrowLeft' ? -1 : 1);
      setPlayhead(S.playhead + d);
      followPlayhead();
      return;
    }
    if (e.key === '=' || e.key === '+') {
      var c1 = tlScroll.clientWidth / 2;
      var ct1 = (tlScroll.scrollLeft + c1 - headWidth()) / S.pxPerSec;
      queueZoom(S.pxPerSec * 1.28, ct1);
      return;
    }
    if (e.key === '-' || e.key === '_') {
      var c2 = tlScroll.clientWidth / 2;
      var ct2 = (tlScroll.scrollLeft + c2 - headWidth()) / S.pxPerSec;
      queueZoom(S.pxPerSec / 1.28, ct2);
      return;
    }
  });

  /* ============================ 全窗口拖放 ============================ */

  /* ============================ 桌面版桥接事件 ============================ */

  /* 桥接就绪：能力清单到手后刷新导出格式列表 */
  window.addEventListener('qazr-py-ready', function () {
    if (expMask && expMask.classList.contains('open')) buildExportForm();
  });

  /* 窗口拖入文件（路径由 Qt 主窗口拿到后转发过来） */
  window.addEventListener('qazr-py-imported', function (e) {
    var d = e.detail || {};
    registerPyItems(d, null);
  });

  window.addEventListener('qazr-py-error', function (e) {
    toast(String(e.detail || '导入失败'), 'err');
  });

  /* 浏览器版的 HTML5 拖拽：桌面版由 Qt 接管，这里跳过以免重复导入 */
  var dz = $('dropzone');
  var dragDepth = 0;
  window.addEventListener('dragenter', function (e) {
    if (py()) return;
    if (!e.dataTransfer || Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') < 0) return;
    dragDepth++;
    dz.classList.add('on');
  });
  window.addEventListener('dragover', function (e) { e.preventDefault(); });
  window.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) dz.classList.remove('on');
  });
  window.addEventListener('drop', function (e) {
    e.preventDefault();
    dragDepth = 0;
    dz.classList.remove('on');
    if (py()) return;                       // 桌面版由 Qt 主窗口接管
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      var tid = pickTrackAt(e.clientY) || S.activeTrack;
      importFiles(e.dataTransfer.files, tid);
    }
  });

  /* ============================ 颜色工具 ============================ */

  function hexA(hex, a) {
    var h = hex.replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, amt) {
    var h = hex.replace('#', '');
    var n = parseInt(h, 16);
    var r = clamp(((n >> 16) & 255) + amt, 0, 255);
    var g = clamp(((n >> 8) & 255) + amt, 0, 255);
    var b = clamp((n & 255) + amt, 0, 255);
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  /* ============================ 初始化 ============================ */

  function init() {
    try {
      var th = localStorage.getItem('qazr.theme');
      if (th) { S.theme = th; document.documentElement.dataset.theme = th; }
      var sn = localStorage.getItem('qazr.snap');
      if (sn !== null) { S.snap = sn === '1'; $('chkSnap').checked = S.snap; }
      var mv = localStorage.getItem('qazr.master');
      if (mv !== null) { S.master = parseFloat(mv); $('masterVol').value = S.master; }
    } catch (e) { }

    for (var i = 0; i < 5; i++) S.tracks.push(makeTrack(i));
    S.activeTrack = S.tracks[0].id;

    setTool('select');
    setPlayIcon(false);
    renderAll();
    refreshInspector();
    lastSnap = snapshot();
    history.length = 0;
    future.length = 0;
    updateUndoButtons();

    window.addEventListener('resize', function () {
      renderRuler();
      rowEls.forEach(function (r) { r.lane.style.width = totalWidth() + 'px'; });
      renderClips();
      layoutPlayhead();
    });

    tlScroll.addEventListener('scroll', function () { /* sticky 已处理 */ });

    $('btnPlay').classList.remove('on');
    toast('欢迎使用 Qazr 音频剪辑软件', 'ok');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
