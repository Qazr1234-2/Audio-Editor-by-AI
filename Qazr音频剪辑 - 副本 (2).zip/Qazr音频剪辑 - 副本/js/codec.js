/*
 * Qazr Codec — 压缩格式导出编码器
 * ------------------------------------------------------------------
 *   encodeMp3  : lamejs（LGPL / LAME）纯 JS 编码 —— 兼容性最广
 *   encodeOpus : 浏览器原生 Opus 编码（WebCodecs）+ 手写 Ogg 封装
 *   encodeM4a  : 浏览器原生 AAC 编码（WebCodecs）+ 手写 MP4 封装
 *
 * 说明：WebCodecs 不提供 MP3 / FLAC 的编码器（仅有解码），
 *       因此 MP3 走内联的 lamejs，其余走浏览器原生编码。
 */
(function (global) {
  'use strict';

  /* ===================== 字节工具 ===================== */

  function concat(list) {
    var n = 0, i;
    for (i = 0; i < list.length; i++) n += list[i].length;
    var out = new Uint8Array(n), off = 0;
    for (i = 0; i < list.length; i++) { out.set(list[i], off); off += list[i].length; }
    return out;
  }

  function u8(v) { return new Uint8Array([v & 0xFF]); }
  function u16(v) { return new Uint8Array([(v >>> 8) & 0xFF, v & 0xFF]); }
  function u32(v) {
    return new Uint8Array([(v >>> 24) & 0xFF, (v >>> 16) & 0xFF, (v >>> 8) & 0xFF, v & 0xFF]);
  }
  function u32le(v) {
    return new Uint8Array([v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF]);
  }
  function fourcc(s) {
    return new Uint8Array([s.charCodeAt(0), s.charCodeAt(1), s.charCodeAt(2), s.charCodeAt(3)]);
  }

  function toU8(d) {
    if (!d) return null;
    if (d instanceof ArrayBuffer) return new Uint8Array(d);
    return new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
  }

  function writeU64LE(arr, off, v) {
    var lo = v % 4294967296;
    var hi = Math.floor(v / 4294967296);
    arr[off] = lo & 0xFF;
    arr[off + 1] = (lo >>> 8) & 0xFF;
    arr[off + 2] = (lo >>> 16) & 0xFF;
    arr[off + 3] = (lo >>> 24) & 0xFF;
    arr[off + 4] = hi & 0xFF;
    arr[off + 5] = (hi >>> 8) & 0xFF;
    arr[off + 6] = (hi >>> 16) & 0xFF;
    arr[off + 7] = (hi >>> 24) & 0xFF;
  }

  /* ===================== 可用性探测 ===================== */

  function hasWebCodecs() {
    return typeof global.AudioEncoder !== 'undefined' && typeof global.AudioData !== 'undefined';
  }

  function hasLame() {
    return !!(global.lamejs && global.lamejs.Mp3Encoder);
  }

  var supportCache = {};

  /* 探测某个编码配置是否可用（结果缓存） */
  function supports(codec, sampleRate, numberOfChannels) {
    var key = codec + '@' + sampleRate + 'x' + numberOfChannels;
    if (key in supportCache) return Promise.resolve(supportCache[key]);
    if (!hasWebCodecs()) { supportCache[key] = false; return Promise.resolve(false); }
    return global.AudioEncoder.isConfigSupported({
      codec: codec, sampleRate: sampleRate, numberOfChannels: numberOfChannels
    }).then(function (s) {
      supportCache[key] = !!(s && s.supported);
      return supportCache[key];
    }, function () { supportCache[key] = false; return false; });
  }

  /* MP3 支持的采样率（MPEG1 / MPEG2 / MPEG2.5） */
  function mp3Rate(r) {
    return r === 8000 || r === 11025 || r === 12000 || r === 16000 || r === 22050 ||
      r === 24000 || r === 32000 || r === 44100 || r === 48000;
  }

  /* ===================== MP3（lamejs） ===================== */

  function floatToInt16(src) {
    var out = new Int16Array(src.length);
    for (var i = 0; i < src.length; i++) {
      var s = src[i];
      if (s > 1) s = 1; else if (s < -1) s = -1;
      out[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return out;
  }

  function encodeMp3(channels, sampleRate, kbps, onProgress) {
    if (!hasLame()) throw new Error('MP3 编码器未加载');
    var nch = Math.min(channels.length, 2);
    var enc = new global.lamejs.Mp3Encoder(nch, sampleRate, kbps);
    var L = floatToInt16(channels[0]);
    var R = nch > 1 ? floatToInt16(channels[1]) : null;
    var total = L.length;
    var STEP = 1152 * 40;
    var parts = [];
    for (var i = 0; i < total; i += STEP) {
      var end = Math.min(i + STEP, total);
      var buf = R ? enc.encodeBuffer(L.subarray(i, end), R.subarray(i, end))
        : enc.encodeBuffer(L.subarray(i, end));
      if (buf.length) parts.push(new Uint8Array(buf));
      if (onProgress) onProgress(end / total);
    }
    var tail = enc.flush();
    if (tail.length) parts.push(new Uint8Array(tail));
    return concat(parts);
  }

  /* ===================== WebCodecs 编码驱动 ===================== */

  /*
   * 把 PCM 送进 AudioEncoder，收集编码后的原始包
   *   返回 { packets:[{data,ts,dur}], desc: Uint8Array|null }
   */
  function runEncoder(codec, channels, sampleRate, kbps, onProgress, extraCfg) {
    return new Promise(function (resolve, reject) {
      var nch = channels.length;
      var total = 0, c, i;
      for (c = 0; c < nch; c++) total = Math.max(total, channels[c].length);

      var packets = [];
      var desc = null;
      var enc;
      try {
        enc = new global.AudioEncoder({
          output: function (chunk, meta) {
            if (!desc && meta && meta.decoderConfig && meta.decoderConfig.description) {
              desc = new Uint8Array(toU8(meta.decoderConfig.description));
            }
            var data = new Uint8Array(chunk.byteLength);
            chunk.copyTo(data);
            packets.push({ data: data, ts: chunk.timestamp, dur: chunk.duration || 0 });
          },
          error: function (e) { reject(e); }
        });
      } catch (e) { reject(e); return; }

      var cfg = {
        codec: codec,
        sampleRate: sampleRate,
        numberOfChannels: nch,
        bitrate: Math.round(kbps * 1000)
      };
      if (extraCfg) for (var k in extraCfg) cfg[k] = extraCfg[k];

      global.AudioEncoder.isConfigSupported(cfg).then(function (s) {
        if (!s || !s.supported) { reject(new Error('当前浏览器不支持该编码：' + codec)); return; }
        enc.configure(s.config || cfg);

        /* Opus 帧长固定 20ms，AAC 用 1024 样本更贴合编码器原生帧 */
        var FRAME = codec === 'opus' ? 960 : 1024;
        var pos = 0;

        function step() {
          try {
            var guard = 0;
            while (pos < total && guard < 120) {
              var n = Math.min(FRAME, total - pos);
              var plane = new Float32Array(nch * n);
              for (var cc = 0; cc < nch; cc++) {
                var src = channels[cc];
                var base = cc * n;
                for (var j = 0; j < n; j++) plane[base + j] = pos + j < src.length ? src[pos + j] : 0;
              }
              var ad = new global.AudioData({
                format: 'f32-planar',
                sampleRate: sampleRate,
                numberOfFrames: n,
                numberOfChannels: nch,
                timestamp: Math.round(pos * 1e6 / sampleRate),
                data: plane
              });
              enc.encode(ad);
              ad.close();
              pos += n;
              guard++;
            }
          } catch (e) { reject(e); return; }
          if (onProgress) onProgress(pos / total);
          if (pos < total) { setTimeout(step, 0); return; }
          enc.flush().then(function () {
            try { enc.close(); } catch (e2) { /* noop */ }
            resolve({ packets: packets, desc: desc });
          }, reject);
        }
        step();
      }).catch(reject);
    });
  }

  /* ===================== Ogg 封装（Opus） ===================== */

  var OGG_CRC = (function () {
    var t = new Uint32Array(256);
    for (var i = 0; i < 256; i++) {
      var r = i << 24;
      for (var j = 0; j < 8; j++) r = (r & 0x80000000) ? ((r << 1) ^ 0x04c11db7) : (r << 1);
      t[i] = r >>> 0;
    }
    return t;
  })();

  function oggCrc(bytes) {
    var crc = 0;
    for (var i = 0; i < bytes.length; i++) {
      crc = ((crc << 8) ^ OGG_CRC[((crc >>> 24) ^ bytes[i]) & 0xFF]) >>> 0;
    }
    return crc >>> 0;
  }

  /* 一个 Ogg 页承载一个包 */
  function oggPage(type, granule, serial, seq, packet) {
    var segs = [];
    var n = packet.length;
    while (n >= 255) { segs.push(255); n -= 255; }
    segs.push(n);

    var segCount = segs.length;
    var bodyLen = 0;
    for (var i = 0; i < segCount; i++) bodyLen += segs[i];

    var page = new Uint8Array(27 + segCount + bodyLen);
    page[0] = 0x4F; page[1] = 0x67; page[2] = 0x67; page[3] = 0x53;   // "OggS"
    page[4] = 0;                                                       // 版本
    page[5] = type;                                                    // 头类型
    writeU64LE(page, 6, granule);
    page.set(u32le(serial), 14);
    page.set(u32le(seq), 18);
    /* 22..25 为 CRC 占位 */
    page[26] = segCount;
    for (i = 0; i < segCount; i++) page[27 + i] = segs[i];
    page.set(packet, 27 + segCount);
    page.set(u32le(oggCrc(page)), 22);
    return page;
  }

  function buildOpusHead(ch, inputRate, preSkip) {
    var head = concat([
      fourcc('Opus'), fourcc('Head'),
      u8(1),               // 版本
      u8(ch),              // 声道数
      new Uint8Array([preSkip & 0xFF, (preSkip >>> 8) & 0xFF]),
      u32le(inputRate),    // 原始采样率（仅信息性）
      new Uint8Array([0, 0]), // 输出增益
      u8(0)                // 声道映射族
    ]);
    return head;
  }

  function buildOpusTags(vendor) {
    var v = [];
    for (var i = 0; i < vendor.length; i++) v.push(vendor.charCodeAt(i));
    var vb = new Uint8Array(v);
    return concat([
      fourcc('Opus'), fourcc('Tags'),
      u32le(vb.length), vb,
      u32le(0)             // 无用户注释
    ]);
  }

  function encodeOpus(channels, sampleRate, kbps, onProgress) {
    return runEncoder('opus', channels, sampleRate, kbps, onProgress).then(function (r) {
      var ch = channels.length;
      var serial = 0x51715A52;   // 'QqZR'
      var pages = [];
      var seq = 0;

      var head = (r.desc && r.desc.length >= 19) ? r.desc : null;
      var preSkip = 312;
      if (head) {
        preSkip = head[10] | (head[11] << 8);
      } else {
        head = buildOpusHead(ch, sampleRate, preSkip);
      }

      pages.push(oggPage(0x02, 0, serial, seq++, head));                       // BOS
      pages.push(oggPage(0x00, 0, serial, seq++, buildOpusTags('Qazr Audio')));

      var frames = 0;
      for (var i = 0; i < r.packets.length; i++) {
        var p = r.packets[i];
        var dur = p.dur > 0 ? p.dur : (960 * 1e6 / sampleRate);
        frames = Math.round((p.ts + dur) * sampleRate / 1e6);
        var last = i === r.packets.length - 1;
        pages.push(oggPage(last ? 0x04 : 0x00, frames, serial, seq++, p.data));
      }
      return concat(pages);
    });
  }

  /* ===================== MP4 封装（AAC / M4A） ===================== */

  var SR_IDX = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];

  function mp4box(type, parts) {
    var body = concat(parts);
    return concat([u32(body.length + 8), fourcc(type), body]);
  }

  function mp4full(type, version, flags, parts) {
    var vf = new Uint8Array([version, (flags >>> 16) & 0xFF, (flags >>> 8) & 0xFF, flags & 0xFF]);
    return mp4box(type, [vf].concat(parts));
  }

  /* 描述符长度（可变长，7 位一组） */
  function descLen(n) {
    var out = [n & 0x7F];
    n = Math.floor(n / 128);
    while (n > 0) { out.unshift((n & 0x7F) | 0x80); n = Math.floor(n / 128); }
    return new Uint8Array(out);
  }

  function descriptor(tag, payload) {
    return concat([u8(tag), descLen(payload.length), payload]);
  }

  var UNITY_MATRIX = concat([
    u32(0x00010000), u32(0), u32(0),
    u32(0), u32(0x00010000), u32(0),
    u32(0), u32(0), u32(0x40000000)
  ]);

  /* 无 AudioSpecificConfig 时的兜底（AAC-LC） */
  function aacAsc(sampleRate, ch) {
    var idx = SR_IDX.indexOf(sampleRate);
    if (idx < 0) idx = 3;
    return new Uint8Array([
      (2 << 3) | (idx >> 1),
      ((idx & 1) << 7) | (ch << 3)
    ]);
  }

  function esdsBox(asc, kbps) {
    var dsi = descriptor(0x05, asc);
    var dcd = descriptor(0x04, concat([
      u8(0x40),                 // MPEG-4 Audio
      u8(0x15),                 // 音频流 (5<<2) | reserved
      new Uint8Array([0, 0, 0]), // bufferSizeDB
      u32(Math.round(kbps * 1000)),
      u32(Math.round(kbps * 1000)),
      dsi
    ]));
    var sl = descriptor(0x06, u8(0x02));
    return mp4full('esds', 0, 0, [descriptor(0x03, concat([u16(0), u8(0), dcd, sl]))]);
  }

  function encodeM4a(channels, sampleRate, kbps, onProgress) {
    return runEncoder('mp4a.40.2', channels, sampleRate, kbps, onProgress, { format: 'aac' })
      .then(function (r) {
        if (!r.packets.length) throw new Error('AAC 编码没有产生数据');
        var ch = channels.length;
        var asc = (r.desc && r.desc.length) ? r.desc : aacAsc(sampleRate, ch);

        var sizes = [];
        var totalSamples = 0;
        var i, p;
        for (i = 0; i < r.packets.length; i++) {
          p = r.packets[i];
          sizes.push(p.data.length);
          var n = p.dur > 0 ? Math.round(p.dur * sampleRate / 1e6) : 1024;
          if (n <= 0) n = 1024;
          totalSamples += n;
        }

        var audio = concat(r.packets.map(function (x) { return x.data; }));

        /* ftyp 在前、mdat 紧随其后，数据起始偏移即可确定 */
        var ftyp = mp4box('ftyp', [fourcc('M4A '), u32(0), fourcc('M4A '), fourcc('mp42'), fourcc('isom')]);
        var dataOffset = ftyp.length + 8;

        /* stco：每 64 个采样一个 chunk */
        var PER = 64;
        var offsets = [];
        var acc = dataOffset;
        for (i = 0; i < sizes.length; i++) {
          if (i % PER === 0) offsets.push(acc);
          acc += sizes[i];
        }

        var sttsEntries = [];
        var runCount = 1;
        for (i = 1; i <= r.packets.length; i++) {
          var same = false;
          if (i < r.packets.length) {
            var a = r.packets[i - 1].dur > 0 ? Math.round(r.packets[i - 1].dur * sampleRate / 1e6) : 1024;
            var b = r.packets[i].dur > 0 ? Math.round(r.packets[i].dur * sampleRate / 1e6) : 1024;
            same = (a === b) && (a > 0);
          }
          if (same) { runCount++; continue; }
          var delta = r.packets[i - 1].dur > 0 ? Math.round(r.packets[i - 1].dur * sampleRate / 1e6) : 1024;
          sttsEntries.push(concat([u32(runCount), u32(delta > 0 ? delta : 1024)]));
          runCount = 1;
        }

        var stsd = mp4full('stsd', 0, 0, [u32(1), mp4box('mp4a', [
          new Uint8Array(6), u16(1),          // 保留 + 数据引用索引
          u16(0), u16(0), u32(0),             // 版本 / 修订 / 厂商
          u16(ch), u16(16), u16(0), u16(0),   // 声道 / 位深 / 预定义 / 保留
          u32(sampleRate <= 65535 ? sampleRate * 65536 : 0),  // 采样率 16.16 定点
          esdsBox(asc, kbps)
        ])]);

        var stts = mp4full('stts', 0, 0, [u32(sttsEntries.length)].concat(sttsEntries));
        var stsc = mp4full('stsc', 0, 0, [u32(1), u32(1), u32(PER), u32(1)]);
        var stsz = mp4full('stsz', 0, 0, [u32(0), u32(sizes.length)].concat(
          sizes.map(function (s) { return u32(s); })));
        var stco = mp4full('stco', 0, 0, [u32(offsets.length)].concat(
          offsets.map(function (o) { return u32(o); })));

        var stbl = mp4box('stbl', [stsd, stts, stsc, stsz, stco]);
        var dref = mp4full('dref', 0, 0, [u32(1), mp4full('url ', 0, 1, [])]);
        var dinf = mp4box('dinf', [dref]);
        var smhd = mp4full('smhd', 0, 0, [u16(0), u16(0)]);
        var minf = mp4box('minf', [smhd, dinf, stbl]);
        var hdlr = mp4full('hdlr', 0, 0, [
          u32(0), fourcc('soun'), new Uint8Array(12),
          new Uint8Array([0x53, 0x6F, 0x75, 0x6E, 0x64, 0x48, 0x61, 0x6E, 0x64, 0x6C, 0x65, 0x72, 0x00])
        ]);
        var mdhd = mp4full('mdhd', 0, 0, [
          u32(0), u32(0), u32(sampleRate), u32(totalSamples), u16(0x55C4), u16(0)
        ]);
        var mdia = mp4box('mdia', [mdhd, hdlr, minf]);

        var durMs = Math.round(totalSamples * 1000 / sampleRate);
        var tkhd = mp4full('tkhd', 0, 7, [
          u32(0), u32(0), u32(1), u32(0), u32(durMs),
          new Uint8Array(8), u16(0), u16(0), u16(0x0100), u16(0),
          UNITY_MATRIX, u32(0), u32(0)
        ]);
        var trak = mp4box('trak', [tkhd, mdia]);

        var mvhd = mp4full('mvhd', 0, 0, [
          u32(0), u32(0), u32(1000), u32(durMs),
          u32(0x00010000), u16(0x0100), u16(0), new Uint8Array(8),
          UNITY_MATRIX, new Uint8Array(24), u32(2)
        ]);

        var moov = mp4box('moov', [mvhd, trak]);
        var mdat = mp4box('mdat', [audio]);
        return concat([ftyp, mdat, moov]);
      });
  }

  global.QazrCodec = {
    hasWebCodecs: hasWebCodecs,
    hasLame: hasLame,
    supports: supports,
    mp3Rate: mp3Rate,
    encodeMp3: encodeMp3,
    encodeOpus: encodeOpus,
    encodeM4a: encodeM4a
  };
})(typeof window !== 'undefined' ? window : this);
