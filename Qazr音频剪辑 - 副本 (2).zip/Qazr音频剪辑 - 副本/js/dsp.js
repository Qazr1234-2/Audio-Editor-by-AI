/*
 * Qazr Audio DSP
 * ------------------------------------------------------------------
 * 纯 JS、零依赖的音频处理核心：
 *   - FFT（radix-2 原地 Cooley-Tukey）
 *   - timeStretch：相位声码器（Phase Vocoder），变速不变调 / 用于变调
 *   - resample：Catmull-Rom 三次插值重采样（变调 / 原版倍率）
 *   - peaks：波形峰值（min/max 包络）
 *   - encodeWav：16 / 24-bit PCM 与 32-bit float 无损导出
 * 该文件同时可在 Node 下 require，便于算法自测。
 */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.QazrDSP = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var TWO_PI = Math.PI * 2;

  /* ============================ FFT ============================ */

  function FFT(size) {
    if ((size & (size - 1)) !== 0) throw new Error('FFT size must be a power of two');
    this.size = size;
    this.levels = Math.round(Math.log2(size));
    var n = size;
    this.cos = new Float32Array(n / 2);
    this.sin = new Float32Array(n / 2);
    for (var i = 0; i < n / 2; i++) {
      this.cos[i] = Math.cos(-TWO_PI * i / n);
      this.sin[i] = Math.sin(-TWO_PI * i / n);
    }
    this.rev = new Uint32Array(n);
    for (var j = 0; j < n; j++) {
      var r = 0;
      for (var b = 0; b < this.levels; b++) r = (r << 1) | ((j >>> b) & 1);
      this.rev[j] = r;
    }
  }

  FFT.prototype.transform = function (re, im) {
    var n = this.size, rev = this.rev, cos = this.cos, sin = this.sin;
    for (var i = 0; i < n; i++) {
      var k = rev[i];
      if (k > i) {
        var t = re[i]; re[i] = re[k]; re[k] = t;
        t = im[i]; im[i] = im[k]; im[k] = t;
      }
    }
    for (var size = 2; size <= n; size <<= 1) {
      var half = size >> 1, step = n / size;
      for (var a = 0; a < n; a += size) {
        for (var b2 = a, c = 0; b2 < a + half; b2++, c += step) {
          var d = b2 + half;
          var tre = re[d] * cos[c] - im[d] * sin[c];
          var tim = re[d] * sin[c] + im[d] * cos[c];
          re[d] = re[b2] - tre; im[d] = im[b2] - tim;
          re[b2] += tre; im[b2] += tim;
        }
      }
    }
  };

  FFT.prototype.inverse = function (re, im) {
    var n = this.size, i;
    for (i = 0; i < n; i++) im[i] = -im[i];
    this.transform(re, im);
    var inv = 1 / n;
    for (i = 0; i < n; i++) { re[i] *= inv; im[i] = -im[i] * inv; }
  };

  /* ========================== 工具函数 ========================== */

  function hann(n) {
    var w = new Float32Array(n);
    for (var i = 0; i < n; i++) w[i] = 0.5 * (1 - Math.cos(TWO_PI * i / n));
    return w;
  }

  function toFloat(x) {
    return (x instanceof Float32Array) ? x : new Float32Array(x);
  }

  function clone(x) {
    return new Float32Array(toFloat(x));
  }

  function reverse(x) {
    var n = x.length, o = new Float32Array(n);
    for (var i = 0; i < n; i++) o[i] = x[n - 1 - i];
    return o;
  }

  function slice(x, start, len) {
    var s = Math.max(0, Math.round(start));
    var e = Math.min(x.length, s + Math.max(0, Math.round(len)));
    var o = new Float32Array(Math.max(0, e - s));
    for (var i = s; i < e; i++) o[i - s] = x[i];
    return o;
  }

  /* ===================== 相位声码器 变速不变调 ===================== */
  /*
   * timeStretch(input, stretch)
   *   stretch = 输出长度 / 输入长度
   *   音高保持不变，仅改变时长。
   */
  function timeStretch(input, stretch, opts) {
    input = toFloat(input);
    if (!(stretch > 0)) stretch = 1;
    if (Math.abs(stretch - 1) < 1e-6) return clone(input);

    opts = opts || {};
    var N = opts.fftSize || 1024;
    if ((N & (N - 1)) !== 0) N = 1024;

    var inLen = input.length;
    if (inLen < N * 2) {
      // 太短，退化为线性重采样保证可用性
      return resample(input, 1 / stretch);
    }

    // 合成跳距必须 <= N/2 才能无缝叠加
    var overlap = opts.overlap || Math.max(4, Math.ceil(stretch * 2));
    if (overlap < 2) overlap = 2;
    if (overlap > 32) overlap = 32;

    var Ha = Math.max(1, Math.floor(N / overlap));
    var Hs = Ha * stretch;                       // 小数合成跳距
    var H = N >> 1;

    var fft = new FFT(N);
    var win = hann(N);
    var outLen = Math.max(1, Math.round(inLen * stretch));
    var alloc = outLen + N * 2;

    var out = new Float32Array(alloc);
    var wsum = new Float32Array(alloc);
    var re = new Float32Array(N), im = new Float32Array(N);
    var lastPhase = new Float32Array(H + 1);
    var sumPhase = new Float32Array(H + 1);
    var omega = new Float32Array(H + 1);
    for (var k = 0; k <= H; k++) omega[k] = TWO_PI * k / N;

    var frames = Math.max(1, Math.floor((inLen - N) / Ha) + 1);

    for (var f = 0; f < frames; f++) {
      var readPos = f * Ha;
      var writePos = f * Hs;
      if (writePos >= alloc - N - 1) break;

      for (var i = 0; i < N; i++) { re[i] = input[readPos + i] * win[i]; im[i] = 0; }
      fft.transform(re, im);

      for (var b = 0; b <= H; b++) {
        var rr = re[b], ii = im[b];
        var mag = Math.sqrt(rr * rr + ii * ii);
        var ph = Math.atan2(ii, rr);
        var sp;
        if (f === 0) {
          lastPhase[b] = ph;
          sumPhase[b] = ph;
          sp = ph;
        } else {
          var d = ph - lastPhase[b] - omega[b] * Ha;
          d -= TWO_PI * Math.round(d / TWO_PI);   // princarg
          lastPhase[b] = ph;
          var trueFreq = omega[b] + d / Ha;
          sp = sumPhase[b] + trueFreq * Hs;
          sumPhase[b] = sp;
        }
        var cr = mag * Math.cos(sp), ci = mag * Math.sin(sp);
        re[b] = cr; im[b] = ci;
        if (b > 0 && b < H) { re[N - b] = cr; im[N - b] = -ci; }
      }

      fft.inverse(re, im);

      var w0 = Math.floor(writePos);
      var frac = writePos - w0;
      for (var s = 0; s < N; s++) {
        var v = re[s] * win[s];
        var w2 = win[s] * win[s];
        out[w0 + s] += v * (1 - frac);
        out[w0 + s + 1] += v * frac;
        wsum[w0 + s] += w2 * (1 - frac);
        wsum[w0 + s + 1] += w2 * frac;
      }
    }

    var res = new Float32Array(outLen);
    for (var p = 0; p < outLen; p++) {
      var wv = wsum[p];
      res[p] = wv > 1e-4 ? out[p] / wv : 0;
    }
    return res;
  }

  /* ======================= 重采样（变调） ======================= */
  /*
   * resample(input, factor)
   *   factor = 音高倍率，输出长度 = input.length / factor
   *   Catmull-Rom 三次插值，降低高频失真
   */
  function resample(input, factor) {
    input = toFloat(input);
    if (!(factor > 0)) factor = 1;
    if (Math.abs(factor - 1) < 1e-9) return clone(input);

    var n = input.length;
    var outLen = Math.max(1, Math.round(n / factor));
    var out = new Float32Array(outLen);

    for (var i = 0; i < outLen; i++) {
      var pos = i * factor;
      var i1 = Math.floor(pos);
      var t = pos - i1;
      var p0 = input[i1 - 1] !== undefined ? input[i1 - 1] : (input[i1] || 0);
      var p1 = input[i1] !== undefined ? input[i1] : 0;
      var p2 = input[i1 + 1] !== undefined ? input[i1 + 1] : p1;
      var p3 = input[i1 + 2] !== undefined ? input[i1 + 2] : p2;
      var t2 = t * t, t3 = t2 * t;
      out[i] = p1 + 0.5 * (t * (p2 - p0) + t2 * (2 * p0 - 5 * p1 + 4 * p2 - p3) + t3 * (-p0 + 3 * p1 - 3 * p2 + p3));
    }
    return out;
  }

  /* ==================== 单声道 -> 目标处理链 ==================== */
  /*
   * processClip(channels, { speed, pitch, vanilla })
   *   channels: Float32Array[]（源片段）
   *   返回处理后的 Float32Array[]（播放倍率 1.0）
   *   非原版：时长 /speed，音高 x pitch
   *   原版耦合：倍率 = pitch（时长 /pitch，音高 x pitch）
   */
  function processClip(channels, cfg) {
    cfg = cfg || {};
    var speed = cfg.speed > 0 ? cfg.speed : 1;
    var pitch = cfg.pitch > 0 ? cfg.pitch : 1;
    var vanilla = !!cfg.vanilla;

    var out = [];
    for (var c = 0; c < channels.length; c++) {
      var src = toFloat(channels[c]);
      if (vanilla) {
        // 原版耦合：倍率同时作用于时长与音高
        var r = cfg.ratio > 0 ? cfg.ratio : 1;
        out.push(resample(src, r));
        continue;
      }
      var stretch = pitch / speed;            // 输出/输入的时长系数
      var tmp = Math.abs(stretch - 1) < 1e-5 ? clone(src) : timeStretch(src, stretch, { fftSize: cfg.fftSize });
      if (Math.abs(pitch - 1) > 1e-5) tmp = resample(tmp, pitch);
      out.push(tmp);
    }
    return out;
  }

  /* ========================= 波形峰值 ========================= */

  function peaks(channels, buckets, from, to) {
    var ch = channels.length;
    var len = channels[0] ? channels[0].length : 0;
    var s = from === undefined ? 0 : Math.max(0, Math.round(from));
    var e = to === undefined ? len : Math.min(len, Math.round(to));
    var span = Math.max(1, e - s);
    var n = Math.max(1, Math.min(buckets || 1024, span));
    var mn = new Float32Array(n), mx = new Float32Array(n);
    for (var b = 0; b < n; b++) {
      var a0 = s + Math.floor(b * span / n);
      var a1 = s + Math.floor((b + 1) * span / n);
      if (a1 <= a0) a1 = a0 + 1;
      var lo = 1, hi = -1;
      for (var c = 0; c < ch; c++) {
        var data = channels[c];
        for (var i = a0; i < a1 && i < data.length; i++) {
          var v = data[i];
          if (v < lo) lo = v;
          if (v > hi) hi = v;
        }
      }
      if (lo > hi) { lo = 0; hi = 0; }
      mn[b] = lo; mx[b] = hi;
    }
    return { min: mn, max: mx, count: n };
  }

  /* ==================== 分段包络（多分辨率金字塔） ====================
   * 把整段音频按固定样本数切成小格，逐级 4 倍下采样，预存每格的 min/max。
   * 求任意缩放级别 / 任意宽度的波形包络时，挑一个"格子比一个像素小几倍"
   * 的层级去聚合即可，复杂度从 O(样本数) 降到 O(像素数)：
   * 这样缩放、拖动都不会再随音频变长而卡顿。
   * 逐级填充由调用方分帧驱动，构建过程本身也不阻塞界面。
   */

  var ENV_BASE = 32;                        // 最细一档：每格 32 个样本
  var ENV_LADDER = [1, 4, 16, 64, 256];     // 逐级放大 4 倍
  var ENV_MIN_CELLS = 8;                     // 层级再粗就没意义了

  function envelopeInit(channels) {
    var ch = channels.length, len = 0, c;
    for (c = 0; c < ch; c++) len = Math.max(len, channels[c].length);
    var levels = [];
    for (var li = 0; li < ENV_LADDER.length; li++) {
      var step = ENV_BASE * ENV_LADDER[li];
      var cells = Math.max(1, Math.ceil(len / step));
      levels.push({
        step: step, cells: cells,
        min: new Float32Array(cells), max: new Float32Array(cells),
        filled: 0
      });
      if (cells <= ENV_MIN_CELLS) break;
    }
    return { len: len, levels: levels, done: len === 0 };
  }

  /* 逐级填充。budget = 本次最多扫描多少个样本（分帧用） */
  function envelopeFill(env, channels, budget) {
    var li, lv, start, k, i, c, v, lo, hi, d;

    /* 先填最细一档：需要真正扫样本 */
    var l0 = env.levels[0];
    if (l0.filled < l0.cells) {
      var can = Math.max(1, Math.floor(budget / l0.step));
      start = l0.filled;
      var stop = Math.min(l0.cells, start + can);
      for (k = start; k < stop; k++) {
        var a0 = k * l0.step, a1 = Math.min(env.len, a0 + l0.step);
        lo = 1; hi = -1;
        for (c = 0; c < channels.length; c++) {
          d = channels[c];
          for (i = a0; i < a1 && i < d.length; i++) {
            v = d[i];
            if (v < lo) lo = v;
            if (v > hi) hi = v;
          }
        }
        if (lo > hi) { lo = 0; hi = 0; }
        l0.min[k] = lo; l0.max[k] = hi;
      }
      l0.filled = stop;
      return (stop - start) * l0.step;
    }

    /* 再由下一级逐级下采样，代价极低 */
    for (li = 1; li < env.levels.length; li++) {
      lv = env.levels[li];
      var prev = env.levels[li - 1];
      /*
       * 本层第 k 格由上一层 4 格合成，最后一格可能不满 4 格。
       * 上一层填满时本层必然可以全部导出；
       * 否则只有能凑齐 4 格的那些格子可导出——注意不能简单地用
       * floor(上一层格数 / 4)，那样会漏掉每层最后一格。
       */
      var derivable = (prev.filled >= prev.cells)
        ? lv.cells
        : Math.min(lv.cells, Math.floor(prev.filled / 4));
      if (lv.filled < derivable) {
        var s2 = lv.filled;
        for (k = s2; k < derivable; k++) {
          lo = 1; hi = -1;
          for (var q = k * 4; q < (k + 1) * 4 && q < prev.cells; q++) {
            if (prev.min[q] < lo) lo = prev.min[q];
            if (prev.max[q] > hi) hi = prev.max[q];
          }
          if (lo > hi) { lo = 0; hi = 0; }
          lv.min[k] = lo; lv.max[k] = hi;
        }
        lv.filled = derivable;
        return 0;
      }
    }

    env.done = true;
    return 0;
  }

  /*
   * 这次查询能否直接用分段包络：需要被选中的那一档已经覆盖到查询终点。
   * 参数与 envelopePeaks 保持一致，否则档位会挑得不一样。
   */
  function envelopeReadyTo(env, buckets, from, to) {
    if (!env) return false;
    if (env.done) return true;
    var s = from === undefined ? 0 : Math.max(0, Math.round(from));
    var e = to === undefined ? env.len : Math.min(env.len, Math.round(to));
    var span = Math.max(1, e - s);
    var n = Math.max(1, Math.min(buckets || 1024, span));
    var lv = envelopePickLevel(env, span / n);
    /* 没有够细的档位时会退回直接扫样本，任何时刻都可用 */
    if (!lv) return true;
    return lv.filled >= Math.min(lv.cells, Math.ceil(e / lv.step));
  }

  /* 挑层级：格子不超过一个桶的四分之一，取其中最粗的一档 */
  function envelopePickLevel(env, per) {
    var best = null;
    for (var li = 0; li < env.levels.length; li++) {
      if (env.levels[li].filled > 0 && env.levels[li].step <= per / 4) best = env.levels[li];
    }
    return best;
  }

  /* 用分段包络求包络：O(桶数 + 覆盖到的格数) */
  function envelopePeaks(env, channels, buckets, from, to) {
    var len = env.len;
    var s = from === undefined ? 0 : Math.max(0, Math.round(from));
    var e = to === undefined ? len : Math.min(len, Math.round(to));
    var span = Math.max(1, e - s);
    var n = Math.max(1, Math.min(buckets || 1024, span));
    var mn = new Float32Array(n), mx = new Float32Array(n);
    var per = span / n;
    var lv = envelopePickLevel(env, per);

    for (var b = 0; b < n; b++) {
      var a0 = s + Math.floor(b * span / n);
      var a1 = s + Math.floor((b + 1) * span / n);
      if (a1 <= a0) a1 = a0 + 1;
      var lo = 1, hi = -1;
      if (lv) {
        var c0 = Math.floor(a0 / lv.step);
        var c1 = Math.floor((a1 - 1) / lv.step);
        var last = Math.min(c1 + 1, lv.cells);
        for (var k = c0; k < last; k++) {
          if (lv.min[k] < lo) lo = lv.min[k];
          if (lv.max[k] > hi) hi = lv.max[k];
        }
      } else {
        /* 还没有够细的层级（只可能是极短的音频段）：直接扫样本 */
        for (var c = 0; c < channels.length; c++) {
          var d = channels[c];
          for (var i = a0; i < a1 && i < d.length; i++) {
            var v = d[i];
            if (v < lo) lo = v;
            if (v > hi) hi = v;
          }
        }
      }
      if (lo > hi) { lo = 0; hi = 0; }
      mn[b] = lo; mx[b] = hi;
    }
    return { min: mn, max: mx, count: n };
  }

  /* ========================= 峰值归一化 ========================= */

  function peakLevel(channels) {
    var peak = 0;
    for (var c = 0; c < channels.length; c++) {
      var d = channels[c];
      for (var i = 0; i < d.length; i++) {
        var v = d[i] < 0 ? -d[i] : d[i];
        if (v > peak) peak = v;
      }
    }
    return peak;
  }

  function normalize(channels, targetDb) {
    var target = Math.pow(10, (targetDb === undefined ? -1 : targetDb) / 20);
    var peak = peakLevel(channels);
    if (peak < 1e-9) return channels;
    var g = target / peak;
    for (var c = 0; c < channels.length; c++) {
      var d = channels[c];
      for (var i = 0; i < d.length; i++) d[i] *= g;
    }
    return channels;
  }

  /* ========================= WAV 编码 ========================= */

  function interleave(channels, length) {
    var ch = channels.length;
    var out = new Float32Array(length * ch);
    for (var i = 0; i < length; i++) {
      for (var c = 0; c < ch; c++) {
        var d = channels[c];
        out[i * ch + c] = i < d.length ? d[i] : 0;
      }
    }
    return out;
  }

  function writeString(view, off, s) {
    for (var i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  }

  /*
   * encodeWav(channels, sampleRate, bitDepth, isFloat)
   *   bitDepth: 16 | 24 | 32
   */
  function encodeWav(channels, sampleRate, bitDepth, isFloat) {
    var numCh = channels.length;
    var len = 0;
    for (var c = 0; c < numCh; c++) len = Math.max(len, channels[c].length);
    var bytes = bitDepth / 8;
    var blockAlign = numCh * bytes;
    var dataSize = len * blockAlign;
    var buffer = new ArrayBuffer(44 + dataSize);
    var view = new DataView(buffer);

    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, isFloat ? 3 : 1, true);
    view.setUint16(22, numCh, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);

    var data = interleave(channels, len);
    var off = 44;
    for (var i = 0; i < data.length; i++) {
      var s = data[i];
      if (isFloat) {
        view.setFloat32(off, s, true); off += 4;
      } else {
        if (s > 1) s = 1; else if (s < -1) s = -1;
        if (bitDepth === 16) {
          view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true); off += 2;
        } else {
          var v = Math.round(s < 0 ? s * 0x800000 : s * 0x7FFFFF);
          view.setUint8(off, v & 0xFF);
          view.setUint8(off + 1, (v >> 8) & 0xFF);
          view.setUint8(off + 2, (v >> 16) & 0xFF);
          off += 3;
        }
      }
    }
    return buffer;
  }

  /* ======================= AIFF 编码（大端无损） ======================= */

  /* 80 位 IEEE 扩展浮点：AIFF 的采样率字段 */
  function writeFloat80(view, off, value) {
    var exp = Math.floor(Math.log2(value));
    var mant = value / Math.pow(2, exp);          // [1, 2)
    view.setUint16(off, exp + 16383, false);
    var a = mant * 2147483648;                    // mant × 2^31
    var hi = Math.floor(a);
    var lo = Math.floor((a - hi) * 4294967296);
    view.setUint32(off + 2, hi >>> 0, false);
    view.setUint32(off + 6, lo >>> 0, false);
  }

  /*
   * encodeAiff(channels, sampleRate, bitDepth)
   *   bitDepth: 16 | 24 | 32（整数 PCM，大端）
   *   结构：FORM / AIFF / COMM(18) / SSND
   */
  function encodeAiff(channels, sampleRate, bitDepth) {
    var numCh = channels.length;
    var len = 0;
    for (var c = 0; c < numCh; c++) len = Math.max(len, channels[c].length);
    var bytes = bitDepth / 8;
    var dataSize = len * numCh * bytes;
    var ssndSize = 8 + dataSize;
    var pad = ssndSize % 2;                       // 块需按偶数字节对齐

    /* 'FORM'(4) + 长度(4) + 'AIFF'(4) + COMM(8+18) + SSND(8+8+数据) + 对齐 */
    var buffer = new ArrayBuffer(54 + dataSize + pad);
    var view = new DataView(buffer);

    writeString(view, 0, 'FORM');
    view.setUint32(4, buffer.byteLength - 8, false);
    writeString(view, 8, 'AIFF');

    /* COMM：声道数 / 采样帧数 / 位深 / 80 位采样率 */
    writeString(view, 12, 'COMM');
    view.setUint32(16, 18, false);
    view.setUint16(20, numCh, false);
    view.setUint32(22, len, false);
    view.setUint16(26, bitDepth, false);
    writeFloat80(view, 28, sampleRate);

    /* SSND：offset / blockSize 均为 0 */
    writeString(view, 38, 'SSND');
    view.setUint32(42, ssndSize, false);
    view.setUint32(46, 0, false);
    view.setUint32(50, 0, false);

    var data = interleave(channels, len);
    var off = 54;
    for (var i = 0; i < data.length; i++) {
      var s = data[i];
      if (s > 1) s = 1; else if (s < -1) s = -1;
      if (bitDepth === 16) {
        view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, false); off += 2;
      } else if (bitDepth === 24) {
        var v = Math.round(s < 0 ? s * 0x800000 : s * 0x7FFFFF);
        view.setUint8(off, (v >> 16) & 0xFF);
        view.setUint8(off + 1, (v >> 8) & 0xFF);
        view.setUint8(off + 2, v & 0xFF);
        off += 3;
      } else {
        view.setInt32(off, Math.round(s < 0 ? s * 0x80000000 : s * 0x7FFFFFFF), false); off += 4;
      }
    }
    return buffer;
  }

  /* ======================= 单位换算（变调） ======================= */

  var A4 = 440;

  function pitchToRatio(value, unit, refHz) {
    value = Number(value) || 0;
    switch (unit) {
      case 'semitone': return Math.pow(2, value / 12);
      case 'cent': return Math.pow(2, value / 1200);
      case 'hz': {
        var ref = refHz > 0 ? refHz : A4;
        var target = ref + value;                 // 以参考频率为基准的绝对偏移
        if (target <= 1) target = 1;
        return target / ref;
      }
      case 'ratio':
      default: return value > 0 ? value : 1;
    }
  }

  function ratioToPitch(ratio, unit, refHz) {
    if (!(ratio > 0)) ratio = 1;
    switch (unit) {
      case 'semitone': return 12 * Math.log2(ratio);
      case 'cent': return 1200 * Math.log2(ratio);
      case 'hz': {
        var ref = refHz > 0 ? refHz : A4;
        return ref * ratio - ref;
      }
      case 'ratio':
      default: return ratio;
    }
  }

  /* ======================= 降噪（谱减法） ======================= */
  /*
   * spectralDenoise(channels, cfg)
   *   cfg: { strength: 0..1, floorDb: 谱底噪(dB), fftSize, hop }
   *   原理：STFT -> 逐频点最小值跟踪估计噪声幅度谱 -> 过减 + 谱底噪限幅
   *         -> 增益的频域/时域平滑（抑制音乐噪声）-> IFFT overlap-add
   */
  function denoiseChannel(src, N, hop, fft, win, alpha, floor, H) {
    var n = src.length;
    if (n < N * 2) return clone(src);
    var frames = Math.max(1, Math.floor((n - N) / hop) + 1);
    var re = new Float32Array(N), im = new Float32Array(N);
    var noise = new Float32Array(H + 1);
    var sm = new Float32Array(H + 1);        // 幅度谱的时间平滑，用于稳定最小值跟踪
    var f, i, b;

    for (b = 0; b <= H; b++) noise[b] = Infinity;
    for (f = 0; f < frames; f++) {
      var rp = f * hop;
      for (i = 0; i < N; i++) { re[i] = src[rp + i] * win[i]; im[i] = 0; }
      fft.transform(re, im);
      for (b = 0; b <= H; b++) {
        var m = Math.sqrt(re[b] * re[b] + im[b] * im[b]);
        sm[b] = f === 0 ? m : (0.9 * sm[b] + 0.1 * m);
        if (sm[b] < noise[b]) noise[b] = sm[b];
      }
    }
    /* 噪声谱沿频率 3 点平滑，避免陷波 */
    var nb = new Float32Array(H + 1);
    for (b = 0; b <= H; b++) {
      var p0 = b > 0 ? noise[b - 1] : noise[b];
      var p1 = b < H ? noise[b + 1] : noise[b];
      nb[b] = (p0 + 2 * noise[b] + p1) * 0.25;
      if (!(nb[b] >= 0)) nb[b] = 0;
    }
    noise = nb;

    var alloc = n + N;
    var out = new Float32Array(alloc);
    var wsum = new Float32Array(alloc);
    var gain = new Float32Array(H + 1);
    var gsm = new Float32Array(H + 1);
    var prev = new Float32Array(H + 1);
    for (b = 0; b <= H; b++) prev[b] = 1;

    for (f = 0; f < frames; f++) {
      var pos = f * hop;
      for (i = 0; i < N; i++) { re[i] = src[pos + i] * win[i]; im[i] = 0; }
      fft.transform(re, im);

      for (b = 0; b <= H; b++) {
        var mag = Math.sqrt(re[b] * re[b] + im[b] * im[b]);
        var g = (mag - alpha * noise[b]) / (mag + 1e-12);
        if (g < floor) g = floor;
        else if (g > 1) g = 1;
        gain[b] = g;
      }
      for (b = 0; b <= H; b++) {
        var q0 = b > 0 ? gain[b - 1] : gain[b];
        var q1 = b < H ? gain[b + 1] : gain[b];
        var s = (q0 + 2 * gain[b] + q1) * 0.25;
        s = 0.55 * prev[b] + 0.45 * s;
        if (s < floor) s = floor;
        prev[b] = s;
        gsm[b] = s;
      }
      for (b = 0; b <= H; b++) {
        var gg = gsm[b];
        re[b] *= gg; im[b] *= gg;
        if (b > 0 && b < H) { var kb = N - b; re[kb] *= gg; im[kb] *= gg; }
      }
      fft.inverse(re, im);
      for (i = 0; i < N; i++) {
        out[pos + i] += re[i] * win[i];
        wsum[pos + i] += win[i] * win[i];
      }
    }

    var res = new Float32Array(n);
    for (i = 0; i < n; i++) {
      var ws = wsum[i];
      res[i] = ws > 1e-4 ? out[i] / ws : src[i];
    }
    return res;
  }

  function spectralDenoise(channels, cfg) {
    cfg = cfg || {};
    var amt = cfg.strength === undefined ? 0.6 : cfg.strength;
    if (amt < 0) amt = 0; if (amt > 1) amt = 1;
    if (amt < 1e-4) return channels;

    var N = cfg.fftSize || 1024;
    if ((N & (N - 1)) !== 0) N = 1024;
    var hop = cfg.hop || (N >> 2);
    var floorDb = cfg.floorDb === undefined ? -18 : cfg.floorDb;
    var floor = Math.pow(10, floorDb / 20);
    if (!(floor > 0.01)) floor = 0.01;
    if (floor > 1) floor = 1;
    var alpha = 1 + amt * 2;                     // 过减系数 1..3

    var fft = new FFT(N);
    var win = hann(N);
    var H = N >> 1;
    var out = [];
    for (var c = 0; c < channels.length; c++) {
      out.push(denoiseChannel(toFloat(channels[c]), N, hop, fft, win, alpha, floor, H));
    }
    return out;
  }

  /* ================= 均衡器（RBJ biquad） ================= */

  var EQ_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

  function biquadCoeffs(type, f0, Q, gainDb, sr) {
    var f = Math.min(Math.max(f0, 8), sr * 0.49);
    var w0 = TWO_PI * f / sr;
    var cw = Math.cos(w0), sw = Math.sin(w0);
    var q = Q > 0 ? Q : 0.7;
    var alpha = sw / (2 * q);
    var A = Math.pow(10, gainDb / 40);
    var b0, b1, b2, a0, a1, a2;
    if (type === 'peaking') {
      b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A;
      a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A;
    } else if (type === 'lowshelf') {
      var sA = Math.sqrt(A);
      b0 = A * ((A + 1) - (A - 1) * cw + 2 * sA * alpha);
      b1 = 2 * A * ((A - 1) - (A + 1) * cw);
      b2 = A * ((A + 1) - (A - 1) * cw - 2 * sA * alpha);
      a0 = (A + 1) + (A - 1) * cw + 2 * sA * alpha;
      a1 = -2 * ((A - 1) + (A + 1) * cw);
      a2 = (A + 1) + (A - 1) * cw - 2 * sA * alpha;
    } else if (type === 'highshelf') {
      var sA2 = Math.sqrt(A);
      b0 = A * ((A + 1) + (A - 1) * cw + 2 * sA2 * alpha);
      b1 = -2 * A * ((A - 1) + (A + 1) * cw);
      b2 = A * ((A + 1) + (A - 1) * cw - 2 * sA2 * alpha);
      a0 = (A + 1) - (A - 1) * cw + 2 * sA2 * alpha;
      a1 = 2 * ((A - 1) - (A + 1) * cw);
      a2 = (A + 1) - (A - 1) * cw - 2 * sA2 * alpha;
    } else if (type === 'highpass') {
      b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2;
      a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
    } else {
      b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2;
      a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
    }
    return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
  }

  /*
   * eqFilters(cfg, sampleRate)
   *   cfg: { gains:[10 dB], lowCut:Hz(0=关), highCut:Hz(0=关), q }
   *   首尾频段用 shelf，中间用 peaking；低切/高切为二阶滤波。
   */
  function eqFilters(cfg, sr) {
    cfg = cfg || {};
    var bands = cfg.bands || EQ_BANDS;
    var gains = cfg.gains || [];
    var q = cfg.q || 1.1;
    var list = [];
    if (cfg.lowCut > 0) list.push({ type: 'highpass', f0: cfg.lowCut, Q: 0.707, gainDb: 0 });
    for (var i = 0; i < bands.length; i++) {
      var g = gains[i];
      if (g === undefined || Math.abs(g) < 0.05) continue;
      var type = i === 0 ? 'lowshelf' : (i === bands.length - 1 ? 'highshelf' : 'peaking');
      var fo = i === 0 ? Math.max(bands[i], 32) : (i === bands.length - 1 ? Math.min(bands[i], sr * 0.45) : bands[i]);
      list.push({ type: type, f0: fo, Q: type === 'peaking' ? q : 0.707, gainDb: g });
    }
    if (cfg.highCut > 0) list.push({ type: 'lowpass', f0: cfg.highCut, Q: 0.707, gainDb: 0 });
    for (var k = 0; k < list.length; k++) list[k].c = biquadCoeffs(list[k].type, list[k].f0, list[k].Q, list[k].gainDb, sr);
    return list;
  }

  function applyEq(channels, cfg, sr) {
    var filters = eqFilters(cfg, sr);
    var out = [];
    for (var c = 0; c < channels.length; c++) {
      var x = clone(channels[c]);
      for (var k = 0; k < filters.length; k++) applyBiquad(x, filters[k].c);
      out.push(x);
    }
    return out;
  }

  function applyBiquad(x, cf) {
    var b0 = cf.b0, b1 = cf.b1, b2 = cf.b2, a1 = cf.a1, a2 = cf.a2;
    var x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (var i = 0; i < x.length; i++) {
      var xi = x[i];
      var yi = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
      x2 = x1; x1 = xi; y2 = y1; y1 = yi;
      x[i] = yi;
    }
    return x;
  }

  function biquadMag(cf, f, sr) {
    var w = TWO_PI * f / sr;
    var cw = Math.cos(w), sw = Math.sin(w);
    var cw2 = Math.cos(2 * w), sw2 = Math.sin(2 * w);
    var nr = cf.b0 + cf.b1 * cw + cf.b2 * cw2;
    var ni = -(cf.b1 * sw + cf.b2 * sw2);
    var dr = 1 + cf.a1 * cw + cf.a2 * cw2;
    var di = -(cf.a1 * sw + cf.a2 * sw2);
    var d = dr * dr + di * di;
    return d > 1e-12 ? Math.sqrt((nr * nr + ni * ni) / d) : 1;
  }

  /* 频响曲线（dB），用于绘制 EQ 曲线 */
  function eqResponse(cfg, sr, freqs) {
    var filters = eqFilters(cfg, sr);
    var out = new Float32Array(freqs.length);
    for (var i = 0; i < freqs.length; i++) {
      var m = 1;
      for (var k = 0; k < filters.length; k++) m *= biquadMag(filters[k].c, freqs[i], sr);
      out[i] = 20 * Math.log10(m > 1e-9 ? m : 1e-9);
    }
    return out;
  }

  /* ============== 人声 / 伴奏分离（中心声道相消） ============== */
  /*
   * vocalSep(channels, cfg)
   *   cfg: { mode: 'off' | 'remove' | 'vocal', strength: 0..1 }
   *   remove（去人声·保留伴奏）：Out = X - k·M ，M = (L+R)/2 中间声道
   *   vocal （去伴奏·保留人声）：Out = M
   *   立体声录音中人声多位于中间，此消去法对多数歌曲有效。
   */
  function vocalSep(channels, cfg) {
    cfg = cfg || {};
    var mode = cfg.mode || 'off';
    if (mode === 'off') return channels;
    var k = cfg.strength === undefined ? 0.9 : cfg.strength;
    if (k < 0) k = 0; if (k > 1) k = 1;

    if (channels.length < 2) return channels.map(clone);

    var L = toFloat(channels[0]), R = toFloat(channels[1]);
    var n = Math.min(L.length, R.length);
    var outL = new Float32Array(n), outR = new Float32Array(n);
    var i, mid;
    if (mode === 'vocal') {
      for (i = 0; i < n; i++) {
        mid = (L[i] + R[i]) * 0.5;
        outL[i] = mid; outR[i] = mid;
      }
    } else {
      for (i = 0; i < n; i++) {
        mid = (L[i] + R[i]) * 0.5;
        outL[i] = L[i] - k * mid;
        outR[i] = R[i] - k * mid;
      }
    }
    var extra = [];
    for (var c = 2; c < channels.length; c++) extra.push(clone(channels[c]));
    return [outL, outR].concat(extra);
  }

  return {
    FFT: FFT,
    hann: hann,
    clone: clone,
    reverse: reverse,
    slice: slice,
    timeStretch: timeStretch,
    resample: resample,
    processClip: processClip,
    peaks: peaks,
    envelopeInit: envelopeInit,
    envelopeFill: envelopeFill,
    envelopePeaks: envelopePeaks,
    envelopeReadyTo: envelopeReadyTo,
    peakLevel: peakLevel,
    normalize: normalize,
    encodeWav: encodeWav,
    encodeAiff: encodeAiff,
    interleave: interleave,
    pitchToRatio: pitchToRatio,
    ratioToPitch: ratioToPitch,
    spectralDenoise: spectralDenoise,
    eqFilters: eqFilters,
    applyEq: applyEq,
    eqResponse: eqResponse,
    EQ_BANDS: EQ_BANDS,
    vocalSep: vocalSep
  };
});
