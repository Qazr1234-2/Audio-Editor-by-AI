/*
 * Qazr Audio Engine
 * ------------------------------------------------------------------
 * 负责：
 *   - 单个音频片段 -> 处理后 PCM（变速 / 变调 / 反转）
 *   - 实时播放调度（多轨混音、淡入淡出、音量、声像）
 *   - 离线导出（OfflineAudioContext）
 *   - 音频文件解码
 */
(function (global) {
  'use strict';

  var DSP = global.QazrDSP;

  /* ---------------- 上下文 ---------------- */

  var ctx = null;
  var master = null;
  var live = [];          // 正在播放的 source 节点
  var rafId = 0;
  var playing = false;
  var tick = null;

  function dbToGain(db) {
    if (!db) return 1;
    return Math.pow(10, db / 20);
  }

  function ensure(sampleRate) {
    if (!ctx) {
      var AC = global.AudioContext || global.webkitAudioContext;
      var opt = {};
      if (sampleRate) opt.sampleRate = sampleRate;
      ctx = new AC(opt);
      master = ctx.createGain();
      master.gain.value = 1;
      master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function context() { return ctx; }
  function masterGain() { return master; }

  function setMasterVolume(v) {
    if (master) master.gain.setTargetAtTime(v, ctx.currentTime, 0.01);
  }

  /* ---------------- 解码 ---------------- */

  function decode(arrayBuffer) {
    var c = ensure();
    return new Promise(function (resolve, reject) {
      var p = c.decodeAudioData(arrayBuffer, function (buf) {
        var channels = [];
        for (var i = 0; i < buf.numberOfChannels; i++) channels.push(new Float32Array(buf.getChannelData(i)));
        resolve({ channels: channels, sampleRate: buf.sampleRate, duration: buf.duration });
      }, function (err) { reject(err || new Error('解码失败，请确认文件为受支持的音频格式')); });
      if (p && p.then) p.catch(reject);
    });
  }

  /* ---------------- 素材处理（带缓存） ---------------- */

  function sliceChannels(channels, from, len) {
    var out = [];
    for (var i = 0; i < channels.length; i++) out.push(DSP.slice(channels[i], from, len));
    return out;
  }

  /*  渲染单个片段为可直接 1.0 倍速播放的 PCM
   *  clip: { channels, srcIn(秒), srcLen(秒), sampleRate, reversed, speed, pitch,
   *          vanilla, ratio, vocal, denoise, eq }
   */
  function renderClip(src, clip) {
    var sr = clip.sampleRate || src.sampleRate;
    var from = Math.round((clip.srcIn || 0) * sr);
    var len = Math.round((clip.srcLen || src.duration) * sr);
    var seg = clip.channels ? clip.channels : sliceChannels(src.channels, from, len);

    if (clip.reversed) seg = seg.map(function (c) { return DSP.reverse(c); });

    /* 人声 / 伴奏分离：基于原始立体声的中心声道相消，先于变速变调 */
    if (clip.vocal && clip.vocal.mode && clip.vocal.mode !== 'off') {
      seg = DSP.vocalSep(seg, clip.vocal);
    }

    var out = DSP.processClip(seg, {
      speed: clip.speed || 1,
      pitch: clip.pitch || 1,
      vanilla: !!clip.vanilla,
      ratio: clip.ratio || 1,
      fftSize: clip.fftSize
    });

    /* 降噪（谱减法） */
    if (clip.denoise && clip.denoise.on) {
      out = DSP.spectralDenoise(out, clip.denoise);
    }

    /* 均衡器 */
    if (clip.eq && clip.eq.on) {
      out = DSP.applyEq(out, clip.eq, sr);
    }
    return { channels: out, sampleRate: sr };
  }

  /* ---------------- 播放 ---------------- */

  function schedule(c, dest, it, t0) {
    var len = it.channels[0] ? it.channels[0].length : 0;
    if (!len) return null;
    var clipDurSec = it.clipDur > 0 ? it.clipDur : len / it.sampleRate;

    /* 播放时只截取到 clipDur，避免把尾部多余样本暴露出去 */
    var usable = Math.min(len, Math.max(1, Math.ceil(clipDurSec * it.sampleRate)));
    if (usable < len) {
      var cut = [];
      for (var ci = 0; ci < it.channels.length; ci++) cut.push(it.channels[ci].subarray(0, usable));
      it = Object.assign({}, it, { channels: cut });
      len = usable;
    }

    var buf = c.createBuffer(it.channels.length, len, it.sampleRate);
    for (var i = 0; i < it.channels.length; i++) buf.copyToChannel(it.channels[i], i);

    var src = c.createBufferSource();
    src.buffer = buf;

    var mono = it.channels.length === 1;
    var gainL = it.gainL === undefined ? 1 : it.gainL;
    var gainR = it.gainR === undefined ? 1 : it.gainR;
    var mode = it.channelMode || 'stereo';
    var needCh = mode !== 'stereo' || Math.abs(gainL - 1) > 1e-6 || Math.abs(gainR - 1) > 1e-6;

    /* 声道处理级：split -> L/R 独立增益 -> merge */
    var head = src;
    if (needCh) {
      var effL = gainL, effR = gainR;
      var inL = 0, inR = 1;
      if (mode === 'left') { effR = 0; }
      else if (mode === 'right') { effL = 0; }
      else if (mode === 'merge') { var m = (gainL + gainR) / 2; effL = m; effR = m; }
      else if (mode === 'swap') { inL = 1; inR = 0; }

      var split = c.createChannelSplitter(2);
      var gl = c.createGain(); gl.gain.value = effL;
      var gr = c.createGain(); gr.gain.value = effR;
      var merge = c.createChannelMerger(2);
      src.connect(split);
      split.connect(gl, 0);
      split.connect(gr, mono ? 0 : 1);
      gl.connect(merge, 0, inL);
      gr.connect(merge, 0, inR);
      head = merge;
    }

    var g = c.createGain();
    var tail = g;

    if (it.pan) {
      var p = c.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, it.pan));
      g.connect(p);
      tail = p;
    }
    head.connect(g);
    tail.connect(dest);

    var base = it.gain === undefined ? 1 : it.gain;
    base *= (it.volume === undefined ? 1 : it.volume);
    var startAt = t0 + (it.delay || 0);
    var localT = it.offset || 0;
    var dur = clipDurSec;
    var fi = it.fadeIn || 0;
    var fo = it.fadeOut || 0;

    var env = g.gain;
    env.cancelScheduledValues(startAt);
    env.setValueAtTime(envAt(base, localT, dur, fi, fo), startAt);

    if (fi > 0 && localT < fi) {
      env.linearRampToValueAtTime(base, startAt + (fi - localT));
    }
    var foStart = dur - fo;
    if (fo > 0 && localT < foStart) {
      if (fi === 0 || foStart > fi) env.setValueAtTime(base, startAt + (foStart - localT));
      env.linearRampToValueAtTime(0.0001, startAt + (dur - localT));
    }

    src.start(startAt, 0);
    return src;
  }

  function envAt(base, t, dur, fi, fo) {
    var v = base;
    if (fi > 0 && t < fi) v *= t / fi;
    if (fo > 0 && t > dur - fo) v *= Math.max(0, (dur - t) / fo);
    return v < 0.0001 ? 0.0001 : v;
  }

  /*
   * play(items, { onTick, onEnd })
   * it: { channels, sampleRate, delay, offset, clipDur, gain, fadeIn, fadeOut, volume, pan }
   */
  function play(items, handlers) {
    stop();
    var c = ensure();
    handlers = handlers || {};
    var t0 = c.currentTime + 0.08;

    for (var i = 0; i < items.length; i++) {
      var s = schedule(c, master, items[i], t0);
      if (s) live.push(s);
    }

    playing = true;
    var total = handlers.total || 0;
    var startedAt = t0;

    function loop() {
      if (!playing) return;
      var pos = c.currentTime - startedAt;
      if (handlers.onTick) handlers.onTick(pos);
      if (total && pos >= total) {
        stop();
        if (handlers.onEnd) handlers.onEnd();
        return;
      }
      rafId = requestAnimationFrame(loop);
    }
    if (total) rafId = requestAnimationFrame(loop);
    else if (handlers.onTick) rafId = requestAnimationFrame(loop);
    return t0;
  }

  function stop() {
    playing = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    for (var i = 0; i < live.length; i++) {
      try { live[i].stop(); } catch (e) { /* noop */ }
      try { live[i].disconnect(); } catch (e2) { /* noop */ }
    }
    live = [];
  }

  function isPlaying() { return playing; }

  /* ---------------- 离线导出 ---------------- */

  function render(items, opts) {
    opts = opts || {};
    var sampleRate = opts.sampleRate || 48000;
    var channels = opts.channels || 2;
    var length = Math.max(1, Math.ceil(opts.duration * sampleRate));
    var OC = global.OfflineAudioContext || global.webkitOfflineAudioContext;
    var c = new OC(channels, length, sampleRate);
    var mg = c.createGain();
    mg.gain.value = 1;
    mg.connect(c.destination);
    for (var i = 0; i < items.length; i++) schedule(c, mg, items[i], 0);
    return c.startRendering();
  }

  function bufferToChannels(audioBuffer) {
    var out = [];
    for (var i = 0; i < audioBuffer.numberOfChannels; i++) out.push(new Float32Array(audioBuffer.getChannelData(i)));
    return out;
  }

  global.QazrEngine = {
    ensure: ensure,
    context: context,
    masterGain: masterGain,
    setMasterVolume: setMasterVolume,
    decode: decode,
    renderClip: renderClip,
    sliceChannels: sliceChannels,
    play: play,
    stop: stop,
    isPlaying: isPlaying,
    render: render,
    bufferToChannels: bufferToChannels,
    dbToGain: dbToGain
  };
})(typeof window !== 'undefined' ? window : this);
