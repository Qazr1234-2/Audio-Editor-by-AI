/*
 * Qazr 音频剪辑 — Python 桌面版桥接
 * ------------------------------------------------------------------
 * 这个文件只在 Python 桌面版里生效（由主程序注入）。
 * 在纯浏览器里打开时，window.QazrPy 根本不存在，app.js 会自动
 * 退回内置实现，所以对单文件 HTML 版没有任何影响。
 *
 * 分工：
 *   控制指令（对话框、导出、能力查询）→ 本地回环 HTTP 的 /api/*
 *   大块 PCM 数据                       → 同一个 HTTP 层（二进制流）
 *
 * 早先这里走的是 QWebChannel，但它依赖 qrc:///qtwebchannel/qwebchannel.js，
 * 而本机的 PySide6 构建里根本没有注册这个资源，导致桥接永远就绪不了、
 * 导出一直卡在编码中。改成 HTTP 之后这条依赖链就断开了。
 */
(function () {
  'use strict';

  var TOKEN = (location.search.match(/[?&]t=([^&]+)/) || [])[1] || '';

  function api(path) {
    var sep = path.indexOf('?') >= 0 ? '&' : '?';
    return path + sep + 't=' + encodeURIComponent(TOKEN);
  }

  function getJSON(path) {
    return fetch(api(path)).then(function (r) { return r.json(); });
  }

  function postJSON(path, obj) {
    return fetch(api(path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(obj || {})
    }).then(function (r) { return r.json(); });
  }

  function dispatch(name, detail) {
    try {
      window.dispatchEvent(new CustomEvent(name, { detail: detail }));
    } catch (e) {
      // 老引擎的兜底
      var ev = document.createEvent('CustomEvent');
      ev.initCustomEvent(name, false, false, detail);
      window.dispatchEvent(ev);
    }
  }

  var P = {
    ready: false,
    caps: null,
    version: 'desktop'
  };

  /* ---------- 能力查询 ---------- */
  P.refreshCaps = function (cb) {
    getJSON('/api/caps').then(function (r) {
      if (!r.error) P.caps = r;
      if (cb) cb(r);
    }).catch(function (e) {
      if (cb) cb({ error: String(e) });
    });
  };

  /* ---------- 导入 ---------- */

  /* 弹出原生文件对话框，导入完成后把每个素材的 PCM 取回来 */
  P.importViaDialog = function (onItems) {
    getJSON('/api/open-media').then(function (r) {
      if (r.cancelled) { if (onItems) onItems(null); return; }
      if (r.error) { if (onItems) onItems({ error: r.error }); return; }
      loadItems(r, onItems);
    }).catch(function (e) {
      if (onItems) onItems({ error: String(e) });
    });
  };

  /* 菜单里用的名字 */
  P.openMedia = P.importViaDialog;

  /* 按路径导入（窗口拖拽 / 命令行传入）。paths 可以是数组，也可以是 JSON 文本 */
  P.loadPaths = function (paths) {
    if (typeof paths === 'string') {
      try { paths = JSON.parse(paths); } catch (e) { paths = []; }
    }
    postJSON('/api/load-paths', { paths: paths || [] }).then(function (r) {
      if (r.error) { dispatch('qazr-py-error', r.error); return; }
      loadItems(r, null);
    }).catch(function (e) {
      dispatch('qazr-py-error', String(e));
    });
  };

  /* 把 items 里的每个素材真正下载成 Float32Array 并交给 app */
  function loadItems(r, onItems) {
    var items = r.items || [];
    var failed = r.failed || [];
    if (!items.length) {
      if (onItems) onItems({ items: [], failed: failed });
      return;
    }
    var out = [];
    var pending = items.length;
    items.forEach(function (it) {
      P.fetchAudio(it.id).then(function (chans) {
        out.push({
          channels: chans,
          sampleRate: it.sample_rate,
          duration: it.duration,
          name: it.name,
          hasVideo: it.has_video,
          codec: it.codec
        });
      }).catch(function (e) {
        failed.push({ name: it.name, error: String(e) });
      }).then(function () {
        if (--pending === 0) {
          if (onItems) onItems({ items: out, failed: failed });
          else if (out.length) dispatch('qazr-py-imported', { items: out, failed: failed });
          else if (failed.length) dispatch('qazr-py-error', '导入失败：' + failed[0].name);
        }
      });
    });
  }

  /* 下载某个素材的原始 PCM（交错 float32 -> 每声道 Float32Array） */
  P.fetchAudio = function (id) {
    return fetch(api('/api/audio/' + encodeURIComponent(id)))
      .then(function (res) {
        if (!res.ok) throw new Error('取音频失败：HTTP ' + res.status);
        var ch = parseInt(res.headers.get('X-Channels'), 10);
        var frames = parseInt(res.headers.get('X-Frames'), 10);
        return res.arrayBuffer().then(function (ab) {
          var all = new Float32Array(ab);
          var out = [];
          for (var c = 0; c < ch; c++) {
            var plane = new Float32Array(frames);
            for (var i = 0; i < frames; i++) plane[i] = all[i * ch + c];
            out.push(plane);
          }
          return out;
        });
      });
  };

  /* ---------- 导出 ---------- */

  /* 上传渲染好的混音，拿到 id 供后续导出 */
  P.uploadPcm = function (channels, sampleRate) {
    var ch = channels.length;
    var frames = 0;
    for (var i = 0; i < ch; i++) frames = Math.max(frames, channels[i].length);
    var all = new Float32Array(frames * ch);
    for (var c = 0; c < ch; c++) {
      var src = channels[c];
      for (var j = 0; j < frames; j++) all[j * ch + c] = j < src.length ? src[j] : 0;
    }
    return fetch(api('/api/pcm?ch=' + ch + '&frames=' + frames + '&sr=' + sampleRate), {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: all.buffer
    }).then(function (res) {
      return res.json();
    }).then(function (r) {
      if (r.error) throw new Error(r.error);
      return r.id;
    });
  };

  /* 弹出原生保存对话框并编码写盘 */
  P.exportAudio = function (id, fmtKey, bitrate, defaultName, cb) {
    postJSON('/api/export', {
      id: id,
      fmt: fmtKey,
      bitrate: bitrate | 0,
      name: defaultName || ''
    }).then(function (r) {
      if (cb) cb(r);
    }).catch(function (e) {
      if (cb) cb({ error: String(e) });
    });
  };

  /* 供菜单调用：触发界面上的导出弹窗 */
  P.exportDialog = function () {
    var btn = document.getElementById('btnExport');
    if (btn) btn.click();
  };

  P.reveal = function (p) { postJSON('/api/reveal', { path: p }); };

  /* ---------- 就绪 ---------- */
  P.ready = true;
  window.QazrPy = P;
  P.refreshCaps(function () {
    dispatch('qazr-py-ready', P.caps);
  });
})();
